import 'package:elfares/genaral/constants/DisabledTextField.dart';
import 'package:elfares/genaral/utilities/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';

// ignore: must_be_immutable
class MyDatePicker extends StatefulWidget {
  MyDatePicker({
    Key? key,
    this.value,
  }) : super(key: key);
  String? value;
  @override
  State<MyDatePicker> createState() => _MyDatePickerState();
}

class _MyDatePickerState extends State<MyDatePicker> {
  @override
  Widget build(BuildContext context) {
    return Flexible(
        child: GestureDetector(
      onTap: () => DatePicker.showDatePicker(
        context,
        showTitleActions: true,
        minTime: DateTime(2018, 1, 1),
        maxTime: DateTime.now(),
        onChanged: (date) {
          setState(() {
            widget.value = Utils.simplifyDate(date);
          });
        },
        onConfirm: (date) {
          setState(() {
            widget.value = Utils.simplifyDate(date);
          });
        },
        currentTime: DateTime.now(),
        locale: LocaleType.ar,
      ),
      child: DisabledTextField(
          margin: const EdgeInsets.only(right: 10),
          label: "${widget.value ?? Utils.simplifyDate(DateTime.now())}"),
    ));
  }
}
