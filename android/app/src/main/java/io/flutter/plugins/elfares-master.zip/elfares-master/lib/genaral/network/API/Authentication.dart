import 'package:elfares/genaral/models/user_model.dart';
import 'package:elfares/genaral/utilities/CachHelper.dart';

import '../Http.dart';

class Authentication {
  HttpMethods _http = HttpMethods();
  Map<String, String> headers = <String, String>{
    'Accept': '*/*',
    'Content-Type': 'application/json',
  };
  Future<UserModel> login(String userName, String password) async {
    UserModel _model = UserModel();
    var _data = await _http.getData(
      url: 'user?userName=$userName&PSWRD=$password',
    );
    print({"username": userName, "password": password});
    print(_data);
    if (_data[0] != null) {
      _model = UserModel.fromJson(_data[0]);
      print(_model.empId);
      return _model;
    } else {
      return _model;
    }
  }

  Future<String> companyLogin(String company) async {
    var _data = await _http.companyLogin(company: company);
    if (_data != null) {
      CachHelper.saveData(key: "key", value: _data["access_token"]);
      return "1";
    } else {
      print(_data);
      return "لم يتم تسجيل المستخدم, برجاء مراجعة البيانات";
    }
  }
}
