import 'package:LocarionWallet/Public/Provider/LocationProvider.dart';
import 'package:LocarionWallet/Public/Provider/UserProvider.dart';
import 'package:LocarionWallet/Public/Screens/Splash.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:auto_route/auto_route.dart';
import 'package:bot_toast/bot_toast.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';
import 'Constants/CachHelper.dart';
import 'Constants/MyColors.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await CachHelper.init();
  Widget startWidget;
  runApp(
    EasyLocalization(
      supportedLocales: [Locale('ar', 'EG'), Locale('en', 'US')],
      path: 'assets/locales',
      fallbackLocale: Locale('ar', 'EG'),
      startLocale: Locale('ar', 'EG'),
      child: MyApp(startWidget: startWidget),
    ),
  );
}

// ignore: must_be_immutable
class MyApp extends StatelessWidget {
  final Widget startWidget;
  ThemeData _defaultThem = ThemeData(
    fontFamily: "Cairo",
    primarySwatch: Colors.grey,
    cursorColor: MyColors.primary,
    focusColor: MyColors.primary,
    accentColor: MyColors.primary,
    primaryColor: MyColors.primary,
    platform: TargetPlatform.android,
    pageTransitionsTheme: PageTransitionsTheme(builders: {
      TargetPlatform.android: CupertinoPageTransitionsBuilder(),
    }),
  );
  final navigatorKey = new GlobalKey<NavigatorState>();

  MyApp({Key key, this.startWidget}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final botToastBuilder = BotToastInit();

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => LocationProvider()),
      ],
      child: MaterialApp(
        title: tr("locationWallet"),
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
        theme: _defaultThem,
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        home: Splash(),
        builder: ExtendedNavigator.builder<AppRouter>(
            router: AppRouter(),
            initialRoute: Routes.splash,
            navigatorKey: navigatorKey,
            builder: (ctx, child) {
              child = FlutterEasyLoading(child: child); //do something
              child = botToastBuilder(context, child);
              return child;
            }),
      ),
    );
  }
}
