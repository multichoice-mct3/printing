import 'package:elfares/genaral/constants/MyColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:search_choices/search_choices.dart';

class CustomDropDown extends StatelessWidget {
  const CustomDropDown({
    required this.hint,
    required this.items,
    required this.value,
    required this.onChange,
  });

  final String hint;
  final List<String> items;
  final String? value;
  final Function(String value) onChange;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 5),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: MyColors.primary, width: .8)),
      child: SearchChoices.single(
        items: items.map((item) {
          return (DropdownMenuItem(
            child: Text(
              item,
              style: TextStyle(color: Colors.black),
              textAlign: TextAlign.right,
            ),
            value: item,
          ));
        }).toList(),
        value: value,
        hint: Text(hint,
            style: TextStyle(color: Colors.black), textAlign: TextAlign.right),
        searchHint: Text(hint, style: TextStyle(color: Colors.black)),
        autofocus: false,
        rightToLeft: true,
        onChanged: (value) => onChange(value),
        isExpanded: true,
        displayItem: (item, selected) {
          return (Row(textDirection: TextDirection.rtl, children: [
            selected
                ? Icon(
                    Icons.radio_button_checked,
                    color: Colors.grey,
                  )
                : Icon(
                    Icons.radio_button_unchecked,
                    color: Colors.grey,
                  ),
            SizedBox(width: 7),
            item,
            Expanded(
              child: SizedBox.shrink(),
            ),
          ]));
        },
        selectedValueWidgetFn: (item) {
          return SizedBox(
            width: 280,
            child: (Text(
              item,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              softWrap: false,
              textDirection: TextDirection.rtl,
              style: GoogleFonts.cairo(fontSize: 14),
            )),
          );
        },
        displayClearIcon: false,
        closeButton: "إغلاق",
      ),
    );
  }
}
