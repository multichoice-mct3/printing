part of "WidgetsImport.dart";

class SearchBar extends StatelessWidget {
  const SearchBar({
    Key? key,
    required this.onChange,
  }) : super(key: key);
  final Function(String value) onChange;
  @override
  Widget build(BuildContext context) {
    return Row(
      textBaseline: TextBaseline.ideographic,
      crossAxisAlignment: CrossAxisAlignment.baseline,
      children: [
        Expanded(
          child: LabelTextField(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            label: "بحث",
            isPassword: false,
            onChange: (value) {
              // print(value);
              onChange(value);
            },
          ),
        ),
        // Container(
        //   child: MyText(title: "بحث", color: Colors.white),
        //   margin: EdgeInsets.only(right: 10),
        //   padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
        //   decoration: BoxDecoration(
        //     color: MyColors.primary,
        //     borderRadius: BorderRadius.circular(8),
        //   ),
        // ),
      ],
    );
  }
}
