
import 'package:mandoboct/General/Models/CategoryModel.dart';

import '../Http.dart';

class CategoriesAPI {
  HttpMethods _http = HttpMethods();
  Future<List<Category>> getCategoriesFromApi() async {
    List<Category>? categories;
    var _data = await _http.getData(url: "Categories");
    if (_data != null) {
      List<Map<String, dynamic>> _categoriesJson =
          List<Map<String, dynamic>>.from(_data);
      categories = _categoriesJson
          .map((category) => Category.fromJson(category))
          .toList();
      return categories;
    }

    return categories!;
  }
}
