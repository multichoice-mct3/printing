class AvrCause{
  int AVCId;
  String AVCName;
  AvrCause({
    this.AVCId,
    this.AVCName
         });
  factory AvrCause.fromJson(Map<String,dynamic>jsonObject){
    return AvrCause(
      AVCId: jsonObject['AVCId'],
      AVCName: jsonObject['AVCName']
    );
  }

}