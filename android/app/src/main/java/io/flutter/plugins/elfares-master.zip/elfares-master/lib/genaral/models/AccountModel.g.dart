// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'AccountModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AccountModel _$AccountModelFromJson(Map<String, dynamic> json) {
  return AccountModel(
    accountId: json['ACCOUNTID'] as String?,
    accountName: json['AccountName'] as String?,
  );
}

Map<String, dynamic> _$AccountModelToJson(AccountModel instance) =>
    <String, dynamic>{
      'ACCOUNTID': instance.accountId,
      'AccountName': instance.accountName,
    };
