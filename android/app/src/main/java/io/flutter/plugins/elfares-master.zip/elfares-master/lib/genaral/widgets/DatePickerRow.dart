import 'package:elfares/genaral/constants/MyText.dart';
import 'package:elfares/genaral/widgets/MyDatePicker.dart';
import 'package:flutter/material.dart';

class DatePickerRow extends StatelessWidget {
  const DatePickerRow({
    Key? key,
    required this.value,
    required this.value1,
  }) : super(key: key);

  final String? value;
  final String? value1;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              MyText(
                title: "من",
                color: Colors.white,
                size: 12,
              ),
              MyDatePicker(value: value),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Row(
            children: [
              MyText(
                title: "الى",
                color: Colors.white,
                size: 12,
              ),
              MyDatePicker(value: value1),
            ],
          ),
        ),
      ],
    );
  }
}
