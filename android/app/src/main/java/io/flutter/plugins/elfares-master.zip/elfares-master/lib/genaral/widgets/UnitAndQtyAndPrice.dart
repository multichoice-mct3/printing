part of "WidgetsImport.dart";

// ignore: must_be_immutable
class UnitAndQtyAndPrice extends StatefulWidget {
  UnitAndQtyAndPrice({
    Key? key,
    this.unit,
    required this.qty,
    required this.showPrice,
    this.price,
  }) : super(key: key);

  String? unit;
  final TextEditingController qty;
  final TextEditingController? price;
  final bool showPrice;

  @override
  State<UnitAndQtyAndPrice> createState() => _UnitAndQtyAndPriceState();
}

class _UnitAndQtyAndPriceState extends State<UnitAndQtyAndPrice> {
  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Flexible(
          child: SimpleDropDown(
            hint: "الوحدة",
            items: ['قطعة'],
            value: widget.unit,
            onChanged: (value) {
              setState(() {
                widget.unit = value;
              });
            },
          ),
        ),
        const SizedBox(width: 5),
        Flexible(
          child: LabelTextField(
            controller: widget.qty,
            label: "الكمية",
            isPassword: false,
            type: TextInputType.number,
          ),
        ),
        const SizedBox(width: 5),
        widget.showPrice
            ? Flexible(
                child: LabelTextField(
                  label: "السعر",
                  controller: widget.price,
                  isPassword: false,
                  type: TextInputType.number,
                ),
              )
            : SizedBox(),
      ],
    );
  }
}
