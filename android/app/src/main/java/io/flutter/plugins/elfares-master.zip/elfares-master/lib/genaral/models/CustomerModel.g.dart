// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'CustomerModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CustomerModel _$CustomerModelFromJson(Map<String, dynamic> json) {
  return CustomerModel(
    customerId: json['CustomerID'] as int?,
    customerName: json['CustomerName'] as String?,
    accountId: json['AccountID'] as String?,
  );
}

Map<String, dynamic> _$CustomerModelToJson(CustomerModel instance) =>
    <String, dynamic>{
      'CustomerID': instance.customerId,
      'CustomerName': instance.customerName,
      'AccountID': instance.accountId,
    };
