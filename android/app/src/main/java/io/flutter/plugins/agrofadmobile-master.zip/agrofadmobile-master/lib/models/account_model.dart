class Account{
  String AccountId;
  String AccountName;

  Account({this.AccountId,this.AccountName});

  factory Account.fromJson(Map<String,dynamic> account){
    return Account(
      AccountId: account['ACCOUNTID'],
      AccountName: account['AccountName']
    );

  }


}