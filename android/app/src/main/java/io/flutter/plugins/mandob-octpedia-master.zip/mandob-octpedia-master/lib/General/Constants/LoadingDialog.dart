import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:mandoboct/General/Constants/MyColors.dart';

import 'MyText.dart';

class LoadingDialog {
  var _context;

  LoadingDialog(this._context);

  showDilaog() {
    showDialog(
        barrierDismissible: false,
        context: _context,
        builder: (BuildContext context) {
          return AlertDialog(
            contentPadding: EdgeInsets.all(0),
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(10))),
            backgroundColor: Colors.transparent,
            content: SpinKitDualRing(color: MyColors.secondary, size: 30.0),
          );
        });
  }

  showLoadingView() => SpinKitThreeBounce(color: MyColors.primary, size: 40.0);

  showSimpleLoadingView() => SpinKitRipple(color: MyColors.primary, size: 40.0);

  showMapLoadingView() =>
      CupertinoActivityIndicator(animating: true, radius: 20);

  showNotification(msg) {
    _context.currentState.showSnackBar(
      SnackBar(
        content: Container(
          height: 25,
          alignment: Alignment.center,
          child: MyText(
            title: msg,
            color: Colors.white,
            size: 10,
          ),
        ),
        backgroundColor: Colors.black.withOpacity(.7),
        duration: Duration(seconds: 2),
      ),
    );
  }

  showBlackNotification(msg) {
    _context.currentState.showSnackBar(
      SnackBar(
        content: Container(
          height: 30,
          alignment: Alignment.center,
          child: MyText(
            title: msg,
            color: Colors.white,
            size: 16,
          ),
        ),
        backgroundColor: MyColors.primary,
        duration: Duration(seconds: 2),
      ),
    );
  }
}
