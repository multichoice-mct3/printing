import 'package:elfares/genaral/constants/MyColors.dart';
import 'package:flutter/material.dart';

class AnimatedLoading extends StatefulWidget {
  const AnimatedLoading({Key? key, required this.child}) : super(key: key);
  final Widget child;
  @override
  _AnimatedLoadingState createState() => _AnimatedLoadingState();
}

class _AnimatedLoadingState extends State<AnimatedLoading>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation _positionAnimation;
  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    _positionAnimation = Tween<double>(begin: .2, end: .3).animate(_controller);
    _controller.forward();
    _controller.addListener(() {
      if (_positionAnimation.isCompleted) {
        _controller.reverse();
      } else if (_positionAnimation.isDismissed) {
        _controller.forward();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) => Container(
        // width: _positionAnimation.value * 100,
        padding: EdgeInsets.all(_positionAnimation.value * 50),
        decoration: BoxDecoration(
            color: MyColors.primary.withOpacity(.3), shape: BoxShape.circle),
        child: widget.child,
      ),
    );
  }
}
