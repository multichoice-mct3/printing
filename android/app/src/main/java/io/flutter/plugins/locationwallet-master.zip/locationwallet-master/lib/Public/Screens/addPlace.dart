import 'package:LocarionWallet/Constants/DefaultButton.dart';
import 'package:LocarionWallet/Constants/IconTextFiled.dart';
import 'package:LocarionWallet/Constants/LoadingDialog.dart';
import 'package:LocarionWallet/Constants/MyColors.dart';
import 'package:LocarionWallet/Public/Provider/LocationProvider.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddPlace extends StatefulWidget {
  @override
  _AddPlaceState createState() => _AddPlaceState();
}

class _AddPlaceState extends State<AddPlace> {
  TextEditingController placeName = TextEditingController();

  TextEditingController placeDesc = TextEditingController();
  @override
  void dispose() {
    placeName.dispose();
    placeDesc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.read<LocationProvider>().getUserLocation();

    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        children: [
          SizedBox(height: 30),
          IconTextFiled(
            controller: placeName,
            isPassword: false,
            label: "${tr("name")} ${tr("location")}",
            icon: Icon(Icons.add_location_alt_outlined),
          ),
          SizedBox(height: 10),
          TextFormField(
            controller: placeDesc,
            maxLines: 4,
            decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 1.5),
                  borderRadius: BorderRadius.circular(5)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(5),
                  borderSide: BorderSide(
                      color: MyColors.primary.withOpacity(.5), width: 2)),
              hintText: tr("description"),
              hintStyle: TextStyle(
                  fontFamily: "Cairo", fontSize: 14, color: Colors.black45),
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 10, vertical: 14),
              suffixIcon: Icon(Icons.description_rounded),
            ),
          ),
          SizedBox(height: 30),
          Row(
            children: [
              Expanded(
                child: DefaultButton(
                  margin: EdgeInsets.symmetric(horizontal: 10),
                  title: "${tr("add")} ${tr("location")} ",
                  onTap: () async {
                    LoadingDialog.showLoadingDialog();
                    context.read<LocationProvider>().addLocation(
                          locationDescription: placeDesc.text,
                          locationName: placeName.text,
                          mapLatitude: context.read<LocationProvider>().getLat,
                          mapLongitude:
                              context.read<LocationProvider>().getLong,
                        );

                    placeDesc.clear();
                    placeName.clear();
                  },
                ),
              ),
              Expanded(
                child: DefaultButton(
                  margin: EdgeInsets.symmetric(horizontal: 10),
                  textColor: MyColors.primary,
                  title: tr("saved_locations"),
                  onTap: () => ExtendedNavigator.root.push(Routes.savedPlaces),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
