import 'package:elfares/genaral/constants/MyDropDown.dart';
import 'package:elfares/genaral/providers/StoresProvider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class StoresDropdown extends StatelessWidget {
  const StoresDropdown({
    Key? key,
  }) : super(key: key);

  // @override
  // void initState() {
  //   super.initState();
  //   context.read<StoresProvider>().getStores();
  // }

  @override
  Widget build(BuildContext context) {
    return Consumer<StoresProvider>(
      builder: (context, stores, child) => Padding(
        padding: const EdgeInsets.all(8.0),
        child: CustomDropDown(
          hint: "اختر المخزن",
          items: stores.storesNames,
          value: stores.storeName,
          onChange: (value) => print(value),
        ),
      ),
    );
  }
}
