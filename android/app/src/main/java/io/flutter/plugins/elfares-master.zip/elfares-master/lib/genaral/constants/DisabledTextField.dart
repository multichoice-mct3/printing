import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'MyColors.dart';

// ignore: must_be_immutable
class DisabledTextField extends StatelessWidget {
  TextEditingController? controller;
  String label;
  EdgeInsets? margin = EdgeInsets.all(0);
  bool? isPassword = false;
  TextInputType? type = TextInputType.text;
  Widget? icon;

  DisabledTextField({
    required this.label,
    this.controller,
    this.margin,
    this.isPassword,
    this.type,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      margin: margin,
      decoration: BoxDecoration(
          color: MyColors.grey,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      child: TextFormField(
        controller: controller,
        keyboardType: type,
        enabled: false,
        style: GoogleFonts.cairo(fontSize: 14),
        decoration: InputDecoration(
            disabledBorder: InputBorder.none,
            focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    color: MyColors.primary.withOpacity(.8), width: 2),
                borderRadius: BorderRadius.all(Radius.circular(10))),
            hintText: "  $label  ",
            hintStyle: GoogleFonts.cairo(fontSize: 14),
            prefixIcon: icon,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 10)),
      ),
    );
  }
}
