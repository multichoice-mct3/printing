import 'package:flutter/cupertino.dart';
import 'package:mandoboct/General/Models/ItemModel.dart';
import 'package:mandoboct/General/Models/ProviderModel.dart';
import 'package:mandoboct/General/Network/API/ItemsApi.dart';
import 'package:mandoboct/General/Network/API/ProvidersApi.dart';

class MokademKhedma extends ChangeNotifier {
  String? _providerName;
  String? get providerName => _providerName;

  changeDropDownValue(String value) {
    _providerName = value;
    getProviderId(value);
    print(_providerId);
    notifyListeners();
  }

  List<String> _items = [];
  List<String> get items => _items;
  addToItems(String item) {
    _items.add(item);
    notifyListeners();
  }

  deleteFromItems(String item) {
    _items.remove(item);
    notifyListeners();
  }

  ProviderApi _providersFromApi = ProviderApi();
  List<ProviderModel> _providers = [];
  List<ProviderModel> get providers => _providers;
  List<String> _providersNames = [];
  List<String> get providerNames => _providersNames;
  int? _providerId;
  int? get providerId => _providerId;
  getProviders() async {
    _providers = await _providersFromApi.getAllProvidersFromApi();
    print(_providers.length);
    fillNames();
    print("_providersNames.length ${_providersNames.length}");
    notifyListeners();
  }

  fillNames() {
    for (var provider in _providers) {
      _providersNames.add(provider.providesName!);
    }
  }

  getProviderId(String name) {
    int itemId =
        _providers.indexWhere((element) => element.providesName == name);
    _providerId = _providers[itemId].providesId;
  }

  Future<void> addItem(ItemModel item) async {
    await ItemsApi().addItem(item);
    notifyListeners();
  }
  // List<ItemModel> _itemsFromApi = [];
  // List<ItemModel> get itemsFromApi => _itemsFromApi;
  // Future<void> getItems() async {
  //   _itemsFromApi = await ItemsApi().getAllItemsromApi();
  //   notifyListeners();
  // }

}
