import 'package:flutter/cupertino.dart';
import 'package:mandoboct/General/Models/ServiceModel.dart';
import 'package:mandoboct/General/Network/API/ServicesApi.dart';

class ServiceProvider extends ChangeNotifier {
  List<ServiceModel> _servicesByParent = [];
  List<ServiceModel> get services => _servicesByParent;
  List<ServiceModel> _servicesByCategory = [];
  List<ServiceModel> get servicesByCategory => _servicesByCategory;
  ServicesApi _servicesApi = ServicesApi();

  Future<void> getServicesByCategory(int categoryId) async {
    _servicesByCategory =
        await _servicesApi.getServicesByCategoryFromApi(categoryId);
    filterByCategory(categoryId);

    print("_servicesByCategory.length${_servicesByCategory.length}");
    print("serNames.length ${serNames.length}");
    notifyListeners();
  }

  Future<void> getServicesBypaernt(int parentId) async {
    _servicesByParent = await _servicesApi.getServicesByParentFromApi(parentId);
    notifyListeners();
  }

  ///////////////////////   get services    ///////////////////////////
  List<ServiceModel> _allServices = [];
  List<ServiceModel> get allServices => _allServices;
  List<String> _servicesNames = [];
  List<String> get servicesNames => _servicesNames;
  String? _serviceName;
  String? get serviceName => _serviceName;
  int? _serviceId;
  int? get serviceId => _serviceId;
  Future<void> getAllServices(int categoryId) async {
    _allServices = await _servicesApi.getAllServicesFromApi();
    // fillNames();
    filterByCategory(categoryId);
    notifyListeners();
  }

  // fillNames() {
  //   for (var service in _allServices) {
  //     _servicesNames.add(service.servicesName!);
  //   }
  // }

  List<ServiceModel> servicesNamesByCategory = [];
  List<String> serNames = [];
  filterByCategory(int id) {
    servicesNamesByCategory = [];
    serNames = [];
    servicesNamesByCategory =
        _allServices.where((element) => element.categoriesId == id).toList();
    servicesNamesByCategory.removeWhere((element) => element.isParent == 1);
    // print('//////${servicesNamesByCategory.length}');
    for (var service in servicesNamesByCategory) {
      serNames.add(service.servicesName!);
    }
  }

  int getServiceId(String name) {
    var itemId =
        _allServices.indexWhere((element) => element.servicesName == name);
    print("item $itemId");
    return itemId;
  }

  changeDropDownValue(String value) {
    _serviceName = value;
    _serviceId = _allServices[getServiceId(value)].servicesId;
    print(_serviceId);
    notifyListeners();
  }
}
