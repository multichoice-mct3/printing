import '../Http.dart';
import '../../models/SuppliersModel.dart';

class SuppliersAPI {
  HttpMethods _http = HttpMethods();
  Future<List<SuppliersModel>> getSuppliersFromApi() async {
    List<SuppliersModel> suppliers = [];
    var _data = await _http.getData(url: "suppliers");
    if (_data != null) {
      List<Map<String, dynamic>> _suppliersJson =
          List<Map<String, dynamic>>.from(_data);
      suppliers = _suppliersJson
          .map((supplier) => SuppliersModel.fromJson(supplier))
          .toList();
      return suppliers;
    }

    return suppliers;
  }
}
