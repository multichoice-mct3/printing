import 'package:agrofad/api/Approved_refused_agentRoutes_api.dart';
import 'package:agrofad/custom_widgets/custom_dialoge.dart';
import 'package:agrofad/models/route_model.dart';
import 'package:agrofad/provider_services/agentRouts_provider.dart';
import 'package:agrofad/provider_services/user_Detail_provider.dart';
import 'package:agrofad/provider_services/user_Detail_provider.dart';
import 'package:awesome_loader/awesome_loader.dart';
import 'package:flutter/material.dart';
import 'package:async/async.dart';
import 'package:provider/provider.dart';
import '../AgrofadMainScreen.dart';
import '../constants.dart';
class EmpRoutes extends StatelessWidget {
  static String id='EmpRoutes';
  final memoizedFuture = AsyncMemoizer();
  SendAgentRouteStatusApi _agentRouteStatusApi=SendAgentRouteStatusApi();
  bool done;
  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    final UserDet = Provider.of<UserDetail>(context);
    print(UserDet.GetEmpId);
    return SafeArea(
      child: FutureBuilder(
        future: memoizedFuture.runOnce(
              () => Provider.of<AgentRoutsProvider>(context).getEmpRoutes(UserDet.GetEmpId),
                                       ),
        builder: (BuildContext Context, AsyncSnapshot snapshot) {
          return Scaffold(
              backgroundColor:
              snapshot.connectionState == ConnectionState.waiting
                  ? Colors.white
                  : KmainColor,
              body: () {
                if (snapshot.connectionState == ConnectionState.done &&
                    snapshot.hasData) {
                  // List<VacOrder> vacs = snapshot.data;
                  return Consumer<AgentRoutsProvider>(
                    builder: (ctx, AgentRoutes, ch) {
                      List<AgentVisitRouteModel> Routes = AgentRoutes.GetEmpRoutesByEmp;
                      return Column(
                        children: [
                          FirstContainer(ScreenWidth, ctx),
                          Expanded(
                            child: ListView.builder(
                              itemCount: Routes.length,
                              itemBuilder: (ctx, int index) {
                                return Card(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    child: Column(
                                      children: [
                                        Row(
                                          textDirection: TextDirection.rtl,
                                          children: [
                                            Expanded(
                                              flex:2,
                                              child: Row(
                                                textDirection:
                                                TextDirection.rtl,
                                                children: [
                                                  Text(
                                                    '   : التاريخ',
                                                    style: TextStyle(
                                                        fontFamily: 'cocon',
                                                        color: KmainColor,
                                                        fontWeight:
                                                        FontWeight.bold,
                                                        fontSize: 16),
                                                  ),
                                                  Text(
                                                   Routes[index].AVRDate,
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                      fontFamily: 'cocon',
                                                      color: KmainColor,
                                                      fontSize: 15,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                              flex: 3,
                                              child: Row(
                                                textDirection:
                                                TextDirection.rtl,
                                                children: [
                                                  Text(
                                                    '  : الزيارة ',
                                                    textAlign: TextAlign.end,
                                                    style: TextStyle(
                                                        fontFamily: 'cocon',
                                                        color: KmainColor,
                                                        fontWeight:
                                                        FontWeight.bold,
                                                        fontSize: 16),
                                                  ),
                                                  Text(
                                                  Routes[index].AVCName,
                                                    textAlign: TextAlign.end,
                                                    style: TextStyle(
                                                      fontFamily: 'cocon',
                                                      color: KmainColor,
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          textDirection: TextDirection.rtl,
                                          children: [
                                            Row(
                                              textDirection: TextDirection.rtl,
                                              children: [
                                                Text(
                                                  '   :العميل',
                                                  style: TextStyle(
                                                      fontFamily: 'cocon',
                                                      color: KmainColor,
                                                      fontWeight:
                                                      FontWeight.bold,
                                                      fontSize: 16),
                                                ),
                                                Text(
                                                Routes[index].CustomerName,
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontFamily: 'cocon',
                                                    color: KmainColor,
                                                    fontSize: 15,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        Routes[index].EmpId!=UserDet.GetEmpId? Row(
                                          textDirection: TextDirection.rtl,
                                          children: [
                                            Row(
                                              textDirection: TextDirection.rtl,
                                              children: [
                                                Text(
                                                  '   :الموظف',
                                                  style: TextStyle(
                                                      fontFamily: 'cocon',
                                                      color: KmainColor,
                                                      fontWeight:
                                                      FontWeight.bold,
                                                      fontSize: 16),
                                                ),
                                                Text(
                                                  Routes[index].EmpName,
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontFamily: 'cocon',
                                                    color: KmainColor,
                                                    fontSize: 15,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ):Container(),
                                        Row(
                                          textDirection: TextDirection.rtl,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              '   :الملاحظات',
                                              style: TextStyle(
                                                  fontFamily: 'cocon',
                                                  color: KmainColor,
                                                  fontWeight:
                                                  FontWeight.bold,
                                                  fontSize: 16),
                                            ),
                                            Container(
                                              width: ScreenWidth * .75,
                                              child: Text(
                                                Routes[index].ManualCauseNote!='' &&Routes[index].ManualCauseNote!=null? Routes[index].ManualCauseNote:'لم يتم ادخال اي ملاحظات',
                                                textAlign: TextAlign.end,
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                 fontFamily: 'cocon',
                                                  color: KmainColor,
                                                  fontSize: 15,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),

                                        Routes[index].EmpId==UserDet.GetEmpId?Row(
                                          textDirection:
                                          TextDirection.rtl,
                                          children: [
                                            Expanded(
                                              child: MaterialButton(
                                                onPressed: () async {
                                                  _openshowModalBottomSheet(context, ScreenWidth,'Completed',Routes[index],UserDet.GetEmpId,index);
                                                },
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                    BorderRadius
                                                        .circular(
                                                        10)),
                                                child: Text(
                                                  'اتممت الزيارة',
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontWeight:
                                                    FontWeight.bold,
                                                    fontFamily: 'cocon',
                                                  ),
                                                ),
                                                color: KmainColor,
                                              ),
                                            ),
                                            SizedBox(
                                              width: 50,
                                            ),
                                            Expanded(
                                                child: RaisedButton(
                                                  onPressed: () async {
                                                    _openshowModalBottomSheet(context, ScreenWidth,'EmpCancel',Routes[index],UserDet.GetEmpId,index);
                                                  },
                                                  shape:
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                      BorderRadius
                                                          .circular(
                                                          10)),
                                                  child: Text(
                                                    'رفض',
                                                    style: TextStyle(
                                                      fontSize: 12,
                                                      color: Colors.white,
                                                      fontWeight:
                                                      FontWeight.bold,
                                                      fontFamily: 'cocon',
                                                    ),
                                                  ),
                                                  color: Colors.red,
                                                ))
                                          ],
                                        ):
                                        Row(
                                          textDirection:
                                          TextDirection.ltr,
                                          children: [
                                            Container(
                                              width: ScreenWidth *.4,
                                                child: RaisedButton(
                                                  onPressed: () async {
                                                    _openshowModalBottomSheet(context, ScreenWidth,'ManagerCancel',Routes[index],UserDet.GetEmpId,index);
                                                  },
                                                  shape:
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                      BorderRadius
                                                          .circular(
                                                          10)),
                                                     child: Text(
                                                     'رفض',
                                                      style: TextStyle(
                                                      fontSize: 12,
                                                      color: Colors.white,
                                                      fontWeight:
                                                      FontWeight.bold,
                                                      fontFamily: 'cocon',
                                                    ),
                                                  ),
                                                   color: Colors.red,
                                                   ))
                                                 ],
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          )
                        ],
                      );
                    },
                  );
                } else if (snapshot.hasError)
                  return Text('Error: ${snapshot.error}');
                else {
                  return Center(
                      child: Container(
                        height: 30,
                        width: 30,
                        child: AwesomeLoader(
                          loaderType: AwesomeLoader.AwesomeLoader3,
                          color: KmainColor,
                        ),
                      ));
                }
              }());
        },
      ),
    );
  }


  Widget FirstContainer(double ScreenWidth,BuildContext context) {
    return Column(
      children: [
        Container(
          width: ScreenWidth,
          height: 40,
          color: OfWhiteColor,
          child: Padding(
            padding: const EdgeInsets.only(right: 25),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'مسارات مندوب',
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: KmainColor,
                    fontSize: 22,
                    fontFamily: 'cocon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 15, top: 3),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)),
                    color: Colors.amber,
                    onPressed: () async {
                      //   Navigator.(context);
                      Navigator.pushNamed(context, AgrofadMainScreen.id);
                    },
                    child: Text(
                      'رجوع',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'cocon',
                          fontSize: 18),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
        SizedBox(height: 10,)
      ],
    );
  }

  Future _openshowModalBottomSheet(BuildContext ctx, double ScreenWidth,String Type, AgentVisitRouteModel Route,int EmpId,int index) async {
    return await showModalBottomSheet(
        context: ctx,
        isScrollControlled: true,
        enableDrag: true,
        isDismissible: true,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(25.0))),
        builder: (BuildContext context) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Padding(
              padding: MediaQuery.of(context).viewInsets,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          Type=='Completed' ?'نتيجة الزيارة' :'سبب الالغاء',
                          style: TextStyle(
                              fontFamily: 'cocon',
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: KmainColor),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  RNotes(ScreenWidth,context),
                  SizedBox(
                    height: 10,
                  ),
                  Consumer<AgentRoutsProvider>(
                    builder: (ctx,RouteProvider,ch){
                      return InkWell(
                        onTap: () async {
                          if (RouteProvider.GetRouteResult !=null){

                              done=await _agentRouteStatusApi.SendAgentRouteStatus(
                                  AvrId: Route.AVRId,
                                  Type:Type,
                                  EmpId: EmpId ,
                                manualResultNote: RouteProvider.GetRouteResult
                                                                                    );
                              if (done){
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return CustomDialoge(
                                        Anothercontext: context,
                                        Message:    Type=='Completed'? 'تم حفظ نتيجة الزيارة ':'تم الالغاءوحفظ السبب ',
                                        Callback: () {
                                          RouteProvider.removeFromEmpRoutes(index);
                                          RouteProvider.changeRouteResult(null);
                                         // Navigator.popAndPushNamed(context, EmpRoutes.id);
                                          Navigator.pop(context);
                                          Navigator.pop(context);
                                        },
                                      );
                                    }

                                );
                                    }
                              else{
                                showDialog(
                                    context: context,
                                    builder: (BuildContext
                                    context) {
                                      return CustomDialoge(
                                        Anothercontext: context,
                                        Message:Type=='Completed'?
                                        'لم يتم حفظ نتيجة الزيارة ':'لم يتم حفظ سبب الالغاء',
                                        Callback:
                                            () {
                                          Navigator.of(
                                              context)
                                              .pop();
                                        },
                                      );
                                    });
                              }


                            }

                          else {
                            showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return Dialog(
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            20.0)), //this right here
                                    child: Container(
                                      height: 120,
                                      child: Padding(
                                        padding: const EdgeInsets.all(20.0),
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Align(
                                              alignment: AlignmentDirectional.topEnd,
                                              child: Text(
                                                Type=='Completed'? 'يجب ادخال نتيجة الزيارة ':'يجب ادخال سبب الالغاء',
                                                style: TextStyle(
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                  fontFamily: 'cocon',
                                                  color: KmainColor,
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 100.0,
                                              child: RaisedButton(
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  },
                                                  child: Text(
                                                    "اغلاق",
                                                    style:
                                                    TextStyle(color: Colors.white),
                                                  ),
                                                  color: KmainColor),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                });
                          }

                        },
                        child: Container(
                          height: 40,
                          width: ScreenWidth / 4,
                          decoration: BoxDecoration(
                            color: KmainColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Text(
                              'اضافة',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontFamily: 'cocon',
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      );
                    },

                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
          );
        });
  }

  Widget RNotes(double ScreenWidth,BuildContext context) {
    return Row(
      textDirection: TextDirection.rtl,
      children: [
        Container(
          width: 85 / 100 * ScreenWidth,
          margin: EdgeInsets.symmetric(horizontal: 15),
          child: TextField(
            textAlign: TextAlign.end,
            cursorColor: KmainColor,
            // controller: RoutNotes,
            maxLines: 2,
            onChanged: (value){
              // RoutNotes.text=value;
              Provider.of<AgentRoutsProvider>(context,listen: false).changeRouteResult(value);
            },
            style: TextStyle(color: KmainColor, fontSize: 14),
            decoration: InputDecoration(
              filled: true,
              fillColor: WhiteColor,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: KmainColor, width: 2)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: KmainColor, width: 2)),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: KmainColor, width: 2)),
              //labelText: 'البيان',
              hintText: 'الملاحظات',
              hintStyle: TextStyle(color: KmainColor, fontSize: 15),
              alignLabelWithHint: false,
            ),
            keyboardType: TextInputType.multiline,
          ),
        ),
      ],
    );
  }
}
