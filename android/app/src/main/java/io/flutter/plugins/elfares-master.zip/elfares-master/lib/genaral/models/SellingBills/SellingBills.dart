import 'package:elfares/genaral/models/BillItemModel.dart';
import 'package:json_annotation/json_annotation.dart';
part 'SellingBills.g.dart';

@JsonSerializable(explicitToJson: true)
class SellingBill {
  @JsonKey(name: "SellingID")
  int? id;
  @JsonKey(name: "'SellingDate'")
  String? date;
  @JsonKey(name: "SellingType")
  String? type;
  @JsonKey(name: "CustomerId")
  int? customerId;
  @JsonKey(name: "CustomerName")
  String? customerName;
  @JsonKey(name: "SellingDisc")
  double? discount;
  @JsonKey(name: "SellingTot")
  double? total;
  @JsonKey(name: "SellingVal")
  double? sellingValue;
  @JsonKey(name: "'saleInvItems'")
  List<BillItemModel>? items;
  @JsonKey(name: "EntryUserId")
  int? entryUserId;
  @JsonKey(name: "EntryUserDate")
  String? entryUserDate;
  SellingBill({
    this.customerId,
    this.customerName,
    this.date,
    this.discount,
    this.entryUserDate,
    this.entryUserId,
    this.id,
    this.items,
    this.sellingValue,
    this.total,
    this.type,
  });
  factory SellingBill.fromJson(Map<String, dynamic> json) =>
      _$SellingBillFromJson(json);
  Map<String, dynamic> toJson() => _$SellingBillToJson(this);
}
