import 'package:flutter/cupertino.dart';
import '../models/StoresModel.dart';
import '../network/API/StoresAPI.dart';

class StoresProvider extends ChangeNotifier {
  StoresApi _api = StoresApi();
  List<Stores> _stores = [];
  List<Stores> get suppliers => _stores;
  List<String> _storesNames = [];
  List<String> get storesNames => _storesNames;
  int? _storeId;
  int get storeId => _storeId!;
  String? storeName;
  Future<void> getStores() async {
    _stores = await _api.getStoresFromApi();
    print("_stores.length ${_stores.length}");
    fillNames();
    notifyListeners();
  }

  fillNames() {
    for (var emp in _stores) {
      _storesNames.add(emp.storeName!);
    }
  }

  changeSupplierName(String newValue) {
    storeName = newValue;
    getSupplierId(newValue);
    notifyListeners();
  }

  getSupplierId(String name) {
    int supId = _stores.indexWhere((element) => element.storeId == name);
    _storeId = _stores[supId].storeId;
  }
}
