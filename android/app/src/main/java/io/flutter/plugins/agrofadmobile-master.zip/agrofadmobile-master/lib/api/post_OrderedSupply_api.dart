import 'dart:convert';

import 'package:agrofad/models/AddOrderedSupply_model.dart';
import 'package:http/http.dart' as http;

import 'login_apis.dart';



class OredredSupplyApi {
  LoginApi loginApi = new LoginApi();
  String BaseUrl = 'http://104.196.134.107/AfitAPI/api';
  bool Posted;

  Future<bool> GetDataFromModel(OrderedSupplyModel orderedSupply) async {
    Map<String, dynamic> Orderdet = orderedSupply.toJson();
    String RequestOrderJsonData = jsonEncode(Orderdet);
    print(RequestOrderJsonData);
    await loginApi.getAccessToken();
    print('${loginApi.token}');
    Map Headers = <String, String>{
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var Response = await http.post(
        'http://104.196.134.107/AfitAPI/api/RequestOrders',
        body: RequestOrderJsonData,
        headers: Headers);
    if (Response.statusCode == 201 ||Response.statusCode == 200 ) {
      print(Response.statusCode);
      var PostResult = jsonDecode(Response.body);
      Posted = true;
      print(PostResult);
    } else {
      print(Response.statusCode);
      var PostResult = jsonDecode(Response.body);
      Posted = false;
      print(PostResult);
    }

    return Posted;
  }
}
