import 'package:easy_localization/easy_localization.dart';
import 'package:elfares/genaral/network/API/Authentication.dart';
import 'package:elfares/genaral/utilities/CachHelper.dart';
import 'package:elfares/genaral/utilities/GlobalState.dart';
import 'package:elfares/user/Home.dart';

import 'package:flutter/material.dart';
import 'package:elfares/genaral/Constants/MyRoute.dart';
import 'package:elfares/genaral/Constants/MyToast.dart';

class AuthProvider extends ChangeNotifier {
  bool isAuth = false;
  Authentication _authentication = Authentication();

  Future<void> login(
      String userName, String password, BuildContext context) async {
    changeAuthState();
    _authentication.login(userName, password).then((value) {
      if (value.userId != null) {
        GlobalState.instance.set('userId', value.userId);
        CachHelper.saveData(key: 'userId', value: value.userId);
        changeAuthState();
        MyToast().showToast('تم تسجيل الدخول بنجاح', Colors.green);
        MyRoute().navigateAndRemove(context: context, route: Home());
      } else {
        changeAuthState();
        MyToast().showToast(tr("loginError"), Colors.red);
      }
    });
    notifyListeners();
  }

  changeAuthState() {
    isAuth = !isAuth;
    notifyListeners();
  }
}
