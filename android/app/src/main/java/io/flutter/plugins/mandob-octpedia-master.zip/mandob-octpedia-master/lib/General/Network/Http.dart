import 'dart:convert';

// ignore: import_of_legacy_library_into_null_safe
import 'package:http/http.dart' as http;

class HttpMethods {
  String? token;
  String baseUrl = "http://minicodeco-001-site11.etempurl.com/api/";

  Map<String, String> normalHeaders = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  };

  Future<dynamic> getData({required String url}) async {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer $token',
    };
    var response = await http.get(Uri.parse("$baseUrl/$url"), headers: headers);
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      return data;
    } else {
      print("bad request ${response.statusCode} at $url");
    }
  }

  Future<String> postData(
      {required String url,
      dynamic body,
      Map<String, String>? authHeaders}) async {
    var response = await http.post(Uri.parse("$baseUrl$url"),
        body: body,
        headers: authHeaders ??
            {
              'Content-Type': 'application/json;charset=UTF-8',
              'Accept': 'application/json',
              // 'Authorization': 'bearer $token',
            });
    print("$baseUrl$url");
    if (response.statusCode == 200 || response.statusCode == 201) {
      var data = json.decode(response.body);
      print(data);
      return "تمت الإضافة";
    } else {
      print("bad request ${response.statusCode}at $url");
      var errorData = response.body;
      print(errorData);
      return "فشلت الإضافة .. يرجى مراجعة البيانات والمحاولة لاحقاً";
    }
  }

  putData({required String url, Map<String, dynamic>? body}) async {
    var response =
        await http.put(Uri.parse("$baseUrl/$url"), body: body, headers: {
      // 'Content-Type': 'application/json',
      // 'Accept': 'application/json',
      'Authorization': 'bearer $token',
    });
    if (response.statusCode == 200 || response.statusCode == 201) {
      var data = json.decode(response.body);
      print(data);
      return data;
    } else {
      print("bad request ${response.statusCode}at $url");
    }
  }
}
