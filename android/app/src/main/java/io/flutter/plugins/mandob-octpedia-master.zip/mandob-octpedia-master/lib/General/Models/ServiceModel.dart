class ServiceModel {
  int? servicesId;
  String? servicesName;
  int? servicesParantId;
  String? servicesParantName;
  String? servicesIcon;
  int? categoriesId;
  String? categoriesName;
  int? isParent;
  ServiceModel(
      {this.servicesId,
      this.servicesName,
      this.servicesParantId,
      this.servicesParantName,
      this.servicesIcon,
      this.categoriesId,
      this.isParent,
      this.categoriesName});

  ServiceModel.fromJson(Map<String, dynamic> json) {
    servicesId = json['servicesId'];
    servicesName = json['servicesName'];
    servicesParantId = json['servicesParantId'];
    servicesParantName = json['servicesParantName'];
    servicesIcon = json['servicesIcon'];
    categoriesId = json['categoriesId'];
    categoriesName = json['categoriesName'];
    isParent = json['isParant'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['servicesId'] = this.servicesId;
    data['servicesName'] = this.servicesName;
    data['servicesParantId'] = this.servicesParantId;
    data['servicesParantName'] = this.servicesParantName;
    data['servicesIcon'] = this.servicesIcon;
    data['categoriesId'] = this.categoriesId;
    data['categoriesName'] = this.categoriesName;
    return data;
  }
}
