part of "HomeImports.dart";

class PaymentVoucher extends StatelessWidget {
  const PaymentVoucher({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String? value;
    return ItemsMainScreen(
      title: "سند قبض",
      content: Column(
        children: [
          IndexAndDate(),
          SizedBox(height: 10),
          Row(
            children: [
              Flexible(
                child: LabelTextField(
                  label: "الرقم",
                  isPassword: false,
                ),
              ),
              SizedBox(width: SizeConfig.screenWidth! * .1),
              Flexible(
                child: LabelTextField(
                  label: "المبلغ",
                  isPassword: false,
                ),
              ),
            ],
          ),
          CustomDropDown(
            hint: "اختر الحساب",
            items: [],
            value: value,
            onChange: (value) => print("object"),
          ),
          const SizedBox(height: 10),
          CustomDropDown(
            hint: "اختر الخزينة",
            items: [],
            value: value,
            onChange: (value) => print("object"),
          ),
          const SizedBox(height: 10),
          NotesTextField(notes: TextEditingController()),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              MyElevatedButton(
                  onPressed: () => print("object"), title: "حفظ السند"),
              MyElevatedButton(
                  onPressed: () => print("object"), title: "عرض السندات"),
            ],
          )
        ],
      ),
    );
  }
}
