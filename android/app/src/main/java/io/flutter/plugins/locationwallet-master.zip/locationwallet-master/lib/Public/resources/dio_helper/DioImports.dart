import 'dart:convert';
import 'dart:io';
import 'package:LocarionWallet/Constants/CachHelper.dart';
import 'package:LocarionWallet/Constants/GlobalState.dart';
import 'package:LocarionWallet/Constants/LoadingDialog.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:auto_route/auto_route.dart';
import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';


part 'DioHelper.dart';


