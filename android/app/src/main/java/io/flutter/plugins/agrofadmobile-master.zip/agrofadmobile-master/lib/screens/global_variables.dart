library global_variables.globals;
String UserType = 'ADMIN';