part of "HomeImports.dart";

class SellingBills extends StatelessWidget {
  const SellingBills({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String? value;
    String? value1;
    return ItemsMainScreen(
      title: "فواتير البيع",
      content: Column(
        children: [
          CustomersDropdown(),
          const SizedBox(height: 10),
          DatePickerRow(value: value, value1: value1),
          const SizedBox(height: 10),
          MyElevatedButton(onPressed: () => print("tapped"), title: "عرض"),
        ],
      ),
    );
  }
}
