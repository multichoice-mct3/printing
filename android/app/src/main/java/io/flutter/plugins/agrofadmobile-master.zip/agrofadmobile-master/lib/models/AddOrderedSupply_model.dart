import 'AddItem_model.dart';
import 'package:intl/intl.dart' as intl;
class OrderedSupplyModel {
  int RequestOrderID;
  String RequestOrderDate ;
  int CustomerId;
  String CustomerName;
  int EmpID;
  String EmpName;
  String IsApproved;
  List<AddItemModel> RequestOrderDet;

  OrderedSupplyModel({
    this.RequestOrderID,
    this.RequestOrderDate ,
    this.CustomerId,
    this.CustomerName,
    this.EmpID,
    this.EmpName,
    this.IsApproved,
    this.RequestOrderDet
  });
     factory OrderedSupplyModel.fromJson(Map<String,dynamic>RequstedOrder){
      // List<AddItemModel> Items;
       String FormatedDate= (RequstedOrder['RequestOrderDate']).substring(0,10);
   return OrderedSupplyModel(
       RequestOrderID: RequstedOrder['RequestOrderID'],
     CustomerId: RequstedOrder['CustomerId'],
     CustomerName: RequstedOrder['CustomerName'],
     EmpID: RequstedOrder['EmpID'],
     EmpName: RequstedOrder['EmpName'],
     IsApproved: RequstedOrder['IsApproved'],
     RequestOrderDate:  FormatedDate,
   //   RequestOrderDet: RequstedOrder['requestOrderDet']==null?null:
                              );
     }
  static  OrderedSupplyModel GetRequstOrderDetail(Map<String,dynamic>RequstedOrder){

    String FormatedDate= (RequstedOrder['RequestOrderDate']).substring(0,10);
    return OrderedSupplyModel(
      RequestOrderID: RequstedOrder['RequestOrderID'],
      CustomerId: RequstedOrder['CustomerId'],
      CustomerName: RequstedOrder['CustomerName'],
        EmpID: RequstedOrder['EmpID'],
      EmpName: RequstedOrder['EmpName'],
      IsApproved: RequstedOrder['IsApproved'],
      RequestOrderDate:  FormatedDate,
        RequestOrderDet:ParsedItemsFromJson(RequstedOrder['requestOrderDet'])
    );
  }

  Map<String, dynamic> toJson(){
        return {
               'RequestOrderID':-1,
               'RequestOrderDate':RequestOrderDate ,
               'CustomerId':CustomerId,
               'CustomerName':CustomerName,
               'IsApproved':IsApproved,
               'EmpID':EmpID,
               'EmpName':EmpName,
               'requestOrderDet':ParsedOrderdItemsToJson(),
        };
  }
  List<Map> ParsedOrderdItemsToJson( ){
   // AddItemModel itemModel=new AddItemModel();
    List<Map>Items=[];
    for(AddItemModel itemModel in RequestOrderDet ){
      Items.add(itemModel.toJson());
    }
    return Items;

  }

  static List<AddItemModel> ParsedItemsFromJson(List  objs ){
       print(objs);
  return objs.map<AddItemModel>((json) => AddItemModel.FromJson(json)).toList();

  }

}
