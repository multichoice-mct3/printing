class StationModel {
  String? stationsName;
  int? trafficLinesId;
  String? trafficLinesName;
  double? stationsPrice;

  StationModel(
      {this.stationsName,
      this.trafficLinesId,
      this.trafficLinesName,
      this.stationsPrice});

  StationModel.fromJson(Map<String, dynamic> json) {
    stationsName = json['stationsName'];
    trafficLinesId = json['trafficLinesId'];
    trafficLinesName = json['trafficLinesName'];
    stationsPrice = json['stationsPrice'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['stationsName'] = this.stationsName;
    data['trafficLinesId'] = this.trafficLinesId;
    data['trafficLinesName'] = this.trafficLinesName;
    data['stationsPrice'] = this.stationsPrice;
    return data;
  }
}
