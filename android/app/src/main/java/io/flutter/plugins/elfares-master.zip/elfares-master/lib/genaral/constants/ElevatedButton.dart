import 'package:elfares/genaral/utilities/SizeConfig.dart';
import 'package:flutter/material.dart';
import 'MyColors.dart';
import 'MyText.dart';

class MyElevatedButton extends StatelessWidget {
  const MyElevatedButton({
    Key? key,
    required this.onPressed,
    required this.title,
    this.size,
  }) : super(key: key);
  final String title;
  final Function onPressed;
  final Size? size;
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () => onPressed(),
      child: MyText(
        title: title,
        color: MyColors.secondary,
        size: 12,
      ),
      style: ElevatedButton.styleFrom(
        fixedSize: size ??
            Size(SizeConfig.screenWidth! * .4, SizeConfig.screenHeight! * .06),
        primary: MyColors.white,
        shape: RoundedRectangleBorder(
          side: BorderSide(color: MyColors.secondary, width: 1.5),
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}
