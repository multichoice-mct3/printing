
class AccountDetModel {
  String AccountId;
  String FromDate;
  String ToDate;

  AccountDetModel({this.AccountId, this.FromDate, this.ToDate});

  Map<String, dynamic> toJson (){
    return {
      'ACCOUNTID':this.AccountId,
      'FromDate':this.FromDate,
      'ToDate':this.ToDate
    };
  }


}