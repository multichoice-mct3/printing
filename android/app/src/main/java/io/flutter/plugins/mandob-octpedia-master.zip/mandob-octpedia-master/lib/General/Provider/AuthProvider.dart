import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
import 'package:mandoboct/DesktopHomeScreen.dart';
import 'package:mandoboct/General/Constants/MyRoute.dart';
import 'package:mandoboct/General/Constants/MyToast.dart';
import 'package:mandoboct/General/Network/API/Authentication.dart';
import 'package:mandoboct/MobileHomeScreen.dart';

class AuthProvider extends ChangeNotifier {
  bool isAuth = false;
  Authentication _authentication = Authentication();

  Future<void> login(
      String userName, String password, BuildContext context) async {
    changeAuthState();
    _authentication.login(userName, password).then((value) {
      if (value) {
        changeAuthState();
        MyToast().showToast(tr("loginSuccess"), Colors.green);
        if (Platform.isAndroid || Platform.isIOS) {
          MyRoute().navigateAndRemove(context: context, route: MobileHome());
        } else {
          MyRoute().navigateAndRemove(context: context, route: DesktopHome());
        }
      } else {
        changeAuthState();
        MyToast().showToast(tr("loginError"), Colors.red);
      }
    });
    notifyListeners();
  }

  changeAuthState() {
    isAuth = !isAuth;
    notifyListeners();
  }
}
