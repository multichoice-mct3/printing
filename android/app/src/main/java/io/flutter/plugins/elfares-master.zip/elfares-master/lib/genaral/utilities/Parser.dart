import 'package:elfares/genaral/utilities/InterfaceParse.dart';

class MyParser {
  ay7aga(String tex, Parse parse) {
    parse.send(tex);
  }

  // final Function<T>(Map<String, dynamic> json) fromJson;
  // List<T> _modelList = [];
  // List<T> parseToModel(List<dynamic> data, T t) {
  //   List<Map<String, dynamic>> _json = List<Map<String, dynamic>>.from(data);
  //   _modelList = _json.map((e) => fromJson(e)).toList();
  //   print("-----------${_modelList.first}");

  //   return _modelList;
  // }
}
