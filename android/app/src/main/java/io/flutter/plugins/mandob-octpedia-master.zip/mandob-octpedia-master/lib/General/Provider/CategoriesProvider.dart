import 'package:flutter/cupertino.dart';
import 'package:mandoboct/General/Models/CategoryModel.dart';
import 'package:mandoboct/General/Network/API/CatergoriesAPI.dart';

class CategoriesProvider extends ChangeNotifier {
  CategoriesAPI _categoriesFromApi = CategoriesAPI();
  List<Category> _categories = [];
  List<String> _categoriesNames = [];
  List<String> get categoriesNames => _categoriesNames;
  List<Category> get categories => _categories;
  String? _categoryName;
  String? get categoryName => _categoryName;
  int? _categoryId;
  int? get categoryId => _categoryId;

  getCategories() async {
    _categories = await _categoriesFromApi.getCategoriesFromApi();
    fillNames();
    print("_categoriesNames.length ${_categoriesNames.length}");
    notifyListeners();
  }

  fillNames() {
    for (var category in _categories) {
      _categoriesNames.add(category.categoriesName!);
    }
  }

  getCategoryId(String name) {
    int itemId =
        _categories.indexWhere((element) => element.categoriesName == name);
    _categoryId = _categories[itemId].categoriesId;
  }

  changeDropDownValue(String value) {
    _categoryName = value;
    getCategoryId(value);
    print(_categoryId);
    notifyListeners();
  }
}
