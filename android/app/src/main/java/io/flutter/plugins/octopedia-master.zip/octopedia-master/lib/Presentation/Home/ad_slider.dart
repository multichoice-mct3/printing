import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:octpedia/App/Utilities/size_config.dart';
import 'package:octpedia/Presentation/Resources/color_manager.dart';
import 'package:octpedia/Presentation/Resources/values_manager.dart';

class AdsSlider extends StatelessWidget {
  const AdsSlider({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // context.read<AdProvider>().getAds();
    return CarouselSlider(
      options: CarouselOptions(
          disableCenter: true,
          height: SizeConfig.screenHeight! * .18,
          autoPlay: true,
          enlargeCenterPage: true),
      items: List.generate(
          ads.length,
          (index) => InkWell(
                onTap: () async {
                  // LoadingDialog.showLoadingDialog();
                  // await context
                  //     .read<ProjectProviders>()
                  //     .getSpecificProvider(ads[index].providesId!);
                  // print(context
                  //     .read<ProjectProviders>()
                  //     .specificProvider
                  //     .providesName);
                  // MyRoute().navigate(
                  //     context: context, route: DetailsIntroScreen());
                },
                child: Container(
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  width: MediaQuery.of(context).size.width,
                  margin: const EdgeInsets.symmetric(
                      horizontal: AppMargin.m8, vertical: AppMargin.m12),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: ColorManager.darkGrey),
                  child: CachedNetworkImage(
                    imageUrl: ads[index],
                    fit: BoxFit.fill,
                    progressIndicatorBuilder:
                        (context, url, downloadProgress) => Center(
                      child: CircularProgressIndicator(
                          value: downloadProgress.progress),
                    ),
                    errorWidget: (context, url, error) =>
                        const Icon(Icons.error),
                  ),
                ),
              )),
    );
  }
}

List<String> ads = [
  'https://themarketingbirds.com/wp-content/uploads/2018/09/coka.jpg',
  'https://www.cantechonline.com/wp-content/uploads/coca-cola-recycle.jpg',
  'https://www.inma.org/files/images/blogs/feature_photos/print_september20_hannah_2020-in-ads-1800.jpg'
];
