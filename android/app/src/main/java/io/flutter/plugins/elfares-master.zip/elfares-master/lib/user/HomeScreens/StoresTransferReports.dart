part of "HomeImports.dart";

class StoresTransferReports extends StatelessWidget {
  const StoresTransferReports({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ItemsMainScreen(
      title: "تقرير اذونات التحويل",
      content: Column(
        children: [
          IndexAndDate(),
        ],
      ),
    );
  }
}
