import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:mandoboct/General/Constants/DefaultButton.dart';
import 'package:mandoboct/General/Constants/IconTextFiled.dart';
import 'package:mandoboct/General/Constants/MyColors.dart';
import 'package:mandoboct/General/Constants/MyText.dart';
import 'package:mandoboct/General/Provider/AuthProvider.dart';
import 'package:mandoboct/General/Utilities/CachHelper.dart';
import 'package:mandoboct/General/Utilities/SizeConfig.dart';
import 'package:mandoboct/General/Utilities/Validator.dart';

import 'package:provider/provider.dart';

import 'AuthMainScreen.dart';

class LoginContent extends StatefulWidget {
  LoginContent({Key? key}) : super(key: key);

  @override
  _LoginContentState createState() => _LoginContentState();
}

class _LoginContentState extends State<LoginContent> {
  final TextEditingController _userName = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return AuthScreen(
        content: Column(
      children: [
        Expanded(
            child: SizedBox(
              child: Container(
                padding: const EdgeInsets.only(top: 50, right: 15),
                width: double.infinity,
                decoration: BoxDecoration(color: MyColors.primary, boxShadow: [
                  BoxShadow(
                      color: MyColors.secondary.withOpacity(.7),
                      offset: Offset(2, 0),
                      blurRadius: 10,
                      spreadRadius: 5)
                ]),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    MyText(
                      title: "مرحباً بعودتك !",
                      size: 14,
                      color: MyColors.white,
                    ),
                    Divider(
                        thickness: 3,
                        color: Colors.white,
                        endIndent: SizeConfig.screenWidth! * .75),
                    MyText(title: tr("pleaseLogin"), color: MyColors.white),
                  ],
                ),
              ),
            ),
            flex: 2),
        Form(
          key: _formKey,
          child: Expanded(
            flex: 5,
            child: Container(
              color: MyColors.primary,
              child: Container(
                decoration: BoxDecoration(
                    color: MyColors.white,
                    borderRadius:
                        BorderRadius.only(topRight: Radius.circular(30))),
                padding: const EdgeInsets.fromLTRB(20, 15, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    IconTextFiled(
                      controller: _userName,
                      margin: const EdgeInsets.symmetric(vertical: 10),
                      label: tr("userName"),
                      isPassword: false,
                      icon: Icon(Icons.person),
                      validate: (value) =>
                          Validator().validateEmpty(value: value),
                    ),
                    IconTextFiled(
                      controller: _password,
                      margin: const EdgeInsets.symmetric(vertical: 10),
                      label: tr("pass"),
                      isPassword: true,
                      icon: Icon(Icons.lock),
                      validate: (value) =>
                          Validator().validateEmpty(value: value),
                    ),
                    Consumer<AuthProvider>(
                      builder: (context, auth, child) => DefaultButton(
                        color: MyColors.primary,
                        child: auth.isAuth
                            ? CircularProgressIndicator(
                                valueColor:
                                    AlwaysStoppedAnimation(Colors.white))
                            : MyText(
                                title: tr("login"),
                                size: 16,
                                color: Colors.white,
                              ),
                        onTap: () async {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            await auth.login(
                                _userName.text, _password.text, context);
                            // CachHelper.saveData(
                            //     key: "userName", value: _userName.text);
                            // print(CachHelper.getData(key: "userName"));
                          }
                        },
                        margin: const EdgeInsets.symmetric(vertical: 20),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ));
  }

  @override
  void dispose() {
    _password.dispose();
    _userName.dispose();
    super.dispose();
  }
}
