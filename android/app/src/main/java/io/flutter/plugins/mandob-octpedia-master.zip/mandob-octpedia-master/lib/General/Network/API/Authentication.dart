import 'dart:convert';
import '../Http.dart';

class Authentication {
  HttpMethods _http = HttpMethods();
  Map<String, String> headers = <String, String>{
    'Accept': '*/*',
    'Content-Type': 'application/json',
  };
  Future<bool> login(String userName, String password) async {
    var _data = await _http.postData(
        authHeaders: headers,
        url: "Authenticate/login",
        body: jsonEncode({"username": "$userName", "password": "$password"}));
    print({"username": userName, "password": password});
    print(_data);
    if (_data.contains("تمت الإضافة")) {
      return true;
    } else {
      return false;
    }
  }
}
