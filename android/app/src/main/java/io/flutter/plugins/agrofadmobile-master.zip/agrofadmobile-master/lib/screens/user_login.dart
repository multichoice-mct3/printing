import 'package:agrofad/AgrofadMainScreen.dart';
import 'package:agrofad/api/get_request_orders_api.dart';
import 'package:agrofad/api/login_apis.dart';
import 'package:agrofad/custom_widgets/CustomTextField.dart';
import 'package:agrofad/provider_services/user_Detail_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants.dart';

class UserLogin extends StatefulWidget {
  static String id = 'UserLogin';

  @override
  _UserLoginState createState() => _UserLoginState();
}

class _UserLoginState extends State<UserLogin> {
  final _formKey = GlobalKey<FormState>();
  bool checked = false;
  String UserName;
  String Password;
  bool isLoading = false;
  String Utype;

  GetRequstsApi _getRequstsApi = GetRequstsApi();
  LoginApi _loginApi = LoginApi();
  @override
  void initState() {
    // TODO: implement initState
    _loginApi.confirmCode('agrofad');
    super.initState();
                   }
  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    double ScreenHieght = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: KmainColor,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height * 12 / 100,
            ),
            Logo(),
            SizedBox(
              height: 10,
            ),
            Text(
              'للتنمية الزراعية',
              style: TextStyle(
                  color: WhiteColor,
                  fontSize: 25,
                  fontFamily: 'cocon',
                  fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 10,
            ),
            WhiteLine(),
            SizedBox(
              height: 30,
            ),
            Form(
                key: _formKey,
                child: Column(
                  children: [
                    CustomTextField(
                      hint: 'اسم المستخدم',
                      icon: Icons.person,
                      OnClick: (value) {
                        UserName = value;
                      },
                    ),
                    CustomTextField(
                      hint: 'الرقم السري',
                      icon: Icons.lock_open,
                      OnClick: (value) {
                        Password = value;
                      },
                    ),
                    LoginButton()
                  ],
                )),
            isLoading
                ? CircularProgressIndicator(
                    backgroundColor: Colors.white,
                  )
                : Container(),
            SizedBox(
              height: ScreenHieght * .20,
            ),
            Container(
              height: ScreenHieght * .10,
              width: ScreenWidth * .4,
              child: Image(image: AssetImage('assets/PowerdByMinicode.png')),
            ),
          ],
        ),
      ),
    );
  }

  Widget Logo() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 40 / 100,
      child: AspectRatio(
        aspectRatio: 1,
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
          ),
          child: SizedBox.expand(
            child: Padding(
              padding: EdgeInsets.all(10),
              child: Image(
                image: AssetImage('assets/Agrofad_Small.png'),
                // fit: BoxFi,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget WhiteLine() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 60),
      child: Divider(
        color: Colors.white,
        thickness: 4,
      ),
    );
  }

  Widget LoginButton() {
    return Consumer<UserDetail>(
      builder: (context, usertype, child) {
        return RaisedButton(
          color: Colors.white,
          onPressed: () {
            setState(() {
              isLoading = true;
            });
            if (_formKey.currentState.validate()) {
              try {
                _formKey.currentState.save();
                _loginApi.login(UserName, Password).then((UserAuth) async {
                  await _getRequstsApi.getUserDateail();
                  Utype = _getRequstsApi.UserType;
                  print(Utype);
                  usertype.ChangeUserType(Utype,_getRequstsApi.EmpId);
                  print('user${usertype.GetUType}');
                  if (UserAuth) {
                    setState(() {
                      isLoading = false;
                    });
                    Navigator.pushNamed(context, AgrofadMainScreen.id);
                  } else {
                    setState(() {
                      isLoading = false;
                    });
                    showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return Dialog(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                    20.0)), //this right here
                            child: Container(
                              height: 120,
                              child: Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Align(
                                      alignment: AlignmentDirectional.topEnd,
                                      child: Text(
                                        'ليس لديك صلاحية',
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'cocon',
                                          color: KmainColor,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 100.0,
                                      child: RaisedButton(
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                          child: Text(
                                            "اغلاق",
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                          color: KmainColor),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          );
                        });
                  }
                });
              } catch (e) {
                print('حدث خطا');
              }
            } else {
              setState(() {
                isLoading = false;
              });
            }
          },
          textColor: KmainColor,
          child: Text(
            'تسجيل الدخول',
            style: TextStyle(fontFamily: 'cocon', fontSize: 18),
          ),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
              side: BorderSide(color: Colors.white)),
        );
      },
    );
  }
}
