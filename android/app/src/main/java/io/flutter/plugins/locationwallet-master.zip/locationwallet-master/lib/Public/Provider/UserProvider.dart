import 'package:flutter/cupertino.dart';

class UserProvider with ChangeNotifier {
  bool passwordVisibility = true;
  bool confirmPasswordVisibility = true;

  void changePasswordVisibility() {
    passwordVisibility = !passwordVisibility;
    notifyListeners();
  }

  void changeConfirmPasswordVisibility() {
    confirmPasswordVisibility = !confirmPasswordVisibility;
    notifyListeners();
  }
}
