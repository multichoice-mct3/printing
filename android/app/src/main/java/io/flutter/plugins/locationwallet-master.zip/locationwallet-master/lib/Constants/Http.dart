import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

import 'CachHelper.dart';

class HttpMethods {
  String token = CachHelper.getData(key: "token");
  static const String baseUrl = "http://minicodeco-001-site8.etempurl.com/api";

  getData({@required String url}) async {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer $token',
    };
    var response = await http.get("$baseUrl/$url", headers: headers);

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      return data;
    } else {
      print("bad request ${response.statusCode}at getData $url");
    }
  }

  postData({@required String url, dynamic body}) async {
    var response = await http.post("$baseUrl/$url", body: body, headers: {
      'Content-Type': 'application/json',
      'Authorization': 'bearer $token',
    });
    if (response.statusCode == 200 || response.statusCode == 201) {
      var data = json.decode(response.body);
      print(data);
      return data;
    } else {
      print("bad request ${response.statusCode} at postData$url");
    }
  }

  putData({@required String url, dynamic body}) async {
    var response = await http.put("$baseUrl/$url", body: body, headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'bearer $token',
    });
    if (response.statusCode == 200 || response.statusCode == 201) {
      var data = json.decode(response.body);
      print(data);
      return data;
    } else {
      print("bad request ${response.statusCode}at putData$url");
    }
  }

  deleteData({@required int locationWalletId}) async {
    var response = await http.delete(
        "http://minicodeco-001-site8.etempurl.com/api/LocationWallets/$locationWalletId",
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'bearer $token',
        });
    bool deleted = false;
    if (response.statusCode == 200 || response.statusCode == 204) {
      deleted = true;

      return deleted;
    } else {
      print("bad request ${response.statusCode}at deleteData$locationWalletId");
      print(
          "http://minicodeco-001-site8.etempurl.com/api/LocationWallets/$locationWalletId");
    }
  }
}
