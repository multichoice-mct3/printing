// import 'package:flutter/material.dart';

// class Test extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           title: Text("ابلكيشن الابلكيشن"),
//         ),
//         body: Container(
//           height: 115,
//           child: Wrap(
//             direction: Axis.horizontal,
//             clipBehavior: Clip.none,
//             // scrollDirection: Axis.horizontal,
//             children: [
//               Container(
//                 margin: EdgeInsets.all(10),
//                 width: 100,
//                 height: 100,
//                 color: Colors.black,
//               ),
//               Container(
//                 margin: EdgeInsets.all(10),
//                 width: 100,
//                 height: 100,
//                 color: Colors.black,
//               ),
//               // Container(
//               //   margin: EdgeInsets.all(10),
//               //   width: 100,
//               //   height: 100,
//               //   color: Colors.black,
//               // ),
//               Container(
//                 margin: EdgeInsets.all(10),
//                 width: 100,
//                 height: 100,
//                 color: Colors.black,
//               ),
//               Container(
//                 margin: EdgeInsets.all(10),
//                 width: 100,
//                 height: 100,
//                 color: Colors.black,
//               ),
//               Container(
//                 margin: EdgeInsets.all(10),
//                 width: 100,
//                 height: 100,
//                 color: Colors.black,
//               ),
//               Container(
//                 margin: EdgeInsets.all(10),
//                 width: 100,
//                 height: 100,
//                 color: Colors.black,
//               ),
//               Container(
//                 margin: EdgeInsets.all(10),
//                 width: 100,
//                 height: 100,
//                 color: Colors.black,
//               ),
//               Container(
//                 margin: EdgeInsets.all(10),
//                 width: 100,
//                 height: 100,
//                 color: Colors.black,
//               ),
//             ],
//           ),
//         ));
//   }
// }
