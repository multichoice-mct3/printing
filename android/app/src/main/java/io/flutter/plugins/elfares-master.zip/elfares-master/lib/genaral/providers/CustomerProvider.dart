import 'package:elfares/genaral/network/API/CustomersAPI.dart';
import 'package:flutter/cupertino.dart';
import 'package:elfares/genaral/models/CustomerModel.dart';

class CustomersProvider extends ChangeNotifier {
  CustomersAPI _api = CustomersAPI();
  List<CustomerModel> _customers = [];
  List<String> _customersNames = [];
  List<String> get customersNames => _customersNames;
  int? _customerId;
  int get customerId => _customerId!;
  String? customerName;
  Future<void> getCustomers() async {
    _customers = await _api.getCustomersFromApi();
    fillNames();
    print(" ------------- ${_customers.length}");
    notifyListeners();
  }

  fillNames() {
    for (var emp in _customers) {
      _customersNames.add(emp.customerName!);
    }
  }

  changeCustomerName(String value) {
    customerName = value;
    print(customerName);
    int index =
        _customers.indexWhere((element) => element.customerName == value);
    _customerId = _customers[index].customerId;
    notifyListeners();
  }
}
