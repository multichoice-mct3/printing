import 'package:flutter/foundation.dart';
class AddItemModel{
      int SerNo;
      int ItemId ;
      String ItemName ;
      String UnitName;
      int UnitId;
      double qty;

          AddItemModel({
                    @required this.SerNo,
                    @required this.qty,
                    @required this.ItemName,
                    @required this.UnitName,
                    @required this.ItemId,
                    @required this.UnitId,

          });
          factory AddItemModel.FromJson(Map<String ,dynamic> AddItem){
            return AddItemModel(
              ItemName: AddItem['ItemName'],
              ItemId: AddItem['ItemId'],
              UnitName: AddItem['UnitName'],
              UnitId: AddItem['UnitId'],
              qty: AddItem['Qty'],
              SerNo: AddItem['SerNo']
                           );
                          }
      Map<String, dynamic> toJson(){
         return
                 {
           'SerNo':SerNo,
           'ItemId':ItemId,
           'ItemName':ItemName,
           'UnitId':UnitId,
           'UnitName':UnitName,
           'Qty':qty,
               };

      }

}