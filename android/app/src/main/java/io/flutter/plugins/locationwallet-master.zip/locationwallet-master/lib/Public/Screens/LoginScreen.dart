import 'package:LocarionWallet/Constants/DefaultButton.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:auto_route/auto_route.dart';

import '../../Constants/IconTextFiled.dart';
import '../../Constants/MyColors.dart';
import '../../Constants/MyText.dart';
import '../../Public/Provider/UserProvider.dart';
import '../../Public/Utilits/Validator.dart';
import '../../Public/resources/GeneralHttpMethods.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class UserLogin extends StatefulWidget {
  @override
  _UserLoginState createState() => _UserLoginState();
}

class _UserLoginState extends State<UserLogin> {
  GlobalKey<FormState> _formKey = new GlobalKey<FormState>();

  TextEditingController _phone = new TextEditingController();

  TextEditingController _pass = new TextEditingController();

  @override
  void dispose() {
    _phone.dispose();
    _pass.dispose();

    super.dispose();
  }

  void _doSomething() async {
    if (_formKey.currentState.validate()) {
      await GeneralHttpMethods().login(_phone.text, _pass.text);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColors.primary,
      body: SingleChildScrollView(
        padding: EdgeInsets.all(0),
        child: Container(
          color: MyColors.primary,
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Stack(
            alignment: Alignment.topCenter,
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(
                    vertical: MediaQuery.of(context).size.height * .08),
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * .5,
                alignment: Alignment.center,
                child: Column(
                  children: [
                    Image.asset(
                      "assets/images/wallet-location.png",
                      fit: BoxFit.contain,
                      width: 200,
                      height: 120,
                      color: MyColors.white,
                    ),
                    MyText(
                      title: tr("locationWallet"),
                      size: 26,
                      color: MyColors.white,
                    )
                  ],
                ),
              ),
              // Positioned(
              //   top: MediaQuery.of(context).size.height * .08,
              //   child: Column(
              //     children: [
              //       Image.asset(
              //         "assets/images/wallet-location.png",
              //         fit: BoxFit.contain,
              //         width: 200,
              //         height: 120,
              //         color: MyColors.white,
              //       ),
              //       MyText(
              //         title: tr("locationWallet"),
              //         size: 26,
              //         color: MyColors.white,
              //       )
              //     ],
              //   ),
              // ),
              Positioned(
                top: MediaQuery.of(context).size.height * .3,
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 25),
                  decoration: BoxDecoration(
                    color: MyColors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: MyText(
                            title: tr("login"),
                            size: 24,
                            color: MyColors.blackOpacity,
                          ),
                        ),
                        SizedBox(height: 10),
                        IconTextFiled(
                          margin:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          type: TextInputType.phone,
                          label: tr("phone"),
                          isPassword: false,
                          controller: _phone,
                          icon: Icon(Icons.phone_iphone),
                          validate: (value) =>
                              Validator().validateEmpty(value: value),
                        ),
                        SizedBox(height: 10),
                        IconTextFiled(
                          margin:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          type: TextInputType.text,
                          label: '${tr("password")} ${tr("ex")} Example^123',
                          isPassword: Provider.of<UserProvider>(context)
                              .passwordVisibility,
                          controller: _pass,
                          icon: InkWell(
                            onTap: () => Provider.of<UserProvider>(context,
                                    listen: false)
                                .changePasswordVisibility(),
                            child: Provider.of<UserProvider>(context)
                                    .passwordVisibility
                                ? Icon(Icons.visibility)
                                : Icon(Icons.visibility_off),
                          ),
                          validate: (value) =>
                              Validator().validatePassword(value: value),
                        ),
                        SizedBox(height: 10),
                        DefaultButton(title: tr("login"), onTap: _doSomething),
                        SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            MyText(
                              title: "${tr("dontHaveAcc")}",
                            ),
                            SizedBox(width: 5),
                            InkWell(
                              onTap: () => ExtendedNavigator.root
                                  .push(Routes.registeration),
                              child: MyText(
                                title: tr("register"),
                                color: MyColors.primary,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
