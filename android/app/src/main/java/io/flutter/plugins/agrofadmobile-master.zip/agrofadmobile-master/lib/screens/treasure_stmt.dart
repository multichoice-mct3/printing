import 'package:agrofad/api/get_account_api.dart';
import 'package:agrofad/api/get_statment_api.dart';
import 'package:agrofad/custom_widgets/custom_dialoge.dart';
import 'package:agrofad/models/Statment_model.dart';
import 'package:agrofad/models/account_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../constants.dart';
import 'package:agrofad/custom_widgets/LifeCycleWidget.dart';
import 'package:search_choices/search_choices.dart';
import 'package:f_datetimerangepicker/f_datetimerangepicker.dart';
import 'package:intl/intl.dart' as intl;
import 'package:dropdown_date_picker/dropdown_date_picker.dart';
import 'package:awesome_loader/awesome_loader.dart';

class TreasureAccountStmt extends StatefulWidget {
  static String id = 'TreasureAccountStmt';

  @override
  _TreasureAccountStmtState createState() => _TreasureAccountStmtState();
}

class _TreasureAccountStmtState extends State<TreasureAccountStmt> {
  static final now = DateTime.now();
  static final InitailFrom = DateTime.now().subtract(Duration(days: 30));
  double showHeight = 0;
  int ShowStmt=0;

  //Var Declrations
  String SelectedAccountName;
  String SelectedAccountId;
  String SelectedCostCenterName;
  int SelectedCostCenterId;
  bool done=false;
  String FromDate;
  String ToDate;


  //get apis method
  //Future GetAccounts;
  GetAllAccountsApi _getAccounts= new GetAllAccountsApi();
  List<Account> Accounts=[];

  GetStatmentApi _getStatmentApi=GetStatmentApi();
  List<StatmentModel> AccountStatment=[];
  Future<List<StatmentModel>> GetSatments()async {
    print(SelectedAccountId);
    print(ToDate);
    print(FromDate);
    AccountStatment=  await _getStatmentApi.Getstatments(SelectedAccountId, ToDate, FromDate);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
        ()async{
      Accounts=await _getAccounts.GetAllAccounts('TreasuryAccs');

      setState(() {
        done=true;
      });
    }();
  }

  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    double ScreenHieght = MediaQuery.of(context).size.height;
    return SafeArea(
      child: Scaffold(
        backgroundColor:!done?Colors.white: KmainColor,
        body:
        !done?
        Center(
          child: Container(
            height: 30,
            width: 30,

            child: AwesomeLoader(
              loaderType: AwesomeLoader.AwesomeLoader3,
              color: KmainColor,

            ),
          ),
        ):
        Column(
          children: [
            // SizedBox(height: 22,),
            Stack(
              alignment: Alignment.bottomCenter,
              children: [
                Column(
                  children: [
                    SelectAcountWidget(ScreenWidth),
                    Container(
                      height: showHeight / 2,
                      color: ShowStmt==1?Colors.white:KmainColor,

                    )
                  ],
                ),
                LifeCycleWidget(
                  onMounted: (size) => setState(() => showHeight = size.height),
                  child: RaisedButton(
                    color: Colors.amber,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18.0),
                    ),
                    onPressed: () async{
                      FromDate=FDate.getDate('/');
                      ToDate=TDate.getDate('/');
                      if(SelectedAccountId!=null){
                        setState(() {
                          ShowStmt=1;
                        });
                        await GetSatments();
                        if (AccountStatment.isNotEmpty){
                          print(AccountStatment[0].Credit);
                          setState(() {
                            ShowStmt=2;
                          });
                        }
                      }
                      else{
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return CustomDialoge(
                                Anothercontext: context,
                                Message: 'من فضلك قم باختيار الحساب ',
                                Callback: (){
                                  Navigator.of(context).pop();
                                },
                              );
                            });
                      }
                    },
                    child: Text(
                      'عرض',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontFamily: 'cocon',
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            ShowStmt==2?Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: ListView.builder(
                    itemCount: AccountStatment.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Container(
                        height: ScreenHieght / 6,
                        child: AccountDetail(index),
                      );
                    }),
              ),
            ): ShowStmt==1?Expanded(
              child: Container(
                color: Colors.white,
                child: Center(
                  child: Container(

                    height: 30,
                    width: 30,
                    child: AwesomeLoader(
                      loaderType: AwesomeLoader.AwesomeLoader3,
                      color: KmainColor,

                    ),
                  ),
                ),
              ),
            ):Container()
          ],
        ),
      ),
    );
  }

  Widget SelectAcountWidget(double ScreenWidth) {
    return Container(
      color: OfWhiteColor,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 25),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  ' حركة خزينة',
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: KmainColor,
                    fontSize: 25,
                    fontFamily: 'cocon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 15, top: 3),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)),
                    color: Colors.amber,
                    onPressed: () async {
                      Navigator.pop(context);
                    },
                    child: Text(
                      'رجوع',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'cocon',
                          fontSize: 18),
                    ),
                  ),
                )
              ],
            ),
          ),
          GetAccountRow(ScreenWidth),
          SizedBox(
            height: 5,
          ),
          // GetCCRow(ScreenWidth),
          // SizedBox(
          //   height: 5,
          // ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Expanded(
                  child: Row(
                    textDirection: TextDirection.rtl,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        'من',
                        style: TextStyle(
                            fontSize: 15,
                            color: KmainColor,
                            fontFamily: 'cocon',
                            fontWeight: FontWeight.bold),
                      ),
                      Container(
                          width: 156,
                          height: 35,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15)),
                          child: FDate),
                    ],
                  ),
                ),
                SizedBox(
                  width: 3,
                ),
                Expanded(
                  child: Row(
                    textDirection: TextDirection.rtl,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        'الي',
                        style: TextStyle(
                            fontSize: 15,
                            color: KmainColor,
                            fontFamily: 'cocon',
                            fontWeight: FontWeight.bold),
                      ),
                      Container(
                          width: 156,
                          height: 40,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15)),
                          child: TDate)
                    ],
                  ),
                )
              ],
            ),
          ),
          SizedBox(
            height: 20,
          )
        ],
      ),
    );
  }

  Widget GetAccountRow(double ScreenWidth) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        // height:WidgetHiegt*22/100,
        width: ScreenWidth,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          //  textDirection: TextDirection.rtl,
          children: [
            Directionality(
              textDirection: TextDirection.rtl,
              child: Container(
                //   height: 70,
                width: 92 / 100 * ScreenWidth,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15)),
                child: GetAccounts(Accounts),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget GetCCRow(double ScreenWidth) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        // height:WidgetHiegt*22/100,
        width: ScreenWidth,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          //  textDirection: TextDirection.rtl,
          children: [
            Directionality(
              textDirection: TextDirection.rtl,
              child: Container(
                //   height: 70,
                width: 70 / 100 * ScreenWidth,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15)),
                child: GetCostCenters(),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget GetAccounts(
      List<Account> Accounts
      ) {
    List<String> AccountNames =[];
    String Id;
    for (Account acc in Accounts) {
      AccountNames.add(acc.AccountName);
    }
    String getAccountId(String AccountName) {
      for (Account acc in Accounts) {
        if (acc.AccountName == AccountName) {
          Id = acc.AccountId;
        }
      }
      return Id;
    }
    return SearchChoices.single(
      items: AccountNames.map<DropdownMenuItem<String>>((string) {
        return (DropdownMenuItem<String>(
          child: SizedBox(
            width: 300,
            child: Text(
              string,
              textDirection: TextDirection.rtl,
              softWrap: false,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style:
              TextStyle(
                fontSize: 18, fontFamily: 'cocon', color: KmainColor,
              ),
            ),
          ),
          value: string,
        ));
      }).toList(),
      menuBackgroundColor: OfWhiteColor,
      value: SelectedAccountName,
      hint: Text(
        "اختر الحساب",
        textDirection: TextDirection.rtl,
        style: TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
      ),
      searchHint: Text(
        "اختر الحساب",
        textDirection: TextDirection.rtl,
        style: TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
      ),
      closeButton: FlatButton(
        onPressed: () {
          Navigator.pop(context);
        },
        child: Text(
          "اغلاق",
          textDirection: TextDirection.rtl,
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 18, color: KmainColor),
        ),
      ),
      underline: Container(
        height: 0,
        padding: EdgeInsets.all(0),
      ),
      clearIcon: Icon(
        Icons.clear,
        color: Colors.red,
        size: 20,
      ),
      icon: Icon(
        Icons.arrow_drop_down,
        size: 25,
        color: KmainColor,
      ),
      onChanged: (value) {
        setState(() {
          SelectedAccountName = value;
          SelectedAccountId = getAccountId(SelectedAccountName);
        });
      },
      isExpanded: true,
      rightToLeft: true,
      displayItem: (item, selected) {
        return (Row(textDirection: TextDirection.rtl, children: [
          selected
              ? Icon(
            Icons.radio_button_checked,
            color: Colors.grey,
          )
              : Icon(
            Icons.radio_button_unchecked,
            color: Colors.grey,
          ),
          SizedBox(width: 7),
          item,
          Expanded(
            child: SizedBox.shrink(),
          ),
        ]));
      },
      selectedValueWidgetFn: (item) {
        return Row(
          textDirection: TextDirection.rtl,
          children: <Widget>[
            SizedBox(
              width: 300,
              child: (Text(
                item,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
                textDirection: TextDirection.rtl,
                style: TextStyle(
                    fontSize: 20, fontFamily: 'cocon', color: KmainColor),
              )),
            ),
          ],
        );
      },
    );
  }

  Widget GetCostCenters(
      // List<CostCenter> CostCenters
      ) {
    List<String> CostCentersNames = [
      'عمارة572',
      'عمارة1415',
      'عمارة612',
    ];
    // int Id;
    // for (CostCenter cc in CostCenters) {
    //   CostCentersNames.add(cc.CostCenterName);
    // }
    // int GetCostCenterId(String CostCenterName) {
    //   for (CostCenter cc in CostCenters) {
    //     if (cc.CostCenterName == CostCenterName) {
    //       Id = cc.CostCeneterId;
    //     }
    //   }
    //   return Id;
    // }
    return SearchChoices.single(
      items: CostCentersNames.map<DropdownMenuItem<String>>((string) {
        return (DropdownMenuItem<String>(
          child: Text(
            string,
            textDirection: TextDirection.rtl,
            style:
            TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
          ),
          value: string,
        ));
      }).toList(),
      menuBackgroundColor: OfWhiteColor,
      value: SelectedCostCenterName,
      hint: Text(
        " مركز التكلفة",
        textDirection: TextDirection.rtl,
        style: TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
      ),
      searchHint: Text(
        " مراكز التكلفة",
        textDirection: TextDirection.rtl,
        style: TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
      ),
      closeButton: FlatButton(
        onPressed: () {
          Navigator.pop(context);
        },
        child: Text(
          "اغلاق",
          textDirection: TextDirection.rtl,
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 18, color: KmainColor),
        ),
      ),
      clearIcon: Icon(
        Icons.clear,
        color: Colors.red,
        size: 20,
      ),
      icon: Icon(
        Icons.arrow_drop_down,
        size: 25,
        color: KmainColor,
      ),
      onChanged: (value) {
        setState(() {
          SelectedCostCenterName = value;
          // SelectedCostCenterId = GetCostCenterId(SelectedCostCenterName);
        });
      },
      underline: Container(
        height: 0,
        padding: EdgeInsets.all(0),
      ),
      isExpanded: true,
      rightToLeft: true,
      displayItem: (item, selected) {
        return (Row(textDirection: TextDirection.rtl, children: [
          selected
              ? Icon(
            Icons.radio_button_checked,
            color: Colors.grey,
          )
              : Icon(
            Icons.radio_button_unchecked,
            color: Colors.grey,
          ),
          SizedBox(width: 7),
          item,
          Expanded(
            child: SizedBox.shrink(),
          ),
        ]));
      },
      selectedValueWidgetFn: (item) {
        return Row(
          textDirection: TextDirection.rtl,
          children: <Widget>[
            (Text(
              item,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                  fontSize: 20, fontFamily: 'cocon', color: KmainColor),
            )),
          ],
        );
      },
    );
  }

  final FDate=DropdownDatePicker(
    firstDate: ValidDate(year: now.year - 100, month: 1, day: 1),
    lastDate: ValidDate(year: now.year, month: now.month, day: now.day),
    textStyle: TextStyle(
      fontWeight: FontWeight.bold,
      color: KmainColor,
      fontSize: 15,
    ),
    dropdownColor: Colors.blue[200],
    dateHint: DateHint(year: 'yyyy', month: 'mm', day: 'dd'),
    ascending: false,
    underLine: Container(
      width: 0,
      height: 0,
      padding: EdgeInsets.all(0),
    ),
    initialDate: ValidDate(year: now.year, month: now.month, day: now.day),
  );
  final TDate=DropdownDatePicker(
    firstDate: ValidDate(year: now.year - 100, month: 1, day: 1),
    lastDate: ValidDate(year: now.year, month: now.month, day: now.day),
    textStyle: TextStyle(
      fontWeight: FontWeight.bold,
      color: KmainColor,
      fontSize: 15,
    ),
    dropdownColor: Colors.blue[200],
    dateHint: DateHint(year: 'yyyy', month: 'mm', day: 'dd'),
    ascending: false,
    underLine: Container(
      width: 0,
      height: 0,
      padding: EdgeInsets.all(0),
    ),
    initialDate: ValidDate(year: now.year, month: now.month, day: now.day),
  );

  Widget AccountDetail(int index) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: LayoutBuilder(
        builder: (context, constarints) {
          double localWidth = constarints.maxWidth;
          double LocalHight = constarints.maxHeight;

          return Column(
            children: [
              //first
              Container(
                width: localWidth,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(20),
                    topLeft: Radius.circular(20),
                  ),
                  color: Colors.white,
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Expanded(
                          flex: 1,
                          child: Row(
                            textDirection: TextDirection.rtl,
                            children: [
                              Container(
                                  child: Text(
                                    ':التاريخ',
                                    textAlign: TextAlign.end,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        fontFamily: 'cocon',
                                        color: KmainColor),
                                  )),
                              SizedBox(
                                width: 15,
                              ),
                              Container(
                                  child: Text(
                                    // '2020/01/19',
                                    AccountStatment[index].EntryDate,
                                    textAlign: TextAlign.end,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        fontFamily: 'cocon',
                                        color: BlackColor),
                                  )),
                            ],
                          )),
                      Expanded(
                        flex: 1,
                        child: Row(
                          textDirection: TextDirection.rtl,
                          children: [
                            Text(
                              ':النوع',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  fontFamily: 'cocon',
                                  color: KmainColor),
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            SizedBox(
                              width: 100,
                              child: Text(
                                AccountStatment[index].StatementNotes,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                softWrap: false,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,

                                    fontSize: 20,
                                    fontFamily: 'cocon',
                                    color: KmainColor),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                height: LocalHight / 3,
                width: localWidth,
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Expanded(
                        flex: 1,
                        child: Row(
                          textDirection: TextDirection.rtl,
                          children: [
                            Text(
                              ':مدين',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  fontFamily: 'cocon',
                                  color: KmainColor),
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            Text(
                              (AccountStatment[index].Debit).toString(),
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  fontFamily: 'cocon',
                                  color: BlackColor),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                          flex: 1,
                          child: Row(
                            textDirection: TextDirection.rtl,
                            children: [
                              Container(
                                  child: Text(
                                    ':دائن',
                                    textAlign: TextAlign.end,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        fontFamily: 'cocon',
                                        color: KmainColor),
                                  )),
                              SizedBox(
                                width: 17,
                              ),
                              Container(
                                  child: Text(
                                    (AccountStatment[index].Credit).toString(),
                                    textAlign: TextAlign.end,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        fontFamily: 'cocon',
                                        color: BlackColor),
                                  )),
                            ],
                          )),

                    ],
                  ),
                ),
              ),
              Container(
                  height: LocalHight / 3,
                  width: localWidth,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(20),
                        bottomLeft: Radius.circular(20)),
                    color: Colors.white,
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                        child: Row(
                          textDirection: TextDirection.rtl,
                          children: [
                            Expanded(
                              flex: 1,
                              child: Row(
                                textDirection: TextDirection.rtl,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    ':الرصيد',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        fontFamily: 'cocon',
                                        color: KmainColor),
                                  ),
                                  SizedBox(
                                    width: 15,
                                  ),
                                  Text(
                                    (AccountStatment[index].StatementBal).toString(),
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                        fontFamily: 'cocon',
                                        color: BlackColor),
                                  ),
                                ],
                              ),
                            ),

                          ],
                        ),
                      ),
                    ],
                  )),
            ],
          );
        },
      ),
    );
  }
}
