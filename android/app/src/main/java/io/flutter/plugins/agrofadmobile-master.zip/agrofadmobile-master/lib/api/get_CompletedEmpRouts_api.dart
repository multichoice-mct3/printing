import 'dart:convert';
import 'package:agrofad/models/route_model.dart';
import 'package:http/http.dart' as http;
import 'login_apis.dart';
class GetCompletedAgentVisitRoutesApi{
  LoginApi _loginApi=LoginApi();
  List<AgentVisitRouteModel> _CompletedEmpRoutes=[];
  Future<List<AgentVisitRouteModel>> GetCompletedAgentVisitRoutes(int EmpIdUserId,int AgentId,String ToDate,String FromDate) async {
    await _loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${_loginApi.token}',
    };
    var response = await http.get(
        "http://104.196.134.107/AfitAPI/api/GetCompletedAgentVisitRoutesByEmp?_EmpId=${EmpIdUserId}",
        headers:Headers
    );
    if (response.statusCode == 200) {
      print(response.body);
      _CompletedEmpRoutes=ParseItems(response.body);
      print(_CompletedEmpRoutes);
    }
    else {
      print(response.body);
    }
    return _CompletedEmpRoutes;
  }
  List<AgentVisitRouteModel> ParseItems(String responseBody) {
    final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();
    print(parsedItems);
    return parsedItems.map<AgentVisitRouteModel>((json) => AgentVisitRouteModel.CompletedVisitfromJson(json)).toList();
  }


}