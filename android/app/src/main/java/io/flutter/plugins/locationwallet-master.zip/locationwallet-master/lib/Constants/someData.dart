import 'package:LocarionWallet/Models/LocationModel.dart';
import 'package:url_launcher/url_launcher.dart';

class SomeModel {
  static List<LocationModel> models = [
    LocationModel(
      mapLatitude: 29.95881375719657,
      mapLongitude: 30.943065620905493,
      locationName: "ميني كود",
      locationWalletId: 1,
      locationDescription: "gym",
    ),
    LocationModel(
      mapLatitude: 29.95881375719657,
      mapLongitude: 30.943065620905493,
      locationName: "هايبر",
      locationWalletId: 1,
      locationDescription: "gym",
    ),
    LocationModel(
      mapLatitude: 29.95881375719657,
      mapLongitude: 30.943065620905493,
      locationName: "بيبا",
      locationWalletId: 1,
      locationDescription: "gym",
    ),
    LocationModel(
      mapLatitude: 29.95881375719657,
      mapLongitude: 30.943065620905493,
      locationName: "زيزو",
      locationWalletId: 1,
      locationDescription: "gym",
    ),
    LocationModel(
      mapLatitude: 29.95881375719657,
      mapLongitude: 30.943065620905493,
      locationName: "شاكاليطه",
      locationWalletId: 1,
      locationDescription: "gym",
    ),
  ];
}

class MapUtils {
  MapUtils._();

  static Future<void> openMap(double latitude, double longitude) async {
    String googleUrl =
        'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
    print(googleUrl);
    if (await canLaunch(googleUrl)) {
      await launch(googleUrl);
    } else {
      throw 'Could not open the map.';
    }
  }

  static void launchMapsUrl(sourceLatitude, sourceLongitude,
      destinationLatitude, destinationLongitude) async {
    String mapOptions = [
      'saddr=$sourceLatitude,$sourceLongitude',
      'daddr=$destinationLatitude,$destinationLongitude',
      'dir_action=navigate'
    ].join('&');

    final url = 'https://www.google.com/maps?$mapOptions';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
