import 'package:agrofad/provider_services/user_Detail_provider.dart';
import 'package:agrofad/screens/Agent_routes.dart';
import 'package:agrofad/screens/account_stmt.dart';
import 'package:agrofad/screens/addAgents_routs.dart';
import 'package:agrofad/screens/addCustomer.dart';
import 'package:agrofad/screens/agent_resultRouts.dart';
import 'package:agrofad/screens/get_orders.dart';
import 'package:agrofad/screens/ordered_supply.dart';
import 'package:agrofad/screens/treasure_stmt.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'constants.dart';

class AgrofadMainScreen extends StatefulWidget {
  static String id = 'LemarMainScreen';
  @override
  _AgrofadMainScreenState createState() => _AgrofadMainScreenState();
}

class _AgrofadMainScreenState extends State<AgrofadMainScreen> {
  //String userType;
  List AgrofadList;
  List AgrofadAdminModuleList = [
    'امر التوريد لعميل',
    'تقرير اوامر التوريد',
    'كشف حساب',
    'حركة خزنة',
    'حساب بنك',
    'اعتماد اجازات',
    'تحديد مسارات ',
    'تقرير مسارات مندوب',
    'نتائج مسارات مندوب',
   // 'اضافة عميل'
  ];
  List AgrofadUserModuleList = [
    'امر التوريد لعميل',
    'تقرير اوامر التوريد',
    'كشف حساب',
    'تحديد مسارات ',
    'تقرير مسارات مندوب',
  //  'اضافة عميل'
  ];
  String PageName = '';
  int SelectedIndex;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    double ScreenHieght = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: KmainColor,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: ScreenWidth,
              color: KmainColor,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  double LocalHieght = constraints.maxHeight;
                  double LocalWidth = constraints.maxWidth;
                  return Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(bottom: 35, top: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          textDirection: TextDirection.rtl,
                          children: [
                            Text(
                              'القائمة الرئيسية',
                              style: TextStyle(
                                  color: WhiteColor,
                                  fontSize: 22,
                                  fontFamily: 'cocon',
                                  fontWeight: FontWeight.bold),
                            ),
                            Text(
                              ' THE CAPITAL ERP',
                              style: TextStyle(
                                  color: WhiteColor,
                                  fontSize: 22,
                                  fontFamily: 'cocon',
                                  fontWeight: FontWeight.bold),
                            ),
                            //   Text('The Capital Erp')
                          ],
                        ),
                      ),
                      Container(
                          width: LocalWidth * .7,
                          child: Center(
                            child: Image(
                              image: AssetImage('assets/logo.png'),
                            ),
                          )),
                    ],
                  );
                },
              ),
            ),
            RealEstateWidget()
          ],
        ),
      ),
    );
  }

  Widget RealEstateWidget() {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(right: 15, bottom: 5, left: 15),
        child: Container(
            width: MediaQuery.of(context).size.width,
            //  height: MediaQuery.of(context).size.height*68/100,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20), color: Colors.white),
            child: Consumer<UserDetail>(
              builder: (context, UserType, child) {
                if (UserType.GetUType == 'ADMIN') {
                  AgrofadList = AgrofadAdminModuleList;
                } else {
                  AgrofadList = AgrofadUserModuleList;
                }
                return ListView.builder(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    scrollDirection: Axis.vertical,
                    itemCount: AgrofadList.length,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          NavigationList(AgrofadList[index]);
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 5, horizontal: 5),
                          child: Stack(
                            alignment: AlignmentDirectional.center,
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width *
                                    85 /
                                    100,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: KmainColor,
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child: Center(
                                  child: Text(
                                    AgrofadList[index],
                                    style: TextStyle(
                                      color: WhiteColor,
                                      fontSize: 22,
                                      fontFamily: 'cocon',
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    });
              },
            )),
      ),
    );
  }

  void NavigationList(String ScreenName) {
    switch (ScreenName) {
      case 'امر التوريد لعميل':
        {
          Navigator.pushNamed(context, OrderedSupply.id);
        }
        break;
      case 'تقرير اوامر التوريد':
        {
          Navigator.pushNamed(context, Orders.id);
        }
        break;
      case 'كشف حساب':
        {
          Navigator.pushNamed(context, AccountStatment.id);
        }
        break;

      case 'حركة خزنة':
        {
          Navigator.pushNamed(context, TreasureAccountStmt.id);
        }
        break;

      case 'تحديد مسارات ':
        {
          Navigator.pushNamed(context, AddAgentRouts.id);
        }
        break;

      case  'تقرير مسارات مندوب':
        {
          Navigator.pushNamed(context, EmpRoutes.id);
        }
        break;

      case 'اضافة عميل':
        {
          Navigator.pushNamed(context, AddCustomer.id);
        }
        break;
      case 'نتائج مسارات مندوب':
        {
          Navigator.pushNamed(context, AgentResultRoutes.id);
        }
        break;




    }
  }
}
