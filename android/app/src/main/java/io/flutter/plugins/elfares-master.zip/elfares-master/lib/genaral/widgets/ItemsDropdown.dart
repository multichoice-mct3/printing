import 'package:elfares/genaral/constants/MyDropDown.dart';
import 'package:elfares/genaral/providers/ItemsProvider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ItemsDropdown extends StatelessWidget {
  const ItemsDropdown({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<ItemsProvider>(
      builder: (context, items, child) => CustomDropDown(
        hint: "اختر الصنف",
        items: items.itemNames,
        value: items.itemName,
        onChange: (value) => items.changeItemName(value),
      ),
    );
  }
}
