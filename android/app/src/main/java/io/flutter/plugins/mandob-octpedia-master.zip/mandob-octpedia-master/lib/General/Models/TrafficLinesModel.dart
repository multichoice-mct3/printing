class TrafficLinesModel {
  int? trafficLinesId;
  String? trafficLinesName;
  int? distance;
  int? providesId;

  TrafficLinesModel({
    this.trafficLinesId,
    this.trafficLinesName,
    this.distance,
    this.providesId,
  });

  TrafficLinesModel.fromJson(Map<String, dynamic> json) {
    trafficLinesId = json['trafficLinesId'];
    trafficLinesName = json['trafficLinesName'];
    distance = json['distance'];
    providesId = json['providesId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['trafficLinesId'] = this.trafficLinesId;
    data['trafficLinesName'] = this.trafficLinesName;
    data['distance'] = this.distance;
    data['providesId'] = this.providesId;
    return data;
  }
}
