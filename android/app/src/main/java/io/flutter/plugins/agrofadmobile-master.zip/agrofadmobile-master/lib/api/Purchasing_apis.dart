import 'dart:convert';
import 'package:agrofad/models/ItemModel.dart';
import 'package:http/http.dart' as http;
import 'login_apis.dart';
class PurchasingApi {
      LoginApi loginApi = new LoginApi();
      List<Item>Items=[];

      String BaseUrl = 'http://104.196.134.107/AfitAPI';
      Future<List <Item>> GetItems() async {
        await loginApi.getAccessToken();
        Map Headers = <String, String>{
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer ${loginApi.token}',
        };
        var response = await http.get("http://104.196.134.107/AfitAPI/api/Item/GetItemsWithQty",
            headers: Headers);
        if (response.statusCode == 200) {
          Items= ParseItems(response.body);
        //  print (Items[1].ItemName);
        } else {
          print(response.body);
        }

        return Items;
      }
              //fn get the item list
      List<Item> ParseItems(String responseBody) {
        final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();
        return parsedItems.map<Item>((json) => Item.FromJson(json)).toList();
      }


    }
