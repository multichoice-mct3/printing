import 'package:flutter/material.dart';
import 'package:mandoboct/General/Constants/LoadingDialog.dart';
import 'package:mandoboct/General/Constants/MyElevatedBtn.dart';
import 'package:mandoboct/General/Provider/provider.dart';
import 'package:mandoboct/General/Utilities/utils.dart';
import 'package:mandoboct/general/Constants/LabelTextField.dart';
import 'package:mandoboct/general/Constants/MyColors.dart';
import 'package:mandoboct/general/Constants/MyDialog.dart';
import 'package:mandoboct/general/Constants/MyDropDown.dart';
import 'package:mandoboct/general/Constants/MyText.dart';
import 'package:mandoboct/general/Constants/MyToast.dart';
import 'package:mandoboct/General/Network/API/ProvidersApi.dart';
import 'package:mandoboct/General/Provider/CategoriesProvider.dart';
import 'package:mandoboct/General/Provider/MainProvider.dart';
import 'package:mandoboct/General/Provider/ServiceProvider.dart';
import 'package:provider/provider.dart';
import 'package:searchfield/searchfield.dart';

class MobileHome extends StatefulWidget {
  @override
  _MobileHomeState createState() => _MobileHomeState();
}

class _MobileHomeState extends State<MobileHome> {
  TextEditingController provName = TextEditingController();
  TextEditingController prodDesc = TextEditingController();
  TextEditingController provPhone = TextEditingController();
  TextEditingController provPhone2 = TextEditingController();
  TextEditingController social = TextEditingController();
  TextEditingController address = TextEditingController();
  TextEditingController lat = TextEditingController();
  TextEditingController long = TextEditingController();
  @override
  void dispose() {
    provName.dispose();
    prodDesc.dispose();
    provPhone.dispose();
    provPhone2.dispose();
    social.dispose();
    address.dispose();
    lat.dispose();
    long.dispose();
    super.dispose();
  }

  bool isLoading = false;
  void loading() {
    setState(() {
      isLoading = !isLoading;
    });
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          title: Text("تسجيل مقدم خدمة"),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                CustomDropDown(
                    items: context.read<CategoriesProvider>().categoriesNames,
                    hint: "اختر الفئة",
                    onChange: (value) async {
                      context
                          .read<CategoriesProvider>()
                          .changeDropDownValue(value);
                      LoadingDialog(context).showDilaog();
                      await Provider.of<ServiceProvider>(context, listen: false)
                          .getAllServices(Provider.of<CategoriesProvider>(
                                      context,
                                      listen: false)
                                  .categoryId ??
                              1);
                      Navigator.pop(context);
                    },
                    value:
                        Provider.of<CategoriesProvider>(context).categoryName),
                const SizedBox(height: 10),
                CustomDropDown(
                    items: context.read<ServiceProvider>().serNames,
                    hint: "اختر الخدمة",
                    onChange: (value) => context
                        .read<ServiceProvider>()
                        .changeDropDownValue(value),
                    value: Provider.of<ServiceProvider>(context).serviceName),
                const SizedBox(height: 10),
                SearchField(
                  suggestions: context.read<MokademKhedma>().providerNames,
                  controller: provName,
                  hint: 'اسم مقدم الخدمة',
                  searchStyle: TextStyle(
                    fontSize: 16,
                    color: Colors.black.withOpacity(0.8),
                  ),
                  validator: (x) {
                    if (!context
                            .read<MokademKhedma>()
                            .providerNames
                            .contains(x) ||
                        x!.isEmpty) {
                      return 'Please Enter a valid State';
                    }
                    return null;
                  },
                  searchInputDecoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: MyColors.primary.withOpacity(.5),
                              width: .5),
                          borderRadius: BorderRadius.circular(10)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                              color: MyColors.primary.withOpacity(.5),
                              width: 2)),
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      filled: true,
                      fillColor: Colors.white),
                  maxSuggestionsInViewPort: 6,
                  itemHeight: 50,
                  onTap: (x) {
                    print(x);
                  },
                ),
                const SizedBox(height: 10),
                // LabelTextField(
                //     controller: provName,
                //     label: "اسم مزود الخدمة",
                //     isPassword: false,
                //     margin: const EdgeInsets.symmetric(vertical: 5.0)),
                TextFormField(
                  controller: prodDesc,
                  maxLines: 7,
                  decoration: InputDecoration(
                    fillColor: MyColors.white,
                    filled: true,
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey, width: 1.5),
                        borderRadius: BorderRadius.circular(5)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5),
                        borderSide: BorderSide(
                            color: MyColors.primary.withOpacity(.5), width: 2)),
                    hintText: "اكتب وصف المنتج هنا",
                    hintStyle: TextStyle(
                        fontFamily: "Almarai",
                        fontSize: 14,
                        color: Colors.black45),
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 10, vertical: 14),
                    suffixIcon: Icon(Icons.description_rounded),
                  ),
                ),
                const SizedBox(width: 10),
                LabelTextField(
                    controller: provPhone,
                    label: "رقم الهاتف",
                    isPassword: false,
                    type: TextInputType.phone,
                    margin: const EdgeInsets.symmetric(vertical: 5.0)),
                LabelTextField(
                    controller: provPhone2,
                    label: "رقم الهاتف (اختياري)",
                    isPassword: false,
                    margin: const EdgeInsets.symmetric(vertical: 5.0)),
                LabelTextField(
                    controller: social,
                    label: "رابط موقع التواصل الإجتماعي",
                    isPassword: false,
                    margin: const EdgeInsets.symmetric(vertical: 5.0)),
                LabelTextField(
                    controller: address,
                    label: "العنوان",
                    isPassword: false,
                    margin: const EdgeInsets.symmetric(vertical: 5.0)),
                Row(
                  children: [
                    Expanded(
                      child: LabelTextField(
                          controller: lat,
                          label: "Latitude",
                          isPassword: false,
                          margin: const EdgeInsets.all(5)),
                    ),
                    Expanded(
                      child: LabelTextField(
                          controller: long,
                          label: "Longitude",
                          isPassword: false,
                          margin: const EdgeInsets.all(5)),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                        child:
                            context.watch<CategoriesProvider>().categoryName !=
                                    "مواصلاتي"
                                ? MyElevatedBtn(
                                    onTap: () async {
                                      if (context
                                              .read<ServiceProvider>()
                                              .serviceId !=
                                          null) {
                                        loading();
                                        await context
                                            .read<MainProvider>()
                                            .getProviders(context
                                                .read<ServiceProvider>()
                                                .serviceId!);
                                        MyDialog(context).showMyDialog();
                                        loading();
                                      } else {
                                        Utils.showSnackBar(
                                            "من فضلك اختار الخدمة",
                                            Colors.red,
                                            context);
                                      }
                                    },
                                    child: isLoading
                                        ? CircularProgressIndicator(
                                            color: Colors.white)
                                        : MyText(
                                            title: "إضافة عناصر",
                                            color: MyColors.white),
                                  )
                                : MyElevatedBtn(
                                    onTap: () async {
                                      if (context
                                              .read<ServiceProvider>()
                                              .serviceId !=
                                          null) {
                                        loading();
                                        await context
                                            .read<MainProvider>()
                                            .getProviders(context
                                                .read<ServiceProvider>()
                                                .serviceId!);
                                        MyDialog(context).show();
                                        loading();
                                      } else {
                                        Utils.showSnackBar(
                                            "من فضلك اختار الخدمة",
                                            Colors.red,
                                            context);
                                      }
                                    },
                                    child: isLoading
                                        ? CircularProgressIndicator(
                                            color: Colors.white)
                                        : MyText(
                                            title: "إضافة محطات",
                                            color: MyColors.white),
                                  )),
                    Expanded(
                      child: Consumer<ServiceProvider>(
                        builder: (ctx, serviceProvid, ch) {
                          return ElevatedButton(
                            onPressed: () async {
                              LoadingDialog(context).showDilaog();
                              await context
                                  .read<MainProvider>()
                                  .getProviders(serviceProvid.serviceId!);
                              context
                                  .read<MainProvider>()
                                  .checkProviderExistance(provName.text);
                              print(serviceProvid.serviceName);
                              if (serviceProvid.serviceName == null ||
                                  provName.text == '') {
                                MyToast().showToast(
                                    "برجاء اضاقة الخدمة والمزود", Colors.red);
                              } else if (context.read<MainProvider>().isExist) {
                                Navigator.pop(context);
                                MyDialog(context).showConfirmDialog(
                                    onTap: () => addProvider(context));
                              } else {
                                addProvider(context);
                                Navigator.pop(context);
                              }
                            },
                            child: MyText(
                              title: "حفظ وتسجيل",
                              color: MyColors.white,
                            ),
                            style: ElevatedButton.styleFrom(
                              fixedSize: Size(screenSize.width * .4,
                                  screenSize.height * .06),
                              primary: MyColors.primary,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ));
  }

  void addProvider(BuildContext context) {
    ProviderApi()
        .addProvider(
      name: provName.text,
      disc: prodDesc.text,
      phone: provPhone.text,
      phone2: provPhone2.text,
      address: address.text,
      social: social.text,
      lat: lat.text.isNotEmpty
          ? double.parse(lat.text)
          : context.read<MainProvider>().getLat,
      long: long.text.isNotEmpty
          ? double.parse(long.text)
          : context.read<MainProvider>().getLong,
      categoryId:
          Provider.of<CategoriesProvider>(context, listen: false).categoryId!,
      serviceId:
          Provider.of<ServiceProvider>(context, listen: false).serviceId!,
    )
        .then((value) {
      if (value == "تمت الإضافة") {
        address.clear();
        prodDesc.clear();
        provName.clear();
        provPhone.clear();
        provPhone2.clear();
        social.clear();
        lat.clear();
        long.clear();
        Utils.showSnackBar(value, Colors.green, context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            backgroundColor: Colors.red,
            content: MyText(title: "حدث خطأ يرجى المحاولة لاحقاً")));
      }
    });
  }
}
