import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:octpedia/App/Utilities/cach_helper.dart';
import 'package:octpedia/App/Utilities/global_state.dart';
import 'package:octpedia/App/Utilities/my_route.dart';
import 'package:octpedia/Presentation/Authentication/Login/login_screen.dart';
import 'package:octpedia/Presentation/Resources/values_manager.dart';
import 'package:octpedia/Presentation/widgets/loading_dialog.dart';

part 'dio_helper.dart';
