import 'package:LocarionWallet/Constants/DefaultAppBar.dart';
import 'package:LocarionWallet/Constants/DefaultButton.dart';
import 'package:LocarionWallet/Constants/IconTextFiled.dart';
import 'package:LocarionWallet/Constants/MyColors.dart';
import 'package:LocarionWallet/Constants/MyText.dart';
import 'package:LocarionWallet/Models/LocationModel.dart';
import 'package:LocarionWallet/Public/Provider/LocationProvider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LocationDetails extends StatefulWidget {
  final LocationModel location;

  LocationDetails({Key key, @required this.location}) : super(key: key);

  @override
  _LocationDetailsState createState() => _LocationDetailsState();
}

class _LocationDetailsState extends State<LocationDetails> {
  TextEditingController placeName = TextEditingController();

  TextEditingController placeDesc = TextEditingController();
  @override
  void dispose() {
    placeDesc.dispose();
    placeName.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    placeDesc.text = widget.location.locationDescription;
    placeName.text = widget.location.locationName;
    return Scaffold(
      appBar: DefaultAppBar(
        title: widget.location.locationName,
        con: context,
        back: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            MyText(title: "يمكنك تعديل بيانات المكان : "),
            SizedBox(height: 30),
            IconTextFiled(
              controller: placeName,
              isPassword: false,
              label: "${tr("name")} ${tr("location")}",
              icon: Icon(Icons.add_location_alt_outlined),
            ),
            SizedBox(height: 10),
            TextFormField(
              controller: placeDesc,
              maxLines: 4,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey, width: 1.5),
                    borderRadius: BorderRadius.circular(5)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(5),
                    borderSide: BorderSide(
                        color: MyColors.primary.withOpacity(.5), width: 2)),
                hintText: tr("description"),
                hintStyle: TextStyle(
                    fontFamily: "Cairo", fontSize: 14, color: Colors.black45),
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 10, vertical: 14),
                suffixIcon: Icon(Icons.description_rounded),
              ),
            ),
            DefaultButton(
              title: tr("confirm"),
              onTap: () {
                widget.location.locationName = placeName.text;
                widget.location.locationDescription = placeDesc.text;
                context
                    .read<LocationProvider>()
                    .editLocation(location: widget.location, context: context);
                print(widget.location.toJson());
              },
              margin: EdgeInsets.symmetric(vertical: 20),
            ),
          ],
        ),
      ),
    );
  }
}
