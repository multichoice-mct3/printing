import 'package:LocarionWallet/Models/LocationModel.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:LocarionWallet/Public/resources/GeneralHttpMethods.dart';
import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:location/location.dart';
import 'package:toast/toast.dart';

class LocationProvider with ChangeNotifier {
  double _lat = 0.0;
  double _long = 0.0;
  double get getLat => _lat;
  double get getLong => _long;

  getUserLocation() async {
    Location location = new Location();
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;
    LocationData _currentLocation;
    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }
    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.DENIED) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.GRANTED) {
        return;
      }
    }
    _currentLocation = await location.getLocation();
    _lat = _currentLocation.latitude;
    _long = _currentLocation.longitude;
  }
  List<LocationModel> _locations = [];
  List<LocationModel> filterdLocations = [];


  getLocations() async {
    print('getter');
    _locations = [];
    _locations = filterdLocations = await GeneralHttpMethods().getLocations();
    print("_locations ${_locations.length}");
  }

  List<LocationModel> get locations => _locations;
  void removeLocation(LocationModel place) {
    GeneralHttpMethods().deleteLocation(place.locationWalletId);
    _locations.remove(place);
    notifyListeners();
  }

  void addLocation({
    @required String locationName,
    @required String locationDescription,
    @required double mapLatitude,
    @required double mapLongitude,
  }) async {
    await GeneralHttpMethods()
        .addLocation(
          locationDescription: locationDescription,
          locationName: locationName,
          mapLatitude: mapLatitude,
          mapLongitude: mapLongitude,
        )
        .then((value) => print(value));
  }

  void editLocation({
    @required LocationModel location,
    @required BuildContext context,
  }) async {
    await GeneralHttpMethods().editLocation(location).then((value) {
      if (value) {
        Toast.show(tr("doneEdit"), context,
            duration: 2,
            gravity: Toast.BOTTOM,
            backgroundColor: Colors.green[400]);
        ExtendedNavigator.root.popAndPush(Routes.savedPlaces);
      } else {
        Toast.show(tr("smthWentWrong"), context,
            duration: 2,
            gravity: Toast.BOTTOM,
            backgroundColor: Colors.red[400]);
      }
    });
  }

  // List<LocationModel> filterdLocations = SomeModel.models;
  void searchList(String value) {
    print(value);
    if (value != "") {
      filterdLocations = filterdLocations
          .where((element) => element.locationName.contains(value))
          .toList();
    } else {
      filterdLocations = _locations;
    }
    print("searchLocations.length ${filterdLocations.length}");
    notifyListeners();
  }
}
