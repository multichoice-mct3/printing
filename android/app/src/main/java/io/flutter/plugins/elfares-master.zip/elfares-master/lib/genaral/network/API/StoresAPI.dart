import 'package:elfares/genaral/models/StoresModel.dart';

import '../Http.dart';

class StoresApi {
  HttpMethods _http = HttpMethods();
  Future<List<Stores>> getStoresFromApi() async {
    List<Stores> stores = [];
    var _data = await _http.getData(url: "store");
    if (_data != null) {
      List<Map<String, dynamic>> _storesJson =
          List<Map<String, dynamic>>.from(_data);
      stores = _storesJson.map((store) => Stores.fromJson(store)).toList();
      return stores;
    }

    return stores;
  }
}
