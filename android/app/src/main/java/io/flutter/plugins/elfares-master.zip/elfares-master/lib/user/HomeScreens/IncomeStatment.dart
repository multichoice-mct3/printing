part of "HomeImports.dart";

class IncomeStatment extends StatelessWidget {
  const IncomeStatment({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String? value, value1, value2, value3;
    return ItemsMainScreen(
        title: "قائمة الدخل",
        content: Column(
          children: [
            CustomDropDown(
              hint: 'اختر الفترة',
              items: [],
              value: value,
              onChange: (value) => print(value),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                MyText(
                  title: 'حتى تاريخ',
                  color: MyColors.white,
                  size: 14,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Row(
                    children: [
                      Flexible(
                        child: SimpleDropDown(
                          hint: "يوم",
                          items: days,
                          value: value1,
                          onChanged: (value) => print(value),
                        ),
                      ),
                      const SizedBox(width: 5),
                      Flexible(
                        child: SimpleDropDown(
                          hint: "شهر",
                          items: months,
                          value: value2,
                          onChanged: (value) => print(value),
                        ),
                      ),
                      const SizedBox(width: 5),
                      Flexible(
                        child: SimpleDropDown(
                          hint: "سنة",
                          items: years,
                          value: value3,
                          onChanged: (value) => print(value),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
            const SizedBox(height: 10),
            MyElevatedButton(onPressed: () => print("fdf"), title: 'عرض')
          ],
        ));
  }
}
