const String imagePath = "assets/images";
const String iconPath = "assets/icons";
const String jsonPath = "assets/json";

class ImageAssets {
  static const String splashLogo = "$imagePath/splash.png";
  static const String education = "$imagePath/Education.png";
  static const String tarfehy = "$imagePath/entertainment.png";
  static const String fixing = "$imagePath/fixing.png";
  static const String industrial = "$imagePath/industrial.png";
  static const String logistic = "$imagePath/logistic.png";
  static const String medical = "$imagePath/medical.png";
  static const String realState = "$imagePath/Realestate.png";
  static const String services = "$imagePath/services.png";
  static const String mwaslat = "$imagePath/transportation.png";
}

class IconAssets {
  static const String menuIcon = "$iconPath/menu.svg";
  static const String medical = "$iconPath/band-aid.svg";
  static const String education = "$iconPath/boy.svg";
  static const String realState = "$iconPath/calculator.svg";
  static const String entertainment = "$iconPath/dribbble.svg";
  static const String fixing = "$iconPath/fixing.svg";
  static const String services = "$iconPath/infinity.svg";
  static const String logistic = "$iconPath/logistics.svg";
  static const String industrial = "$iconPath/performance.svg";
  static const String transportation = "$iconPath/transport.svg";
}

class JsonAssets {
  static const String loading = "$jsonPath/loading.json";
  static const String error = "$jsonPath/error.json";
  static const String empty = "$jsonPath/empty.json";
}
