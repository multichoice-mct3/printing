library agrofad.globals;
String UserType = 'ADMIN';