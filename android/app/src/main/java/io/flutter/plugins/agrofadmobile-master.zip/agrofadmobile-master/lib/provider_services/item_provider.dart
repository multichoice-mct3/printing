
import 'package:agrofad/api/Purchasing_apis.dart';
import 'package:agrofad/api/get_customers-api.dart';
import 'package:agrofad/models/ItemModel.dart';
import 'package:agrofad/models/customer_model.dart';
import 'package:flutter/cupertino.dart';
class ItemProvider extends ChangeNotifier{
  //////items
  PurchasingApi _purchasingApi=PurchasingApi();
  List<Item> _items=List<Item>();
  String _SelectedItemName;
  int _SelectedItemId;

  String get GetSelectedItemName =>_SelectedItemName;
  int get GetSelectedItemId=>_SelectedItemId;
  List<Item> get GetItems=>_items;

  GetItemsFromApi()async{
    _items=await _purchasingApi.GetItems();
    return _items;
  }
  getItemId(String itemName){
    for (Item item in _items) {
      if (item.ItemName == itemName) {
        _SelectedItemId = item.ItemId;
      }
    }
  }

  changeSelectedItem(String itemName ){
    _SelectedItemName =itemName;
    getItemId(itemName);
    notifyListeners();
  }
  ////customers
  GetCustomersApi _customersApi =GetCustomersApi();
  List<Customer> _Customers=List<Customer>();
  List<Customer> get GetCustomers=>_Customers;
GetCustomerFromApi()async{
  _Customers=await _customersApi.GetCustomers();
  return _Customers;
}



}