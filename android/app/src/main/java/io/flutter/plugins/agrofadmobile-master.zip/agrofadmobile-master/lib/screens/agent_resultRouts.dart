import 'package:agrofad/api/get_account_api.dart';
import 'package:agrofad/api/get_emps_api.dart';
import 'package:agrofad/api/get_statment_api.dart';
import 'package:agrofad/custom_widgets/custom_dialoge.dart';
import 'package:agrofad/models/Statment_model.dart';
import 'package:agrofad/models/account_model.dart';
import 'package:agrofad/models/emp+model.dart';
import 'package:agrofad/models/route_model.dart';
import 'package:agrofad/provider_services/agentRouts_provider.dart';
import 'package:agrofad/provider_services/emps_provider.dart';
import 'package:agrofad/provider_services/user_Detail_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../constants.dart';
import 'package:agrofad/custom_widgets/LifeCycleWidget.dart';
import 'package:search_choices/search_choices.dart';
import 'package:intl/intl.dart' as intl;
import 'package:dropdown_date_picker/dropdown_date_picker.dart';
import 'package:awesome_loader/awesome_loader.dart';
import 'package:async/async.dart';
class AgentResultRoutes extends StatefulWidget {
  static String id = 'AgentResultRoutes';
  @override
  _AgentResultRoutesState createState() => _AgentResultRoutesState();
}
class _AgentResultRoutesState extends State<AgentResultRoutes> {
  static final now = DateTime.now();
  static final InitailFrom = DateTime.now().subtract(Duration(days: 30));
  double showHeight = 0;
  int ShowStmt=0;
  //Var Declrations
  String SelectedAccountName;
  String SelectedAccountId;
  String SelectedCostCenterName;
  int SelectedCostCenterId;
  bool done=false;
  String FromDate;
  String ToDate;

  GetEmpsApi _getEmpsApi=GetEmpsApi();
  //get apis method
  //Future GetAccounts;
  GetAllAccountsApi _getAccounts= new GetAllAccountsApi();
  List<Account> Accounts=[];

  GetStatmentApi _getStatmentApi=GetStatmentApi();
  List<StatmentModel> AccountStatment=[];
  Future<List<StatmentModel>> GetSatments()async {
    print(SelectedAccountId);
    print(ToDate);
    print(FromDate);
    AccountStatment=  await _getStatmentApi.Getstatments(SelectedAccountId, ToDate, FromDate);
  }

  final memoizedFuture = AsyncMemoizer();
  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    double ScreenHieght = MediaQuery.of(context).size.height;
    final UserDet = Provider.of<UserDetail>(context,listen: false);
    return SafeArea(
      child: FutureBuilder(
        future:
        memoizedFuture.runOnce(() => Provider.of<EmpsProvider>(context,listen: false).getEmpsFromApi()),
        builder: (BuildContext context,AsyncSnapshot snapshot){
          return Scaffold(
            backgroundColor:snapshot.connectionState==ConnectionState.waiting?Colors.white:KmainColor,
            body:(){
              if (snapshot.connectionState==ConnectionState.done &&snapshot.hasData){
                return Column(
                  children: [
                    // SizedBox(height: 22,),
                    Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        Column(
                          children: [
                            SelectAgentWidget(ScreenWidth),
                            Container(
                              height: showHeight / 2,
                              color: ShowStmt==1?Colors.white:KmainColor,

                            )
                          ],
                        ),
                        LifeCycleWidget(
                          onMounted: (size) => setState(() => showHeight = size.height),
                          child: RaisedButton(
                            color: Colors.amber,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                            ),
                            onPressed: () async{
                              FromDate=FDate.getDate('/');
                              ToDate=TDate.getDate('/');
                              int agentId=Provider.of<EmpsProvider>(context,listen: false).GetEmpId;
                              if(agentId!=null){
                                setState(() {
                                  ShowStmt=1;
                                });
                               await  Provider.of<AgentRoutsProvider>(context,listen: false).
                               getCompletedEmpRoutes(UserDet.GetEmpId, agentId, ToDate, FromDate);
                                if (Provider.of<AgentRoutsProvider>(context,listen: false).GetCompletedEmpRoutes .length>0){
                                  setState(() {
                                    ShowStmt=2;
                                  });
                                }
                                else{
                                  setState(() {
                                    ShowStmt=0;
                                  });
                                  showDialog(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return CustomDialoge(
                                          Anothercontext: context,
                                          Message: 'لا يوجد بيانات ',
                                          Callback: (){
                                            Navigator.of(context).pop();
                                          },
                                           );
                                           });
                                          }
                                             }
                              else{
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return CustomDialoge(
                                        Anothercontext: context,
                                        Message: 'من فضلك قم باختيار المندوب ',
                                        Callback: (){
                                          Navigator.of(context).pop();
                                        },
                                      );
                                    });
                              }
                            },
                            child: Text(
                              'عرض',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontFamily: 'cocon',
                                fontSize: 20,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    ShowStmt==2?Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: ListView.builder(
                            itemCount: Provider.of<AgentRoutsProvider>(context,listen: false).GetCompletedEmpRoutes.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Container(
                                child: CompletedEmpRoutesDet(index),
                              );
                            }),
                      ),
                    ): ShowStmt==1?Expanded(
                      child: Container(
                        color: Colors.white,
                        child: Center(
                          child: Container(

                            height: 30,
                            width: 30,
                            child: AwesomeLoader(
                              loaderType: AwesomeLoader.AwesomeLoader3,
                              color: KmainColor,

                            ),
                          ),
                        ),
                      ),
                    ):Container()
                  ],
                );
              }
              else if (snapshot.hasError)
                return Center(child: Text('${snapshot.error}'));

              else {
                return Center(
                    child: Container(
                      height: 30,
                      width: 30,
                      child: AwesomeLoader(
                        loaderType: AwesomeLoader.AwesomeLoader3,
                        color: KmainColor,
                      ),
                    ));
              }
            }()

          );
        },

      ),
    );
  }

  Widget SelectAgentWidget(double ScreenWidth) {
    return Container(
      color: OfWhiteColor,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 25),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'نتائج مسارات مندوب',
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: KmainColor,
                    fontSize: 22,
                    fontFamily: 'cocon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 15, top: 3),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)),
                    color: Colors.amber,
                    onPressed: () async {
                      Navigator.pop(context);
                    },
                    child: Text(
                      'رجوع',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'cocon',
                          fontSize: 18),
                    ),
                  ),
                )
              ],
            ),
          ),
          GetAgentRow(ScreenWidth),
          SizedBox(
            height: 5,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Row(
                  textDirection: TextDirection.rtl,
                  children: [
                    Text(
                      'من',
                      style: TextStyle(
                          fontSize: 14,
                          color: KmainColor,
                          fontFamily: 'cocon',
                          ),
                    ),
                    SizedBox(
                      width: 2,
                    ),
                    Container(
                        width: 147,
                        height: 35,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10)),
                        child: FDate),
                  ],
                ),

                Row(
                  textDirection: TextDirection.rtl,
                  children: [
                    Text(
                      'الي',
                      style: TextStyle(
                          fontSize: 14,
                          color: KmainColor,
                          fontFamily: 'cocon',
                        ),
                    ),
                    SizedBox(
                      width: 2,
                    ),
                    Container(
                        width: 147,
                        height: 35,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10)),
                        child: TDate)
                  ],
                )
              ],
            ),
          ),
          SizedBox(
            height: 20,
          )
        ],
      ),
    );
  }

  Widget GetAgentRow(double ScreenWidth) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        // height:WidgetHiegt*22/100,
        width: ScreenWidth,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          //  textDirection: TextDirection.rtl,
          children: [
            Directionality(
              textDirection: TextDirection.rtl,
              child: Container(
                //   height: 70,
                width: 92 / 100 * ScreenWidth,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)),
                child: GetAgents(Provider.of<EmpsProvider>(context,listen: false).GetEmps),
              ),
            )
          ],
        ),
      ),
    );
  }



  Widget GetAgents(
      List<Emp> Emps
      ) {
    List<String> EmpsNames =[];
    String Id;
    for (Emp emp in Emps) {
      EmpsNames.add(emp.EmpName);
    }
    return Consumer<EmpsProvider>(
      builder: (ctx,EmpProvid,ch){
        return SearchChoices.single(
          items: EmpsNames.map<DropdownMenuItem<String>>((string) {
            return (DropdownMenuItem<String>(
              child: SizedBox(
                width: 300,
                child: Text(
                  string,
                  textDirection: TextDirection.rtl,
                  softWrap: false,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style:
                  TextStyle(
                    fontSize: 17, fontFamily: 'cocon', color: KmainColor,
                  ),
                ),
              ),
              value: string,
            ));
          }).toList(),
          menuBackgroundColor: OfWhiteColor,
          value: EmpProvid.GetEmpName,
          hint: Text(
            "اختر المندوب",
            textDirection: TextDirection.rtl,
            style: TextStyle(fontSize: 16, fontFamily: 'cocon', color: KmainColor),
          ),
          searchHint: Text(
            "اختر المندوب",
            textDirection: TextDirection.rtl,
            style: TextStyle(fontSize: 16, fontFamily: 'cocon', color: KmainColor),
          ),
          closeButton: FlatButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text(
              "اغلاق",
              textDirection: TextDirection.rtl,
              style: TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 16, color: KmainColor),
            ),
          ),
          underline: Container(
            height: 0,
            padding: EdgeInsets.all(0),
          ),
          clearIcon: Icon(
            Icons.clear,
            color: Colors.red,
            size: 20,
          ),
          icon: Icon(
            Icons.arrow_drop_down,
            size: 25,
            color: KmainColor,
          ),

          onClear: (){
            EmpProvid.clearEmpId();
          },
          onChanged: (value) {
            EmpProvid.changeSelectedEmp(value);
          },
          isExpanded: true,
          rightToLeft: true,
          displayItem: (item, selected) {
            return (Row(textDirection: TextDirection.rtl, children: [
              selected
                  ? Icon(
                Icons.radio_button_checked,
                color: Colors.grey,
              )
                  : Icon(
                Icons.radio_button_unchecked,
                color: Colors.grey,
              ),
              SizedBox(width: 7),
              item,
              Expanded(
                child: SizedBox.shrink(),
              ),
            ]));
          },
          selectedValueWidgetFn: (item) {
            return Row(
              textDirection: TextDirection.rtl,
              children: <Widget>[
                SizedBox(
                  width: 280,
                  child: (Text(
                    item,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    softWrap: false,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                        fontSize: 15, fontFamily: 'cocon', color: KmainColor),
                  )),
                ),
              ],
            );
          },
        );
      },

    );
  }

  final FDate=DropdownDatePicker(
    firstDate: ValidDate(year: now.year - 100, month: 1, day: 1),
    lastDate: ValidDate(year: now.year, month: now.month, day: now.day),
    textStyle: TextStyle(
      color: KmainColor,
      fontSize: 14,
    ),
    dropdownColor: Colors.blue[200],
    dateHint: DateHint(year: 'yyyy', month: 'mm', day: 'dd'),
    ascending: false,
    underLine: Container(
      width: 0,
      height: 0,
      padding: EdgeInsets.all(0),
    ),
    initialDate: ValidDate(year: now.year, month: now.month, day: now.day),
  );
  final TDate=DropdownDatePicker(
    firstDate: ValidDate(year: now.year - 100, month: 1, day: 1),
    lastDate: ValidDate(year: now.year, month: now.month, day: now.day),
    textStyle: TextStyle(
      color: KmainColor,
      fontSize: 14,
    ),
    dropdownColor: Colors.blue[200],
    dateHint: DateHint(year: 'yyyy', month: 'mm', day: 'dd'),
    ascending: false,
    underLine: Container(
      width: 0,
      height: 0,
      padding: EdgeInsets.all(0),
    ),
    initialDate: ValidDate(year: now.year, month: now.month, day: now.day),
  );
  Widget CompletedEmpRoutesDet(int index) {
   List<AgentVisitRouteModel>_CompletedEmpRoutes=Provider.of<AgentRoutsProvider>(context,listen: false).GetCompletedEmpRoutes;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: LayoutBuilder(
        builder: (context, constarints) {
          double localWidth = constarints.maxWidth;
          double LocalHight = constarints.maxHeight;
          return Column(
            children: [
              //first
              Container(
                width: localWidth,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(10),
                    topLeft: Radius.circular(10),
                  ),
                  color: Colors.white,
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Expanded(
                          flex: 4,
                          child: Row(
                            textDirection: TextDirection.rtl,
                            children: [
                              Container(
                                  child: Text(
                                    ':التاريخ',
                                    textAlign: TextAlign.end,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15,
                                        fontFamily: 'cocon',
                                        color: KmainColor),
                                  )),
                              SizedBox(
                                width: 5,
                              ),
                              Container(
                                  child: Text(
                                    // '2020/01/19',
                                    _CompletedEmpRoutes[index].AVRDate,
                                    textAlign: TextAlign.end,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15,
                                        fontFamily: 'cocon',
                                        color: BlackColor),
                                  )),
                            ],
                          )),
                      Expanded(
                        flex: 7,
                        child: Row(
                          textDirection: TextDirection.rtl,
                          children: [
                            Text(
                              ':سبب الزيارة',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                  fontFamily: 'cocon',
                                  color: KmainColor),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            SizedBox(
                              width: 156,
                              child: Text(
                                _CompletedEmpRoutes[index].AVCName,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                softWrap: false,
                                textAlign: TextAlign.end,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    fontFamily: 'cocon',
                                    color: KmainColor),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                width: localWidth,
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Text(
                        ':العميل',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            fontFamily: 'cocon',
                            color: KmainColor),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        _CompletedEmpRoutes[index].CustomerName,
                        textAlign: TextAlign.end,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            fontFamily: 'cocon',
                            color: BlackColor),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                width: localWidth,
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        textDirection: TextDirection.rtl,
                        children: [
                          Container(
                              child: Text(
                                ' :المندوب',
                                textAlign: TextAlign.end,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    fontFamily: 'cocon',
                                    color: KmainColor),
                              )),
                          SizedBox(
                            width: 5,
                          ),
                          Container(
                              child: Text(
                                _CompletedEmpRoutes[index].EmpName,
                                textAlign: TextAlign.end,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    fontFamily: 'cocon',
                                    color: BlackColor),
                              )),
                        ],
                      ),
                      Row(
                        textDirection: TextDirection.rtl,
                        children: [
                          Container(
                              child: Text(
                                ' :حالة الزيارة',
                                textAlign: TextAlign.end,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    fontFamily: 'cocon',
                                    color: KmainColor),
                              )),
                          SizedBox(
                            width: 5,
                          ),
                          Container(
                              child: Text(
                                _CompletedEmpRoutes[index].AVRStatus==97402?"تمت الزيارة":
                                _CompletedEmpRoutes[index].AVRStatus==97403?"ملغية من المندوب":
                                _CompletedEmpRoutes[index].AVRStatus==97404?"ملغية من المدير":'',
                                textAlign: TextAlign.start,
                                style: TextStyle(

                                    fontSize: 12,
                                    fontFamily: 'cocon',
                                    color:_CompletedEmpRoutes[index].AVRStatus==97402? Colors.amber:Colors.red),
                              )),
                        ],
                      ),
                    ],
                  )
                ),
              ),
              Container(
                  width: localWidth,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(10),
                        bottomLeft: Radius.circular(10)),
                    color: Colors.white,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      textDirection: TextDirection.rtl,
                      children: [
                        Text(
                          ':نتيجة الزيارة',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              fontFamily: 'cocon',
                              color: KmainColor),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Expanded(
                          child: Text(
                            _CompletedEmpRoutes[index].ManualResultNote==null?"لم يتم ادخال نتيجة الزيارة"
                                :(_CompletedEmpRoutes[index].ManualResultNote)
                                .toString(),
                                style: TextStyle(
                                fontSize: 14,
                                fontFamily: 'cocon',
                                fontWeight: FontWeight.bold,
                                color: BlackColor),
                            textAlign: TextAlign.end,
                          ),
                        ),
                      ],
                    ),
                  )),
            ],
          );
        },
      ),
    );
  }
}
