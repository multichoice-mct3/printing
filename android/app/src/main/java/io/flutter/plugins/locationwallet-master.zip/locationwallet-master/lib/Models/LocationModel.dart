class LocationModel {
  int locationWalletId;
  String userName;
  String userPhoneNumber;
  double mapLatitude;
  double mapLongitude;
  String locationName;
  String locationDescription;

  LocationModel(
      {this.locationWalletId,
      this.userName,
      this.userPhoneNumber,
      this.mapLatitude,
      this.mapLongitude,
      this.locationName,
      this.locationDescription});

  LocationModel.fromJson(Map<String, dynamic> json) {
    locationWalletId = json['locationWalletId'];
    userName = json['userName'];
    userPhoneNumber = json['userPhoneNumber'];
    mapLatitude = json['mapLatitude'];
    mapLongitude = json['mapLongitude'];
    locationName = json['locationName'];
    locationDescription = json['locationDescription'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['locationWalletId'] = this.locationWalletId;
    data['userName'] = this.userName;
    data['userPhoneNumber'] = this.userPhoneNumber;
    data['mapLatitude'] = this.mapLatitude;
    data['mapLongitude'] = this.mapLongitude;
    data['locationName'] = this.locationName;
    data['locationDescription'] = this.locationDescription;
    return data;
  }
}
