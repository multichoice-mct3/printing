import 'package:LocarionWallet/Constants/DefaultAppBar.dart';
import 'package:LocarionWallet/Constants/MyColors.dart';
import 'package:LocarionWallet/Constants/MyText.dart';
import 'package:LocarionWallet/Public/Provider/LocationProvider.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:LocarionWallet/Public/resources/GeneralHttpMethods.dart';
import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:LocarionWallet/Constants/someData.dart';

class SavedPlaces extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // context.read<LocationProvider>().getUserLocation();
    context.read<LocationProvider>().getLocations();
    return Scaffold(
        appBar: DefaultAppBar(
          title: tr("saved_locations"),
          con: context,
          back: true,
        ),
        body: Consumer<LocationProvider>(
          builder: (context, places, child) => RefreshIndicator(
            child: ListView.separated(
              physics: BouncingScrollPhysics(),
              shrinkWrap: true,
              itemCount: places.filterdLocations.length,
              separatorBuilder: (BuildContext con, int index) {
                return Divider(
                  color: Colors.grey[400],
                  indent: 15,
                  thickness: 2,
                  endIndent: 0,
                );
              },
              itemBuilder: (BuildContext con, int index) {
                return InkWell(
                  onTap: () => MapUtils.launchMapsUrl(
                      context.read<LocationProvider>().getLat,
                      context.read<LocationProvider>().getLong,
                      places.locations[index].mapLatitude,
                      places.locations[index].mapLongitude),
                  child: Container(
                    margin: EdgeInsets.all(10),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.location_pin,
                                    color: Colors.red,
                                  ),
                                  Expanded(
                                    child: MyText(
                                      title: places
                                          .filterdLocations[index].locationName,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 15),
                              Row(
                                children: [
                                  Icon(
                                    Icons.description_rounded,
                                    color: MyColors.primary,
                                  ),
                                  Expanded(
                                    child: MyText(
                                      title: places.filterdLocations[index]
                                          .locationDescription,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        MyIconButton(
                            color: Colors.blueAccent[400],
                            icon: Icons.edit,
                            onTap: () => ExtendedNavigator.root
                                    .push(Routes.locationDetails, arguments: {
                                  'exampleArgument':
                                      places.filterdLocations[index]
                                })),
                        MyIconButton(
                          color: Colors.redAccent[400],
                          icon: Icons.delete,
                          onTap: () => context
                              .read<LocationProvider>()
                              .removeLocation(places.filterdLocations[index]),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            onRefresh: () {
              return GeneralHttpMethods().getLocations();
            },
          ),
        ));
  }
}

class MyIconButton extends StatelessWidget {
  const MyIconButton({
    Key key,
    @required this.onTap,
    @required this.color,
    @required this.icon,
  }) : super(key: key);

  final Function onTap;
  final Color color;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 10),
        padding: EdgeInsets.all(10),
        child: Icon(
          icon,
          color: Colors.white,
          size: 18,
        ),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 5,
              spreadRadius: 6,
              offset: Offset(0, 1),
            )
          ],
        ),
      ),
    );
  }
}

// Consumer<LocationProvider>(
//           builder: (ctx, places, child) {
//             return RefreshIndicator(
//               child: ListView.separated(
//                 physics: BouncingScrollPhysics(),
//                 shrinkWrap: true,
//                 itemCount: places.locations.length,
//                 separatorBuilder: (BuildContext con, int index) {
//                   return Divider(
//                     color: Colors.grey[400],
//                     indent: 15,
//                     thickness: 2,
//                     endIndent: 0,
//                   );
//                 },
//                 itemBuilder: (BuildContext con, int index) {
//                   print(places.locations[index].locationWalletId);
//                   return InkWell(
//                     onTap: () => MapUtils.launchMapsUrl(
//                         context.read<LocationProvider>().getLat,
//                         context.read<LocationProvider>().getLong,
//                         places.locations[index].mapLatitude,
//                         places.locations[index].mapLongitude),
//                     child: Container(
//                       margin: EdgeInsets.all(10),
//                       child: Row(
//                         children: [
//                           Expanded(
//                             child: Column(
//                               children: [
//                                 Row(
//                                   children: [
//                                     Icon(
//                                       Icons.location_pin,
//                                       color: Colors.red,
//                                     ),
//                                     Expanded(
//                                       child: MyText(
//                                         title: places
//                                             .locations[index].locationName,
//                                         overflow: TextOverflow.ellipsis,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                                 SizedBox(height: 15),
//                                 Row(
//                                   children: [
//                                     Icon(
//                                       Icons.description_rounded,
//                                       color: MyColors.primary,
//                                     ),
//                                     Expanded(
//                                       child: MyText(
//                                         title: places.locations[index]
//                                             .locationDescription,
//                                         overflow: TextOverflow.ellipsis,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                           MyIconButton(
//                               color: Colors.blueAccent[400],
//                               icon: Icons.edit,
//                               onTap: () => MyRoute().navigate(
//                                   withReplace: true,
//                                   context: context,
//                                   route: LocationDetails(
//                                     location: places.locations[index],
//                                   ))),
//                           MyIconButton(
//                             color: Colors.redAccent[400],
//                             icon: Icons.delete,
//                             onTap: () => context
//                                 .read<LocationProvider>()
//                                 .removeLocation(places.locations[index]),
//                           ),
//                         ],
//                       ),
//                     ),
//                   );
//                 },
//               ),
//               onRefresh: () {
//                 return places.getLocations();
//               },
//             );
//           },
//         )
