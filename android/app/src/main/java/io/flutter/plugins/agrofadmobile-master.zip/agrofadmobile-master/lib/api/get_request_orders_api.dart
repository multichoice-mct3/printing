import 'dart:convert';
import 'package:agrofad/models/AddOrderedSupply_model.dart';
import 'package:agrofad/models/customer_model.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'login_apis.dart';

class GetRequstsApi {
  String UserType;
  int EmpId;
  int UserId;

  Future<void> getUserDateail()async{
    final prefs = await SharedPreferences.getInstance();
    UserType = prefs.getString("UserType");
    EmpId = prefs.getInt("EmpID");
    UserId=prefs.getInt('UserId');
  }
  LoginApi loginApi = new LoginApi();
  List <OrderedSupplyModel>RequstOrders=[];
  String BaseUrl = 'http://104.196.134.107/AfitAPI';
  Future<List <OrderedSupplyModel>> GetUserRequsts() async {
    await loginApi.getAccessToken();
    await  getUserDateail();
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var response;
    if (UserType=="ADMIN"){
       response = await http.get("http://104.196.134.107/AfitAPI/api/GetRequestOrderView",
          headers: Headers);
    }

        else{
         response = await http.get("http://104.196.134.107/AfitAPI/api/GetRequestOrderView/$EmpId",
          headers: Headers);
           }


    if (response.statusCode == 200) {
      RequstOrders= ParseItems(response.body);

    } else {
      print(response.body);
    }
    return RequstOrders;
  }
  //fn get the item list
  List<OrderedSupplyModel> ParseItems(String responseBody) {
    final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();

    return parsedItems.map<OrderedSupplyModel>((json) => OrderedSupplyModel.fromJson(json)).toList();
  }

}
