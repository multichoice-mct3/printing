// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouteGenerator
// **************************************************************************

// ignore_for_file: public_member_api_docs

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';

import '../../Home.dart';
import '../../Models/LocationModel.dart';
import '../Screens/LocationScreen.dart';
import '../Screens/LoginScreen.dart';
import '../Screens/Regestration.dart';
import '../Screens/Splash.dart';
import '../Screens/savedPlaces.dart';

class Routes {
  static const String splash = '/';
  static const String userLogin = '/user-login';
  static const String registeration = '/Registeration';
  static const String home = '/Home';
  static const String savedPlaces = '/saved-places';
  static const String locationDetails = '/location-details';
  static const all = <String>{
    splash,
    userLogin,
    registeration,
    home,
    savedPlaces,
    locationDetails,
  };
}

class AppRouter extends RouterBase {
  @override
  List<RouteDef> get routes => _routes;
  final _routes = <RouteDef>[
    RouteDef(Routes.splash, page: Splash),
    RouteDef(Routes.userLogin, page: UserLogin),
    RouteDef(Routes.registeration, page: Registeration),
    RouteDef(Routes.home, page: Home),
    RouteDef(Routes.savedPlaces, page: SavedPlaces),
    RouteDef(Routes.locationDetails, page: LocationDetails),
  ];
  @override
  Map<Type, AutoRouteFactory> get pagesMap => _pagesMap;
  final _pagesMap = <Type, AutoRouteFactory>{
    Splash: (data) {
      return MaterialPageRoute<dynamic>(
        builder: (context) => Splash(),
        settings: data,
      );
    },
    UserLogin: (data) {
      return PageRouteBuilder<dynamic>(
        pageBuilder: (context, animation, secondaryAnimation) => UserLogin(),
        settings: data,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade,
      );
    },
    Registeration: (data) {
      return PageRouteBuilder<dynamic>(
        pageBuilder: (context, animation, secondaryAnimation) =>
            Registeration(),
        settings: data,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade,
      );
    },
    Home: (data) {
      return PageRouteBuilder<dynamic>(
        pageBuilder: (context, animation, secondaryAnimation) => Home(),
        settings: data,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade,
      );
    },
    SavedPlaces: (data) {
      return PageRouteBuilder<dynamic>(
        pageBuilder: (context, animation, secondaryAnimation) => SavedPlaces(),
        settings: data,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade,
      );
    },
    LocationDetails: (data) {
      final args = data.getArgs<LocationDetailsArguments>(nullOk: false);
      return PageRouteBuilder<dynamic>(
        pageBuilder: (context, animation, secondaryAnimation) =>
            LocationDetails(
          key: args.key,
          location: args.location,
        ),
        settings: data,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade,
      );
    },
  };
}

/// ************************************************************************
/// Arguments holder classes
/// *************************************************************************

/// LocationDetails arguments holder class
class LocationDetailsArguments {
  final Key key;
  final LocationModel location;
  LocationDetailsArguments({this.key, @required this.location});
}
