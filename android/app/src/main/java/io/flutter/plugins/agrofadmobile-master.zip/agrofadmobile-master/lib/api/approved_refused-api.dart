
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:agrofad/models/post_account_det.dart';

import 'login_apis.dart';

class SendStatusApi{
  LoginApi loginApi = new LoginApi();
  bool done;
  Future<bool> SendApprovedorRefusedOrder(int index,String Type)async {

    await loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var Response;
if (Type=='Refused') {
  Response = await http.post(
      'http://104.196.134.107/AfitAPI/api/RefuseRequestOrder/$index',
      headers: Headers
  );
}

    if (Type=='Approved') {
      Response = await http.post(
          'http://104.196.134.107/AfitAPI/api/ApproveRequestOrder/$index',
          headers: Headers
      );
    }
    if (Response.statusCode==204){
      done=true;
                      }
    else {
      var PostResult=jsonDecode(Response.body);
    done =false;
      print(PostResult);
    }

return done;

  }

}