import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:octpedia/App/Utilities/size_config.dart';
import 'package:octpedia/Domain/home_model.dart';
import 'package:octpedia/Presentation/Home/ad_slider.dart';
import 'package:octpedia/Presentation/Resources/assets_manager.dart';
import 'package:octpedia/Presentation/Resources/color_manager.dart';
import 'package:octpedia/Presentation/Resources/font_manager.dart';
import 'package:octpedia/Presentation/Resources/values_manager.dart';
import 'package:octpedia/Presentation/widgets/search_bar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _controller = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          controller: _controller,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(AppMargin.m14),
                child: Row(
                  children: [
                    Row(
                      children: [
                        Text(
                          tr('welcome'),
                          style: Theme.of(context).textTheme.subtitle1,
                        ),
                      ],
                    ),
                    const Spacer(),
                    SvgPicture.asset(IconAssets.menuIcon, height: AppSize.s20),
                  ],
                ),
              ),
              const AdsSlider(),
              CategoriesGridView(searchController: _searchController),
              HomeContainer(
                title: "عروض مختارة",
                homeItems: List.generate(
                    3,
                    (index) => const HomeItem(
                          title: 'بن العميد',
                          subtitle: 'عروض الجمعة البيضاء',
                          image: ImageAssets.splashLogo,
                        )),
              ),
              HomeContainer(
                title: "مفضلاتي",
                isFavourite: true,
                homeItems: List.generate(
                    3,
                    (index) => const HomeItem(
                          isFavourite: true,
                          title: 'ناصية زمان',
                          subtitle: 'عروض بمناسبة افتتاح الفرع الجديد',
                          image: ImageAssets.splashLogo,
                        )),
              ),
              HomeContainer(
                title: "عروضي",
                homeItems: List.generate(
                    3,
                    (index) => const HomeItem(
                          title: 'بن العميد',
                          subtitle: 'عروض الجمعة البيضاء',
                          image: ImageAssets.splashLogo,
                        )),
              ),
              const SizedBox(height: AppSize.s20),
            ],
          ),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class HomeContainer extends StatelessWidget {
  const HomeContainer({
    Key? key,
    required String title,
    required List<HomeItem> homeItems,
    bool isFavourite = false,
  })  : _title = title,
        _homeItems = homeItems,
        _isFavourite = isFavourite,
        super(key: key);
  final String _title;
  final List<HomeItem> _homeItems;
  final bool _isFavourite;
  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          margin: const EdgeInsets.symmetric(vertical: AppMargin.m20),
          padding: const EdgeInsets.symmetric(
              horizontal: AppPadding.p12, vertical: AppPadding.p18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppSize.s28),
            color: Colors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                _title,
                style: _isFavourite
                    ? Theme.of(context)
                        .textTheme
                        .headline2
                        ?.copyWith(color: ColorManager.favourite)
                    : Theme.of(context).textTheme.headline2,
              ),
              Column(children: _homeItems),
            ],
          ),
        ),
        Positioned(
            bottom: -5,
            right: SizeConfig.screenWidth! * .5 - 25,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: ColorManager.favourite,
              ),
              child: IconButton(
                onPressed: () => print("object"),
                icon: const Icon(Icons.add),
                color: Colors.white,
              ),
            ))
      ],
    );
  }
}

class HomeItem extends StatelessWidget {
  const HomeItem(
      {Key? key,
      required String title,
      required String subtitle,
      required String image,
      bool isFavourite = false})
      : _title = title,
        _isFavourite = isFavourite,
        _image = image,
        _subtitle = subtitle,
        super(key: key);
  final String _title;
  final String _subtitle;
  final bool _isFavourite;
  final String _image;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        children: [
          Container(
            height: AppSize.s60,
            decoration: BoxDecoration(
                color: Colors.amber,
                borderRadius: BorderRadius.circular(AppSize.s14)),
            child: Image.asset(
              _image,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: AppSize.s12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_title,
                    style: _isFavourite
                        ? Theme.of(context).textTheme.headline3?.copyWith(
                            color: ColorManager.favourite,
                            fontSize: FontSize.s18)
                        : Theme.of(context).textTheme.headline3),
                _isFavourite
                    ? const SizedBox()
                    : Text(
                        _subtitle,
                        style: Theme.of(context).textTheme.subtitle1,
                      ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => print("object"),
            icon: Icon(
              _isFavourite
                  ? Icons.favorite_rounded
                  : Icons.favorite_border_rounded,
            ),
            color: ColorManager.favourite,
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(
          horizontal: AppPadding.p12, vertical: AppPadding.p8),
      margin: const EdgeInsets.symmetric(vertical: AppMargin.m8),
      decoration: BoxDecoration(
          color: _isFavourite
              ? ColorManager.favourite.withOpacity(.1)
              : ColorManager.white,
          borderRadius: BorderRadius.circular(AppSize.s14)),
    );
  }
}

class CategoriesGridView extends StatelessWidget {
  const CategoriesGridView({
    Key? key,
    required TextEditingController searchController,
  })  : _searchController = searchController,
        super(key: key);

  final TextEditingController _searchController;
  @override
  Widget build(BuildContext context) {
    return Container(
        height: SizeConfig.screenHeight! * 1.9,
        padding: const EdgeInsets.all(AppMargin.m8),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(AppSize.s28)),
        child: Column(
          children: [
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppPadding.p12),
              child: SearchInput(
                  textController: _searchController,
                  hintText: 'ابحث في الخدمات'),
            ),
            Expanded(
              child: StaggeredGridView.countBuilder(
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(
                    horizontal: AppMargin.m12, vertical: AppMargin.m18),
                crossAxisCount: 4,
                itemCount: homeCategories.length,
                itemBuilder: (BuildContext context, int index) => Container(
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  padding: const EdgeInsets.all(AppPadding.p8),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage(homeCategories[index].image))),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Expanded(
                        child: Align(
                          alignment: const AlignmentDirectional(-0.85, -1),
                          child: Text(
                            homeCategories[index].title,
                            style: Theme.of(context).textTheme.bodyText1,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Align(
                          alignment: const AlignmentDirectional(0.85, 1),
                          child: Container(
                            width: 50,
                            height: 50,
                            padding: const EdgeInsets.all(AppPadding.p12),
                            decoration: BoxDecoration(
                              color: homeCategories[index].iconColor,
                              shape: BoxShape.circle,
                            ),
                            child: SvgPicture.asset(homeCategories[index].icon),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                staggeredTileBuilder: (int index) =>
                    StaggeredTile.count(2, index.isEven ? 3 : 2.5),
                mainAxisSpacing: 20.0,
                crossAxisSpacing: 20.0,
              ),
            ),
          ],
        ));
  }
}
