import 'package:agrofad/constants.dart';
import 'package:agrofad/screens/user_login.dart';
import 'package:flutter/material.dart';
import 'package:splashscreen/splashscreen.dart';

class SplashWidget extends StatelessWidget {
  static String id= 'SplashWidget';
  //
  // int empID;
  // Future<void> getAccessToken() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   setState(() {
  //     empID = prefs.getInt("EmpID");
  //   });
  // }
  @override
  Widget build(BuildContext context) {
    return SplashScreen(
      backgroundColor: ErpMainColor,
      seconds: 3,
      navigateAfterSeconds: UserLogin.id,
      // title: new Text(
      //   'MiniCode GeeKs',
      //   textScaleFactor: 2,
      //   style: TextStyle(
      //       fontFamily: 'cocon',
      //       color: KmainColor,
      //       fontWeight: FontWeight.bold
      //
      //   ),
      // ),
      image: Image.asset('assets/Agrofad.png'),
      loadingText: Text("loading",
        style: TextStyle(
            fontSize: 25,
            color: KmainColor,
            fontFamily: 'cocon'
        ),
      ),
      photoSize: 120.0,
      loaderColor: KmainColor,
    );
  }
}
