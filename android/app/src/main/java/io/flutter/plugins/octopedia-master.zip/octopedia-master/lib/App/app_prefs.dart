import 'package:octpedia/App/Utilities/cach_helper.dart';

import '../presentation/resources/language_manager.dart';

const String prefsKeyLang = "PREFS_KEY_LANG";

class AppPreferences {
  Future<String> getAppLanguage() async {
    String? language = CachHelper.getData(key: prefsKeyLang);

    if (language != null && language.isNotEmpty) {
      return language;
    } else {
      return LanguageType.english.getValue();
    }
  }
}
