import '../../models/ItemsModel.dart';
import '../Http.dart';

class ItemsAPI {
  HttpMethods _http = HttpMethods();
  Future<List<Items>> getItemsFromApi() async {
    List<Items> items = [];
    var _data = await _http.getData(url: "item");
    if (_data != null) {
      List<Map<String, dynamic>> _itemsJson =
          List<Map<String, dynamic>>.from(_data);
      items = _itemsJson.map((item) => Items.fromJson(item)).toList();
      return items;
    }

    return items;
  }
}
