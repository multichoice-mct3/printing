package com.minicode.mandoboct

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
