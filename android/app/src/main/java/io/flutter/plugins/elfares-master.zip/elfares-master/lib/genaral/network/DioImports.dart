import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:elfares/genaral/constants/LoadingDialog.dart';
import 'package:elfares/genaral/utilities/CachHelper.dart';
import 'package:elfares/genaral/utilities/GlobalState.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

part 'DioHelper.dart';
