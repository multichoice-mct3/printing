
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
class UserDetail extends ChangeNotifier{
  String _UType='ADMIN';
  int _UserId;
  String _UserName;
  int _EmpId;


  String get GetUType => _UType;
  String get GetUserName => _UserName;

  int get GetUserId =>_UserId;
  int get GetEmpId =>_EmpId;


  ChangeUserType(String us,int EmpId){
    _EmpId=EmpId;
    _UType=us;
    notifyListeners();
  }

}