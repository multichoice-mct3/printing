import 'package:elfares/genaral/constants/DefaultAppBar.dart';
import 'package:elfares/genaral/network/Http.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import '../genaral/constants/MyColors.dart';
import '../genaral/constants/MyText.dart';
import '../genaral/constants/constants.dart';
import '../genaral/utilities/SizeConfig.dart';
import '../genaral/constants/AnimationContainer.dart';

// ignore: must_be_immutable
class Home extends StatelessWidget {
  Home({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    // CachHelper.clearData();

    return Scaffold(
      backgroundColor: MyColors.primary,
      appBar: DefaultAppBar(title: "القائمة الرئيسية", leading: SizedBox()),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // IconButton(onPressed: () => HttpMethods().sessionExpired(), icon: Icon(Icons.ac_unit)),
          Expanded(
            child: AnimationContainer(
              index: 1,
              distance: 100,
              vertical: true,
              child: Container(
                padding: const EdgeInsets.only(top: 30),
                decoration: BoxDecoration(
                    color: MyColors.white,
                    borderRadius: BorderRadius.vertical(
                        top: Radius.elliptical(
                            SizeConfig.screenWidth! * .9, 50))),
                child: AnimationLimiter(
                  child: GridView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2, childAspectRatio: 1.5),
                    itemCount: homeItems().length,
                    itemBuilder: (BuildContext context, int index) {
                      return AnimationConfiguration.staggeredList(
                        position: index,
                        duration: const Duration(milliseconds: 700),
                        child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                            child: GestureDetector(
                              onTap: () =>
                                  homeItems(context: context)[index].onTap(),
                              child: Container(
                                clipBehavior: Clip.antiAliasWithSaveLayer,
                                margin: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  boxShadow: kBoxShadow,
                                  color: MyColors.white,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(5),
                                      decoration: BoxDecoration(
                                          color: MyColors.primary,
                                          borderRadius: BorderRadius.vertical(
                                              bottom: Radius.elliptical(
                                                  SizeConfig.screenWidth! * .8,
                                                  50))),
                                      child: Container(
                                          padding: EdgeInsets.all(10),
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            shape: BoxShape.circle,
                                          ),
                                          child: Image.asset(
                                            homeItems()[index].icon,
                                            width: 30,
                                            height: 30,
                                          )),
                                    ),
                                    MyText(
                                      title: homeItems()[index].name,
                                      alien: TextAlign.center,
                                      color: MyColors.primary,
                                      size: 12,
                                    ),
                                    SizedBox()
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
