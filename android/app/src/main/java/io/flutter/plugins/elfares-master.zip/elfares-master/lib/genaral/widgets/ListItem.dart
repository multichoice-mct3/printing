part of "WidgetsImport.dart";

class ListItem extends StatelessWidget {
  const ListItem({
    Key? key,
    required this.index,
    required this.desc,
    required this.total,
  }) : super(key: key);
  final String index, desc, total;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 1,
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 2),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            color: Colors.white,
            child: MyText(
              title: "$index",
              size: 12,
            ),
          ),
        ),
        Expanded(
          flex: 4,
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 2),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(color: Colors.white),
            child: MyText(
              title: "$desc",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              size: 12,
            ),
          ),
        ),
        Expanded(
          flex: 2,
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 2),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            color: Colors.white,
            child: MyText(
              title: "$total",
              size: 12,
            ),
          ),
        ),
      ],
    );
  }
}
