import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:mandoboct/General/Constants/MyText.dart';
import 'package:mandoboct/DesktopHomeScreen.dart';
import 'package:mandoboct/General/Provider/CategoriesProvider.dart';
import 'package:mandoboct/General/Provider/MainProvider.dart';
import 'package:mandoboct/General/Provider/provider.dart';
import 'package:mandoboct/MobileHomeScreen.dart';
import 'package:mandoboct/Screens/auth/LoginContent.dart';
import 'package:provider/provider.dart';
import '../../General/Utilities/SizeConfig.dart';
import '../General/Constants/constants.dart';
import '../General/Constants/AnimationContainer.dart';
import '../General/Constants/MyColors.dart';
import '../General/Constants/MyRoute.dart';
import 'package:flutter/material.dart';

class Splash extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  // String token = CachHelper.getData(key: "token") ?? "";
  @override
  void initState() {
    super.initState();

    Future.delayed(Duration(seconds: 3), () async {
      await context.read<CategoriesProvider>().getCategories();
      await context.read<MokademKhedma>().getProviders();
      await context.read<MainProvider>().getUserLocation();
      // if (token != "" || context.read<AuthProvider>().isSignIn) {
      print(Platform.isWindows || kIsWeb);
      // if (Platform.isAndroid || Platform.isIOS) {
      //   MyRoute().navigateAndRemove(context: context, route: MobileHome());
      // } else {
      //   MyRoute().navigateAndRemove(context: context, route: DesktopHome());
      // }

      // } else {
      MyRoute().navigateAndRemove(context: context, route: LoginContent());
      // }
    });
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 50),
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(color: MyColors.white),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(),
            MyText(
              title: "Welcome to Octpedia Bussiness",
              size: 20,
            ),
            AnimationContainer(
              index: 1,
              distance: 100,
              vertical: true,
              child: Container(
                padding: EdgeInsets.all(40),
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: kBoxShadow,
                ),
                child: Container(
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  decoration: BoxDecoration(
                    color: MyColors.bg,
                    shape: BoxShape.circle,
                    boxShadow: kBoxShadow,
                  ),
                  child: Image.asset(
                    "assets/images/splash.png",
                    width: 200,
                    height: 200,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            const SizedBox(),
          ],
        ),
      ),
    );
  }
}
