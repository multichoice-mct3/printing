import 'package:elfares/genaral/constants/MyRoute.dart';
import 'package:elfares/genaral/models/HomeModel.dart';
import 'package:elfares/user/HomeScreens/HomeImports.dart';
import 'package:flutter/material.dart';

const List<BoxShadow> kBoxShadow = [
  BoxShadow(
    color: Colors.black12,
    blurRadius: 8,
    spreadRadius: 6,
    offset: Offset(0, 2),
  )
];
const List<BoxShadow> kBoxShadow2 = [
  BoxShadow(
    color: Colors.black12,
    blurRadius: 10,
    spreadRadius: 1,
    offset: Offset(2, 6),
  )
];

List<HomeModel> homeItems({BuildContext? context}) => [
      HomeModel("فاتورة بيع", "assets/icons/InV_OUT.png",
          () => MyRoute().navigate(context: context!, route: SellingInvoice())),
      HomeModel(
          "فاتورة شراء",
          "assets/icons/InV_IN.png",
          () => MyRoute()
              .navigate(context: context!, route: PurchasingInvoice())),
      HomeModel("فواتير بيع", "assets/icons/InV_OUT.png",
          () => MyRoute().navigate(context: context!, route: SellingBills())),
      HomeModel(
          "فواتير شراء",
          "assets/icons/InV_IN.png",
          () =>
              MyRoute().navigate(context: context!, route: PurchasingBills())),
      HomeModel("سند صرف", "assets/icons/Bill_In.png",
          () => MyRoute().navigate(context: context!, route: RecieptVoucher())),
      HomeModel("سند قبض", "assets/icons/Bill_Out.png",
          () => MyRoute().navigate(context: context!, route: PaymentVoucher())),
      HomeModel("قائمة الدخل", "assets/icons/Income.png",
          () => MyRoute().navigate(context: context!, route: IncomeStatment())),
      HomeModel("رصيد مخزن", "assets/icons/Store.png",
          () => MyRoute().navigate(context: context!, route: StoreBalance())),
      HomeModel(
          "حركة خزينة",
          "assets/icons/Treasury.png",
          () => MyRoute()
              .navigate(context: context!, route: TreasureAccountStatement())),
      HomeModel(
          "كشف حساب",
          "assets/icons/statement.png",
          () =>
              MyRoute().navigate(context: context!, route: AccountStatment())),
      HomeModel(
          "تقرير اذونات التحويل",
          "assets/icons/transfer.png",
          () => MyRoute()
              .navigate(context: context!, route: StoresTransferReports())),
      HomeModel("تحويل بين مخازن", "assets/icons/transfer.png",
          () => MyRoute().navigate(context: context!, route: StoresTransfer())),
    ];

Gradient setGradientColo(List<Color> colors) {
  return LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: colors);
}

List<Gradient> servGradients = [
  setGradientColo([Color(0xFF360568), Color(0xFF5B2A86)]),
  setGradientColo([Colors.black38, Colors.black87]),
  setGradientColo([Color(0xFF3E2A9B), Color(0xFF15036E)]),
  setGradientColo([Color(0xFF2676EB), Color(0xFF2676EB)]),
  setGradientColo([Color(0xFF7C2EF1), Color(0xFF4500AC)]),
  setGradientColo([Color(0xFF3AAA35), Color(0xFF0C7B08)]),
  setGradientColo([Color(0xFF4E51FD), Color(0xFF090C8D)]),
  setGradientColo([Color(0xFF2F87A2), Color(0xFF127491)]),
];

const Duration myDuration = Duration(milliseconds: 750);

const List<String> paymentTypes = ["CASH", "CREDIT"];
List<String> days = List.generate(31, (index) => '${(index + 1)}');
List<String> months = List.generate(12, (index) => '${(index + 1)}');
const List<String> years = ['2018', '2019', '2020', '2021', '2022'];


