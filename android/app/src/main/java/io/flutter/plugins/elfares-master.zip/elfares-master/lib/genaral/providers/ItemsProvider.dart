import 'package:elfares/genaral/models/BillItemModel.dart';
import 'package:flutter/material.dart';

import '.././models/ItemsModel.dart';

import '.././network/API/ItemsAPI.dart';

class ItemsProvider extends ChangeNotifier {
  ItemsAPI _api = ItemsAPI();
  List<Items> _items = [];
  List<Items> get items => _items;
  List<String> _itemsNames = [];
  List<String> get itemNames => _itemsNames;
  String? itemName;
  int? itemId;
  double? quantity;
  int? unitId;
  double? price;
  String? unitName;

  Future<void> getItems() async {
    _items = await _api.getItemsFromApi();
    print(_items.length);
    fillNames();
    notifyListeners();
  }

  fillNames() {
    _itemsNames = [];
    for (var item in _items) {
      _itemsNames.add(item.itemName!);
    }
  }

  changeItemName(String value) {
    itemName = value;
    int index = _items.indexWhere((element) => element.itemName == value);
    itemId = _items[index].itemId;
    unitId = _items[index].unitId;
    unitName = _items[index].unitName;
    price = _items[index].itemSalePrice;
    quantity = _items[index].availableQty;
    notifyListeners();
  }

  // -------------- Bill Item Model ------------- //
  List<BillItemModel> _sellingBillItems = [];
  List<BillItemModel> get sellingBillItems => _sellingBillItems;
  addToSellingBill(BillItemModel model) {
    _sellingBillItems.add(model);
    notifyListeners();
  }

  // -------------- Purchase Item Model ------------- //
  List<BillItemModel> _purchaseBillItems = [];
  List<BillItemModel> get purchaseBillItems => _purchaseBillItems;
  addTopurchasingBill(BillItemModel model) {
    _purchaseBillItems.add(model);
    notifyListeners();
  }
}
