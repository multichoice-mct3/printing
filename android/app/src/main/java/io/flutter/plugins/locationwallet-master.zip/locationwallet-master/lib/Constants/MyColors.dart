import 'dart:ui';

import 'package:flutter/material.dart';

class MyColors {
  static Color primary = Color(0xff0074bd);
  static Color secondary = Color(0xff154E3F);
  static Color bg = Color(0xfff5f5f5);
  static Color grey = Colors.grey;
  static Color greyWhite = Color(0xfff4f5f9);
  static Color blackOpacity = Color(0xff313135);
  static Color white = Color(0xfff5f5f5);

  static setColors({Color primaryColor, Color secondaryColor}) {
    primary = primaryColor;
    secondary = secondaryColor;
  }
}
