import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:octpedia/App/Utilities/my_route.dart';
import 'package:octpedia/Presentation/Authentication/Login/login_screen.dart';
import 'package:octpedia/Presentation/Resources/color_manager.dart';
import 'package:octpedia/Presentation/Resources/values_manager.dart';

class LoadingDialog {
  static showLoadingDialog() {
    EasyLoading.show(
        maskType: EasyLoadingMaskType.black,
        dismissOnTap: false,
        indicator: SpinKitCubeGrid(
          size: 40.0,
          itemBuilder: (context, index) {
            return Container(
              height: 10,
              width: 10,
              margin: const EdgeInsets.all(AppMargin.m8),
              decoration: BoxDecoration(
                  color: ColorManager.secondary, shape: BoxShape.circle),
            );
          },
        ),
        status: "loading");
  }

  static showLoadingView() {
    return SpinKitCubeGrid(
      color: ColorManager.secondary,
      size: 40.0,
    );
  }

  static showConfirmDialog(
      {required BuildContext context,
      required String title,
      required Function confirm}) {
    return showCupertinoDialog(
      context: context,
      builder: (BuildContext context) {
        return _alertDialog(title, confirm, context, "تأكيد");
      },
    );
  }

  static showAuthDialog({required BuildContext context}) {
    return showCupertinoDialog(
      context: context,
      builder: (BuildContext context) {
        return _alertDialog(
            "قم بتسجيل الدخول للمتابعة",
            () => MyRoute().navigateAndRemove(
                context: context, route: const LoginScreen()),
            context,
            "دخول");
      },
    );
  }

  static Widget _alertDialog(
      String title, Function confirm, BuildContext context, String okText) {
    return CupertinoAlertDialog(
      title: Text(title, style: Theme.of(context).textTheme.subtitle2),
      // content: MyText(title: title,size: 12,color: MyColors.blackOpacity,),
      actions: [
        CupertinoDialogAction(
          child: Text("رجوع", style: Theme.of(context).textTheme.subtitle2),
          onPressed: () => Navigator.pop(context),
        ),
        CupertinoDialogAction(
          child: Text(okText, style: Theme.of(context).textTheme.subtitle2),
          onPressed: () => confirm,
        ),
      ],
    );
  }

  static showToastNotification(msg,
      {Color? color, Color? textColor, Alignment? alignment}) {
    BotToast.showSimpleNotification(
        title: msg,
        align: alignment ?? Alignment.bottomCenter,
        backgroundColor: color ?? ColorManager.secondary,
        titleStyle: TextStyle(color: textColor ?? ColorManager.white),
        duration: DurationConstant.splashDuration,
        hideCloseButton: false,
        closeIcon: Icon(
          Icons.close,
          size: 25,
          color: ColorManager.white,
        ));
  }

  static showSimpleToast(msg) {
    BotToast.showText(text: msg);
  }
}
