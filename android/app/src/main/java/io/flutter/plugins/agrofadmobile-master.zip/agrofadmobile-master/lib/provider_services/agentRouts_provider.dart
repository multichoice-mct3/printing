import 'package:agrofad/api/GetPendingAgentVisitRoutes_api.dart';
import 'package:agrofad/api/get_CompletedEmpRouts_api.dart';
import 'package:agrofad/api/get_avrcauses_api.dart';
import 'package:agrofad/api/get_customers-api.dart';
import 'package:agrofad/models/avrCause_model.dart';
import 'package:agrofad/models/customer_model.dart';
import 'package:agrofad/models/route_model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;
import 'package:intl/intl.dart';

class AgentRoutsProvider extends ChangeNotifier {
  String selectedDate = intl.DateFormat('yyyy/MM/dd').format(DateTime.now());
  GetAvrCausesApi _avrCausesApi=GetAvrCausesApi();
  GetCustomersApi _customersApi = GetCustomersApi();
  List<AgentVisitRouteModel> _Emproutes = [];


  List<AvrCause> _AvrCauses=[];

  List<Customer> _Customers=[];

  List<Customer> get GetCustomers =>_Customers;

  getCustomers()async{
    _Customers=await _customersApi.GetCustomers();
    return _Customers;
  }

  String _SelectedCustomerName;
  int _SelectEdCustomerId;
  String _CauseNameSelected ;
  int _CauseNameId;
  String RouteNotes;

  String _RouteResult;

  String get GetSelectedCustomerName=>_SelectedCustomerName;
  String get GetCauseNameSelected=>_CauseNameSelected;
  int get GetSelectEdCustomerId=>_SelectEdCustomerId;
  int get GetCauseNameId=>_CauseNameId;
  String get GetSelectedDate => selectedDate;
  String get GetRouteNotes => RouteNotes;
  List<AgentVisitRouteModel> get GetRoutList => _Emproutes;
  List<AvrCause> get  GetAvrCausee=>_AvrCauses;
  String get GetRouteResult => _RouteResult;

  changeRouteResult( String Notes){
    _RouteResult =Notes;
    notifyListeners();
  }


  changeCauseName(String CauseName,int CauseId){
    _CauseNameSelected=CauseName;
    _CauseNameId=CauseId;
    notifyListeners();
  }
  changeCustomer(String CusName,int CustId){
    _SelectedCustomerName=CusName;
    _SelectEdCustomerId=CustId;
    notifyListeners();
  }

  GetAvrCauses()async{
    _AvrCauses =await  _avrCausesApi.GetAvrCauses();
    _CauseNameSelected=_AvrCauses[0].AVCName;
    _CauseNameId=_AvrCauses[0].AVCId;
     return _AvrCauses;
              }
  changeSelectedDate(DateTime NewDate) {
    selectedDate = intl.DateFormat('yyyy/MM/dd').format(NewDate);
    notifyListeners();
  }

  AddRoutToRoutList(AgentVisitRouteModel routeModel) {
    _Emproutes.add(routeModel);
    RouteNotes='';
    notifyListeners();
  }

  RemoveRoutToRoutList(int index) {    //remove from list when the agent delete route befouresave
    _Emproutes.removeAt(index);
    notifyListeners();
  }

  changeNotes(String Notes){
    RouteNotes=Notes;
    notifyListeners();
  }

  EmptyRoutList() {
    _Emproutes =[];
    notifyListeners();
  }


  /////////////////////////////////////////////// get emp routes by EmpUserId
  GetPendingAgentVisitRoutesApi _getPendingAgentVisitRoutesApi=GetPendingAgentVisitRoutesApi();

  List<AgentVisitRouteModel> _EmpRoutesByEmp=[];
  List<AgentVisitRouteModel> get GetEmpRoutesByEmp=>_EmpRoutesByEmp;

  getEmpRoutes(int EmpId)async{
    _EmpRoutesByEmp=await _getPendingAgentVisitRoutesApi.GetPendingAgentVisitRoutes(EmpId);
    return _EmpRoutesByEmp;
  }
  /////////////////////////////////////////////// get emp routes by EmpUserId
  GetCompletedAgentVisitRoutesApi  _completedAgentVisitRoutesApi=GetCompletedAgentVisitRoutesApi();
  List<AgentVisitRouteModel> _CompletedEmpRoutes=[];
  List<AgentVisitRouteModel> _TempCompletedEmpRoutes=[];
  List<AgentVisitRouteModel> get GetCompletedEmpRoutes=>_CompletedEmpRoutes;
  getCompletedEmpRoutes(int EmpIdUserId,int AgentId,String ToDate,String FromDate)async{
    _CompletedEmpRoutes=[];
    DateTime Fdate = DateFormat('yyyy/MM/dd').parse(FromDate);
    DateTime Tdate = DateFormat('yyyy/MM/dd').parse(ToDate);
    _TempCompletedEmpRoutes=await _completedAgentVisitRoutesApi.GetCompletedAgentVisitRoutes(EmpIdUserId,AgentId,ToDate,FromDate);


    for(AgentVisitRouteModel avrm in _TempCompletedEmpRoutes){


      DateTime AvrDate = DateTime.parse(avrm.AVRDate);
         //
         // if (AvrDate.isBefore(Tdate)&&AvrDate.isAfter(Fdate)&&avrm.EmpId==AgentId){
         //   _CompletedEmpRoutes.add(avrm);
         //                                                                           }
         if (avrm.EmpId==AgentId){
           if (AvrDate.isBefore(Tdate)&&AvrDate.isAfter(Fdate)||AvrDate.isAtSameMomentAs(Tdate) || AvrDate.isAtSameMomentAs(Fdate)){
             _CompletedEmpRoutes.add(avrm);
           }
         }
             }
    return _CompletedEmpRoutes;
  }
///////////////////////////////////////////////////////////////////// remove from emproutes after action

removeFromEmpRoutes(int index){
  _EmpRoutesByEmp.removeAt(index);
  notifyListeners();
}
}
