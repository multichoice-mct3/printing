import 'package:json_annotation/json_annotation.dart';
part 'CustomerModel.g.dart';

@JsonSerializable(includeIfNull: true)
class CustomerModel {
  @JsonKey(name: "CustomerID")
  final int? customerId;
  @JsonKey(name: "CustomerName")
  final String? customerName;
  @JsonKey(name: "AccountID")
  final String? accountId;

  CustomerModel({
    this.customerId,
    this.customerName,
    this.accountId,
  });

  factory CustomerModel.fromJson(Map<String, dynamic> json) =>
      _$CustomerModelFromJson(json);
  Map<String, dynamic> toJson() => _$CustomerModelToJson(this);
}
