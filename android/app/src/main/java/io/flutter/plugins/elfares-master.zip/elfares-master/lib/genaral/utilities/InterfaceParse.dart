abstract class Parse {
  void send(String text);
  void recieve();
}
