import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:octpedia/Presentation/Resources/theme_manager.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:octpedia/Presentation/splash/splash.dart';

class MyApp extends StatefulWidget {
  const MyApp._internal();
  static const MyApp instance = MyApp._internal();
  factory MyApp() => instance;

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final botToastBuilder = BotToastInit();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Octopedia',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      theme: getApplicationTheme(),
      home: const Splash(),
      builder: (context, child) {
        child = FlutterEasyLoading(child: child);
        child = botToastBuilder(context, child);
        return child;
      },
    );
  }
}
