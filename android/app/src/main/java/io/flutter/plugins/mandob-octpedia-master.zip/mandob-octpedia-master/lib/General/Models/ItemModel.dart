class ItemModel {
  String? itemName;
  int? providesId;
  String? providesName;

  ItemModel({this.itemName, this.providesId, this.providesName});

  ItemModel.fromJson(Map<String, dynamic> json) {
    itemName = json['itemName'];
    providesId = json['providesId'];
    providesName = json['providesName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['itemName'] = this.itemName;
    data['providesId'] = this.providesId;
    data['providesName'] = this.providesName;
    return data;
  }
}
