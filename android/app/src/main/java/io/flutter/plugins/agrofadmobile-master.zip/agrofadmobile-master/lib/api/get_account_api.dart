import 'dart:convert';
import 'package:agrofad/models/account_model.dart';
import 'package:http/http.dart' as http;

import 'get_request_orders_api.dart';
import 'login_apis.dart';

class GetAllAccountsApi{
  int UserId;
  LoginApi loginApi = new LoginApi();
  GetRequstsApi _getRequstsApi=GetRequstsApi();
  List <Account>Accounts=[];
  String BaseUrl = 'http://104.196.134.107/AfitAPI';
  Future<List <Account>> GetAllAccounts(String AccType) async {
    await loginApi.getAccessToken();
    await _getRequstsApi.getUserDateail();
    UserId=_getRequstsApi.UserId;
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var response;
    if (AccType=='AllAccs'){
      response = await http.get("http://104.196.134.107/AfitAPI/api/Accounts"+"?User_ID="+UserId.toString(),
          headers: Headers);
    }
    if (AccType=='BankAccs'){
      response = await http.get("http://104.196.134.107/AfitAPI/api/Accounts"+"?User_ID="+UserId.toString(),
          headers: Headers);
    }
    if (AccType=='TreasuryAccs'){
      response = await http.get("http://104.196.134.107/AfitAPI/api/Accounts",
          headers: Headers);
    }
    if (response.statusCode == 200) {
      Accounts= ParseItems(response.body);
    } else {
      print(response.body);
    }
    return Accounts;
  }
  //fn get the item list
  List<Account> ParseItems(String responseBody) {
    final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();
    return parsedItems.map<Account>((json) => Account.fromJson(json)).toList();
  }
}