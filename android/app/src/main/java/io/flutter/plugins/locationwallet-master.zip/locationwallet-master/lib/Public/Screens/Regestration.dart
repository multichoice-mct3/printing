import 'package:LocarionWallet/Constants/IconTextFiled.dart';
import 'package:LocarionWallet/Constants/LabelTextField.dart';
import 'package:LocarionWallet/Constants/MyColors.dart';
import 'package:LocarionWallet/Constants/MyText.dart';
import 'package:LocarionWallet/Public/Provider/UserProvider.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:LocarionWallet/Public/Utilits/Validator.dart';
import 'package:LocarionWallet/Public/resources/GeneralHttpMethods.dart';
import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';

class Registeration extends StatefulWidget {
  @override
  _RegisterationState createState() => _RegisterationState();
}

class _RegisterationState extends State<Registeration> {
  // GlobalKey<ScaffoldState> _scaffold = new GlobalKey<ScaffoldState>();

  GlobalKey<FormState> _formKey = new GlobalKey<FormState>();

  TextEditingController _fName = new TextEditingController();

  TextEditingController _lName = new TextEditingController();

  TextEditingController _phone = new TextEditingController();

  TextEditingController _email = new TextEditingController();

  TextEditingController _pass = new TextEditingController();

  TextEditingController _conPass = new TextEditingController();

  RoundedLoadingButtonController _btnController =
      RoundedLoadingButtonController();

  void _doSomething(BuildContext context) async {
    if (_formKey.currentState.validate()) {
      await GeneralHttpMethods().register(_phone.text, _pass.text, _email.text);
    }
  }

  @override
  void dispose() {
    _fName.dispose();
    _lName.dispose();
    _phone.dispose();
    _email.dispose();
    _pass.dispose();
    _conPass.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffold,
      backgroundColor: MyColors.primary,
      body: SingleChildScrollView(
        padding: EdgeInsets.all(0),
        child: Container(
          color: MyColors.primary,
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Stack(
            alignment: Alignment.topCenter,
            children: <Widget>[
              Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * .5,
                alignment: Alignment.center,
              ),
              Positioned(
                top: 60,
                child: Column(
                  children: [
                    Image.asset(
                      "assets/images/wallet-location.png",
                      fit: BoxFit.contain,
                      width: 200,
                      height: 120,
                      color: MyColors.white,
                    ),
                    MyText(
                      title: "Location Wallet",
                      size: 26,
                      color: MyColors.white,
                    )
                  ],
                ),
              ),
              Positioned(
                top: MediaQuery.of(context).size.height * .3,
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 25),
                  decoration: BoxDecoration(
                    color: MyColors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(4.0),
                          child: MyText(
                            title: tr("register"),
                            size: 24,
                            color: MyColors.blackOpacity,
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: LabelTextField(
                                margin: EdgeInsets.symmetric(
                                    horizontal: 5, vertical: 5),
                                type: TextInputType.text,
                                label: tr("fName"),
                                isPassword: false,
                                controller: _fName,
                                validate: (value) =>
                                    Validator().validateEmpty(value: value),
                              ),
                            ),
                            Expanded(
                              child: LabelTextField(
                                margin: EdgeInsets.symmetric(
                                    horizontal: 5, vertical: 5),
                                type: TextInputType.text,
                                label: tr("lName"),
                                isPassword: false,
                                controller: _lName,
                                validate: (value) => print(value),
                              ),
                            ),
                          ],
                        ),

                        IconTextFiled(
                          margin:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          type: TextInputType.phone,
                          label: tr("phone"),
                          isPassword: false,
                          controller: _phone,
                          icon: Icon(Icons.phone_iphone),
                          validate: (value) =>
                              Validator().validatePhone(value: value),
                        ),
                        IconTextFiled(
                          margin:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          type: TextInputType.emailAddress,
                          label: "${tr("email")} ex: user@example.com",
                          isPassword: false,
                          controller: _email,
                          icon: Icon(Icons.email_outlined),
                          validate: (value) =>
                              Validator().validateEmail(value: value),
                        ),
                        IconTextFiled(
                          margin:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          type: TextInputType.text,
                          label: '${tr("password")} ${tr("ex")} Example^123',
                          isPassword: Provider.of<UserProvider>(context)
                              .passwordVisibility,
                          controller: _pass,
                          icon: InkWell(
                            onTap: () => Provider.of<UserProvider>(context,
                                    listen: false)
                                .changePasswordVisibility(),
                            child: Provider.of<UserProvider>(context)
                                    .passwordVisibility
                                ? Icon(Icons.visibility)
                                : Icon(Icons.visibility_off),
                          ),
                          validate: (value) =>
                              Validator().validatePassword(value: value),
                        ),
                        IconTextFiled(
                          margin:
                              EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                          type: TextInputType.text,
                          label: "${tr("confirm")} ${tr("password")}",
                          isPassword: Provider.of<UserProvider>(context)
                              .confirmPasswordVisibility,
                          controller: _conPass,
                          icon: InkWell(
                            onTap: () => Provider.of<UserProvider>(context,
                                    listen: false)
                                .changeConfirmPasswordVisibility(),
                            child: Provider.of<UserProvider>(context)
                                    .confirmPasswordVisibility
                                ? Icon(Icons.visibility)
                                : Icon(Icons.visibility_off),
                          ),
                          validate: (value) => Validator()
                              .validatePasswordConfirm(
                                  confirm: value, pass: _pass.text),
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).size.height * .05,
                        ),
                        // Visibility(
                        // child:
                        RoundedLoadingButton(
                          width: MediaQuery.of(context).size.width * .85,
                          child: MyText(
                            title: tr("register"),
                            size: 14,
                            color: Colors.white,
                          ),
                          color: MyColors.primary,
                          borderRadius: 5,
                          height: 45,
                          controller: _btnController,
                          onPressed: () => _doSomething(context),
                        ),
                        // InkWell(
                        //   onTap: () {
                        //     if (_formKey.currentState.validate()) {}

                        //     GeneralHttpMethods()
                        //         .register(_phone.text, _pass.text, _email.text)
                        //         .then((value) {
                        //       print("value $value");
                        //     });
                        //   },
                        //   child: Container(
                        //     width: MediaQuery.of(context).size.width,
                        //     height: 45,
                        //     margin: EdgeInsets.symmetric(
                        //         horizontal: 10, vertical: 10),
                        //     decoration: BoxDecoration(
                        //       color: MyColors.primary,
                        //       borderRadius: BorderRadius.circular(5),
                        //     ),
                        //     alignment: Alignment.center,
                        //     child: MyText(
                        //       title: tr("register"),
                        //       size: 14,
                        //       color: Colors.white,
                        //     ),
                        //   ),
                        // ),
                        // visible: !_visible,
                        //   replacement:
                        //       Center(child: CircularProgressIndicator()),
                        // ),
                        SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            MyText(
                              title: "${tr("alreadyHaveAcc")}",
                            ),
                            SizedBox(width: 5),
                            InkWell(
                              onTap: () => ExtendedNavigator.root
                                  .pushAndRemoveUntil(
                                      Routes.userLogin, (route) => false),
                              child: MyText(
                                title: tr("login"),
                                color: MyColors.primary,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
