part of "WidgetsImport.dart";

class IndexAndDate extends StatelessWidget {
  const IndexAndDate({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            MyText(title: "م", color: MyColors.white),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: MyText(
                title: "Auto",
                size: 12,
                color: MyColors.dark,
              ),
            )
          ],
        ),
        Row(
          children: [
            MyText(title: "التاريخ", color: MyColors.white),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(10)),
              child: MyText(
                title: Utils.simplifyDate(DateTime.now()),
                size: 12,
              ),
            )
          ],
        )
      ],
    );
  }
}
