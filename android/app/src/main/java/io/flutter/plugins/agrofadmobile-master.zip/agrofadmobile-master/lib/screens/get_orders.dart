import 'package:agrofad/api/get_request_orders_api.dart';
import 'package:agrofad/models/AddOrderedSupply_model.dart';
import 'package:agrofad/screens/order_detail.dart';
import 'package:awesome_loader/awesome_loader.dart';
import 'package:flutter/material.dart';
import '../AgrofadMainScreen.dart';
import '../constants.dart';

class Orders extends StatefulWidget {
  static String id='Orders';
  @override
  _OrdersState createState() => _OrdersState();
}
class _OrdersState extends State<Orders> {
  bool done=false;
  List<OrderedSupplyModel> RequstedOrders;

  GetRequstsApi _getRequstsApi=GetRequstsApi();
  Future<List<OrderedSupplyModel>> GetRequsts() async {
    //getallitems api
    List<OrderedSupplyModel>Orders = await _getRequstsApi.GetUserRequsts();
    return Orders;
  }
@override
  void initState() {
    // TODO: implement initState
    super.initState();
    ()async{
      RequstedOrders=await GetRequsts();

      setState(() {
        done=true;
      });
    }();
  }

  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    double ScreenHieght = MediaQuery.of(context).size.height;
    return SafeArea(
      child: Scaffold(
        backgroundColor: !done?Colors.white: KmainColor,
        body:  !done
            ? Center(
          child: Container(
            height: 30,
            width: 30,
            child: AwesomeLoader(
              loaderType: AwesomeLoader.AwesomeLoader3,
              color: KmainColor,

            ),
          ),
        )
        :Column(
          children: [
            FirstContainer(ScreenWidth),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: ListView.builder(
                    itemCount: RequstedOrders.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GetSupplyOrders(index);
                    }),
              ),
            )
          ],
        ),
      ),
    );
  }
  Widget FirstContainer(double ScreenWidth) {
    return Column(
      children: [
        Container(
          width: ScreenWidth,
          height: 40,
          color: OfWhiteColor,
          child: Padding(
            padding: const EdgeInsets.only(right: 25),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  ' اوامر التوريد ',
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: KmainColor,
                    fontSize: 25,
                    fontFamily: 'cocon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 15, top: 3),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)),
                    color: Colors.amber,
                    onPressed: () async {
                       //   Navigator.(context);
                      Navigator.pushNamed(context, AgrofadMainScreen.id);
                    },
                    child: Text(
                      'رجوع',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'cocon',
                          fontSize: 18),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
        SizedBox(height: 10,)
      ],
    );
  }
  Widget GetSupplyOrders(int index) {
    // print(index.toString());
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child:InkWell(
        onTap: (){
          Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => OrderSupplyDet(OrderId: RequstedOrders[index].RequestOrderID),
          ),
        );
          // Navigator.pushNamed(context, OrderSupplyDet.id);
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: Colors.white,
          ),
          child: Column(
            children: [
              //first
              Container(
                // height: 20,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        textDirection: TextDirection.rtl,
                        children: [
                          Expanded(
                            flex: 1,
                            child: Row(
                              textDirection: TextDirection.rtl,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  ':المندوب',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      fontFamily: 'cocon',
                                      color: KmainColor),
                                ),
                                SizedBox(
                                  width: 15,
                                ),
                                Text(
                                  RequstedOrders[index].EmpName,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                      fontFamily: 'cocon',
                                      color: KmainColor),
                                ),
                              ],
                            ),
                          ),

                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 5,),
              Container(
               // height: 20,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        textDirection: TextDirection.rtl,
                        children: [
                          Expanded(
                            flex: 1,
                            child: Row(
                              textDirection: TextDirection.rtl,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  ':العميل',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      fontFamily: 'cocon',
                                      color: KmainColor),
                                ),
                                SizedBox(
                                  width: 15,
                                ),
                                Text(
                                  RequstedOrders[index].CustomerName,
                                  textAlign: TextAlign.end,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                      fontFamily: 'cocon',
                                      color: KmainColor),
                                ),
                              ],
                            ),
                          ),

                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 5,),
              Container(
               // height: 20,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Expanded(
                          flex: 1,
                          child: Row(
                            textDirection: TextDirection.rtl,
                            children: [
                              Container(
                                  child: Text(
                                    ':التاريخ',
                                    textAlign: TextAlign.end,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        fontFamily: 'cocon',
                                        color: KmainColor),
                                  )),
                              SizedBox(
                                width: 15,
                              ),
                              Container(
                                  child: Text(
                                    RequstedOrders[index].RequestOrderDate,
                                    textAlign: TextAlign.end,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15,
                                        fontFamily: 'cocon',
                                        color: BlackColor),
                                  )),
                            ],
                          )),
                      Expanded(
                        flex: 1,
                        child: Row(
                          textDirection: TextDirection.rtl,
                          children: [
                            Text(
                              ':رقم اذن التوريد',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  fontFamily: 'cocon',
                                  color: KmainColor),
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            Text(
                              RequstedOrders[index].RequestOrderID.toString(),
                              textAlign: TextAlign.end,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                  fontFamily: 'cocon',
                                  color: BlackColor),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),


            ],
          ),
        ),
      )
    );
  }
}
