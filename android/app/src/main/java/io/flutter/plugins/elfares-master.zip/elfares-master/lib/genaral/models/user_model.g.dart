// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserModel _$UserModelFromJson(Map<String, dynamic> json) {
  return UserModel(
    userId: json['UserId'] as int?,
    userName: json['UserName'] as String?,
    empId: json['EmpID'] as int?,
    userType: json['UserType'] as String?,
    enterpriseId: json['EnterpriseId'] as int?,
  );
}

Map<String, dynamic> _$UserModelToJson(UserModel instance) => <String, dynamic>{
      'UserId': instance.userId,
      'UserName': instance.userName,
      'EmpID': instance.empId,
      'UserType': instance.userType,
      'EnterpriseId': instance.enterpriseId,
    };
