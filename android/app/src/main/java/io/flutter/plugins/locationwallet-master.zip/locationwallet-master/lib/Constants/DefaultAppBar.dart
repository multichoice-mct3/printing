import 'package:flutter/material.dart';

import 'MyColors.dart';
import 'MyText.dart';

// ignore: must_be_immutable
class DefaultAppBar extends PreferredSize {
  String title;
  BuildContext con;
  double elevation;
  List<Widget> actions = [];
  final Size preferredSize = const Size.fromHeight(kToolbarHeight + 5);
  bool back = false;

  DefaultAppBar(
      {@required this.title, @required this.con, this.actions, this.back});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: MyText(
        title: "$title",
        size: 16,
        color: MyColors.white,
      ),
      centerTitle: true,
      elevation: elevation,
      automaticallyImplyLeading: false,
      backgroundColor: MyColors.primary,
      leading: back ?? false
          ? IconButton(
              icon: Icon(
                Icons.arrow_back_ios,
                color: MyColors.white,
              ),
              onPressed: () => Navigator.of(con).pop(),
            )
          : null,
      actions: actions,
    );
  }
}
