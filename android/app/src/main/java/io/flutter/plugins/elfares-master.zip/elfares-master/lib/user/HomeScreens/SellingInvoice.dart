part of "HomeImports.dart";

// ignore: must_be_immutable
class SellingInvoice extends StatefulWidget {
  @override
  State<SellingInvoice> createState() => _SellingInvoiceState();
}

class _SellingInvoiceState extends State<SellingInvoice> {
  String? unit;

  TextEditingController discount = TextEditingController();
  TextEditingController qty = TextEditingController();
  TextEditingController price = TextEditingController();
  double total = 0;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      child: Consumer<SellingInvsProvider>(
        builder: (context, sellingInvs, child) {
          discount.text = '${sellingInvs.discount ?? ''}';
          return ItemsMainScreen(
              title: "فاتورة البيع",
              fabExist: true,
              onTap: () => saveSelling(context),
              showTotal: true,
              total: total,
              afterDiscount: sellingInvs.discount ?? 0,
              content: Column(
                children: [
                  IndexAndDate(),
                  SizedBox(height: 10),
                  PaymentAndDisCount(
                    paymentMethod: sellingInvs.paymentType,
                    discountController: discount,
                    change: (value) => context
                        .read<SellingInvsProvider>()
                        .changePaymentMethod(value),
                  ),
                  CustomersDropdown(),
                  const SizedBox(height: 10),
                  Consumer<ItemsProvider>(
                    builder: (context, itemsProvider, child) {
                      qty.text = itemsProvider.quantity.toString();
                      price.text = itemsProvider.price.toString();
                      return Container(
                        padding: EdgeInsets.all(10),
                        margin: EdgeInsets.symmetric(vertical: 5),
                        decoration: BoxDecoration(
                            color: MyColors.white,
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          children: [
                            ItemsDropdown(),
                            const SizedBox(height: 10),
                            UnitAndQtyAndPrice(
                              unit: itemsProvider.unitName,
                              showPrice: true,
                              qty: qty,
                              price: price,
                            ),
                            MyElevatedButton(
                              onPressed: addToBillModel(context),
                              title: 'إضافة',
                              size: Size(SizeConfig.screenWidth!, 50),
                            ),
                            const SizedBox(height: 10),
                          ],
                        ),
                      );
                    },
                  ),
                  Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 2),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                  topRight: Radius.circular(10))),
                          child: MyText(
                            title: "م",
                            size: 12,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 4,
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 2),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(color: Colors.white),
                          child: MyText(
                            title: "الوصف",
                            size: 12,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 2),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10))),
                          child: MyText(
                            title: "الأجمالي",
                            size: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Expanded(
                    child: Consumer<ItemsProvider>(
                      builder: (context, sellingItems, child) {
                        return ListView.builder(
                          itemCount: sellingItems.sellingBillItems.length,
                          itemBuilder: (BuildContext context, int index) {
                            return ListItem(
                              desc: sellingItems
                                  .sellingBillItems[index].itemName!,
                              index: (index + 1).toString(),
                              total: sellingItems.sellingBillItems[index].tot
                                  .toString(),
                            );
                          },
                        );
                      },
                    ),
                  )
                ],
              ));
        },
      ),
      onWillPop: () => close(),
    );
  }

  addToBillModel(BuildContext context) {
    BillItemModel model = BillItemModel(
      itemId: context.read<ItemsProvider>().itemId,
      itemName: context.read<ItemsProvider>().itemName,
      price: double.parse(price.text),
      qty: double.parse(qty.text),
      unitName: context.read<ItemsProvider>().unitName,
      unitId: context.read<ItemsProvider>().unitId,
      tot: double.parse(qty.text) * double.parse(price.text),
    );
    context.read<ItemsProvider>().addToSellingBill(model);
    total = total + model.tot!;
    print(total);
    setState(() {});
    // print(context.read<SellingInvsProvider>().total);
    print(model.toJson());
  }

  saveSelling(BuildContext context) {
    print(unit);
    SellingBill model = SellingBill(
      customerId: context.read<CustomersProvider>().customerId,
      customerName: context.read<CustomersProvider>().customerName,
      type: context.read<SellingInvsProvider>().paymentType,
      date: DateFormat('dd-MM-yyyy').format(DateTime.now()),
      items: context.read<ItemsProvider>().sellingBillItems,
      discount: double.parse(discount.text),
      entryUserDate: DateFormat('dd-MM-yyyy').format(DateTime.now()),
      entryUserId: CachHelper.getData(key: 'userId'),
      sellingValue: context.read<SellingInvsProvider>().discount,
      total: context.read<SellingInvsProvider>().total,
    );
    // context.read<ItemsProvider>().addToSellingBill();

    print(model.toJson());
  }

  Future<bool> close() async {
    var myProvider = Provider.of<ItemsProvider>(context, listen: false);
    myProvider.itemName = null;
    myProvider.quantity = null;
    myProvider.itemId = null;
    myProvider.quantity = null;
    myProvider.price = null;
    myProvider.unitId = null;
    myProvider.unitName = null;
    qty.clear();
    price.clear();
    return true;
  }
}
