part of "HomeImports.dart";

class PurchasingBills extends StatelessWidget {
  const PurchasingBills({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String? value;
    String? value1;
    return ItemsMainScreen(
      title: "فواتير الشراء",
      content: Column(
        children: [
          SuppliersDropdown(),
          const SizedBox(height: 10),
          DatePickerRow(value: value, value1: value1),
          const SizedBox(height: 10),
          MyElevatedButton(onPressed: () => print("tapped"), title: "عرض"),
        ],
      ),
    );
  }
}
