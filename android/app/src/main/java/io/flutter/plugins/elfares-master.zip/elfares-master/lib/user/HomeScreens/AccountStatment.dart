part of "HomeImports.dart";

class AccountStatment extends StatelessWidget {
  const AccountStatment({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String? value;
    String? value1;
    String? value2;
    return ItemsMainScreen(
      title: "كشف حساب",
      content: Column(
        children: [
          const SizedBox(height: 10),
          CustomDropDown(
            hint: "اختر الحساب",
            items: [],
            value: value,
            onChange: (value) => print("object"),
          ),
          const SizedBox(height: 10),
          DatePickerRow(value: value1, value1: value2),
          const SizedBox(height: 10),
          MyElevatedButton(onPressed: () => print("object"), title: 'عرض')
        ],
      ),
    );
  }
}
