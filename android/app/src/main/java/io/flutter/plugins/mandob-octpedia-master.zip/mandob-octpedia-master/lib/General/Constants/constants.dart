import 'package:flutter/material.dart';

const List<BoxShadow> kBoxShadow = [
  BoxShadow(
    color: Colors.black12,
    blurRadius: 8,
    spreadRadius: 6,
    offset: Offset(0, 2),
  )
];
const List<BoxShadow> kBoxShadow2 = [
  BoxShadow(
    color: Colors.black12,
    blurRadius: 10,
    spreadRadius: 1,
    offset: Offset(2, 6),
  ),
];

const List<String> servicesNames = [
  "الخدمات الصناعية",
  "الخدمات اللوجيستية",
  "الخدمات التعليمية",
  "الخدمات الطبية",
  "الخدمات الترفيهية",
  "الإستثمار العقاري",
  "الخدمية",
  "عن المدينة",
];

Gradient setGradientColo(List<Color> colors) {
  return LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: colors);
}

List<Gradient> servGradients = [
  setGradientColo([Color(0xFFEFAB2F), Color(0xFFD28801)]),
  setGradientColo([Color(0xFFD61914), Color(0xFFA50A05)]),
  setGradientColo([Color(0xFF3E2A9B), Color(0xFF15036E)]),
  setGradientColo([Color(0xFF2676EB), Color(0xFF2676EB)]),
  setGradientColo([Color(0xFF7C2EF1), Color(0xFF4500AC)]),
  setGradientColo([Color(0xFF3AAA35), Color(0xFF0C7B08)]),
  setGradientColo([Color(0xFF4E51FD), Color(0xFF090C8D)]),
  setGradientColo([Color(0xFF2F87A2), Color(0xFF127491)]),
];
