import 'package:elfares/genaral/models/AccountModel.dart';
import 'package:elfares/genaral/network/Http.dart';
import 'package:elfares/genaral/utilities/GlobalState.dart';

class AccountsApi {
  HttpMethods _http = HttpMethods();
  Future<List<AccountModel>> getAccountsFromApi(String url) async {
    List<AccountModel> _accounts = [];

    var _data =
        await _http.getData(url: "http://104.196.134.107/AfitAPI/api/$url");
    if (_data != null) {
      List<Map<String, dynamic>> _accountsJson =
          List<Map<String, dynamic>>.from(_data);
      _accounts = _accountsJson
          .map((account) => AccountModel.fromJson(account))
          .toList();
      return _accounts;
    }

    return _accounts;
  }

  Future<List<AccountModel>> getAllAccounts() async {
    List<AccountModel> _accounts = [];
    _accounts = await getAccountsFromApi('Accounts');
    return _accounts;
  }

  Future<List<AccountModel>> getAccountsByUser() async {
    List<AccountModel> _accounts = [];
    int _userId = GlobalState.instance.get('userId');
    _accounts = await getAccountsFromApi('Accounts?User_ID=$_userId');
    return _accounts;
  }
}
