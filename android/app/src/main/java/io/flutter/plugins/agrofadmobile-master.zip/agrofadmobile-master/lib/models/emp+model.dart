class Emp{
  int EmpId;
  String EmpName;
  Emp({this.EmpId, this.EmpName});


  factory Emp.FromJson(Map<String ,dynamic> agents){
  return Emp(
      EmpName: agents['EmpName'],
      EmpId: agents['EmpID']
  );
  }

}