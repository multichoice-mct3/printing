package com.octpedia.octpedia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
