import 'dart:convert';
import 'package:agrofad/models/AddOrderedSupply_model.dart';
import 'package:agrofad/models/route_model.dart';
import 'package:http/http.dart' as http;

import 'login_apis.dart';



class PostEmpDailyRoutsApi {
  LoginApi loginApi = new LoginApi();
  bool Posted;
  Future<bool> PostEmpDailyRouts(List<AgentVisitRouteModel > dailyRoutesList) async {
    List<Map>Routs=[];
    for(AgentVisitRouteModel  route in dailyRoutesList ){
      Routs.add(route.ToJson());
    }


     String RequestOrderJsonData = jsonEncode(Routs);
    print(RequestOrderJsonData);

     await loginApi.getAccessToken();

     Map Headers = <String, String>{
       'Content-Type': 'application/json',
       'Authorization': 'Bearer  ${loginApi.token}',
    };
    var Response = await http.post(
        'http://104.196.134.107/AfitAPI/api/AgentVisitRoutes',
        body: RequestOrderJsonData,
        headers: Headers);
    if (Response.statusCode == 201  || Response.statusCode == 200) {
     // var PostResult = jsonDecode(Response.body);
      Posted = true;
      print(Posted.toString());
      //print(PostResult);
    } else {
      //var PostResult = jsonDecode(Response.body);
      Posted = false;
     // print(PostResult);
      print(Posted.toString());
    }

    return Posted;
  }
}
