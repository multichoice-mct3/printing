import 'package:LocarionWallet/Constants/MyColors.dart';
import 'package:LocarionWallet/Constants/MyText.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';


class OnBoardingScreen extends StatefulWidget {
  @override
  _OnBoardingScreenState createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  int currentPage = 0;

  List<OnBoardingModel> boarding = [
    OnBoardingModel(
      image: 'assets/images/map1.png',
      title: 'On Boarding 1 title',
      body: 'On Board 1 Body',
    ),
    OnBoardingModel(
      image: 'assets/images/map2.png',
      title: 'On Boarding 2 title',
      body: 'On Board 2 Body',
    ),
    OnBoardingModel(
      image: 'assets/images/map3.png',
      title: 'On Boarding 3 title',
      body: 'On Board 3 Body',
    ),
  ];
  bool isLast = false;

  var boardingController = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            SizedBox(height: 10),
            InkWell(
                onTap: () => ExtendedNavigator.root.push(Routes.userLogin),
                child: MyText(
                  title: tr("skip"),
                  color: MyColors.primary,
                )),
            Expanded(
              child: PageView.builder(
                onPageChanged: (value) {
                  if (value == boarding.length - 1) {
                    setState(() {
                      isLast = true;
                      currentPage = value;
                    });
                    print("last");
                  } else {
                    print(" not last");
                    setState(() {
                      isLast = false;
                      currentPage = value;
                    });
                  }
                },
                controller: boardingController,
                physics: BouncingScrollPhysics(),
                itemBuilder: (context, index) =>
                    buildBoardingItem(boarding[index]),
                itemCount: boarding.length,
              ),
            ),
            SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    boarding.length,
                    (index) => buildDot(index: index),
                  ),
                ),
                FloatingActionButton(
                  onPressed: () {
                    boardingController.nextPage(
                        duration: Duration(milliseconds: 750),
                        curve: Curves.fastLinearToSlowEaseIn);
                    if (isLast) ExtendedNavigator.root.push(Routes.userLogin);
                  },
                  child: Icon(Icons.arrow_forward_ios),
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  AnimatedContainer buildDot({@required int index}) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 750),
      margin: EdgeInsets.only(right: 5),
      height: 10,
      width: currentPage == index ? 25 : 10,
      decoration: BoxDecoration(
        color: currentPage == index ? MyColors.primary : Colors.grey,
        borderRadius: BorderRadius.circular(10),
      ),
    );
  }

  Widget buildBoardingItem(OnBoardingModel boarding) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Image.asset(
              boarding.image,
            ),
          ),
          SizedBox(height: 30),
          MyText(
            title: boarding.title,
            size: 20,
          ),
          SizedBox(height: 20),
          MyText(title: boarding.body),
          SizedBox(height: 30),
        ],
      );
}

class OnBoardingModel {
  final String image, title, body;

  OnBoardingModel({
    @required this.image,
    @required this.title,
    @required this.body,
  });
}
