import 'package:json_annotation/json_annotation.dart';
part 'StoresModel.g.dart';

@JsonSerializable()
class Stores {
  @JsonKey(name: "StoreId")
  int? storeId;
  @JsonKey(name: "StoreName")
  String? storeName;

  Stores({
    this.storeId,
    this.storeName,
  });

  factory Stores.fromJson(Map<String, dynamic> json) => _$StoresFromJson(json);
  Map<String, dynamic> toJson() => _$StoresToJson(this);
}
