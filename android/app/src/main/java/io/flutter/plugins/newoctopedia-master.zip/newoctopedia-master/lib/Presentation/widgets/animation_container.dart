import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:octpedia/Presentation/Resources/values_manager.dart';

class AnimationContainer extends StatelessWidget {
  final Widget? child;
  final int? index;
  final bool vertical;
  final bool scale;
  final double distance;
  final Duration? duration;

  // ignore: use_key_in_widget_constructors
  const AnimationContainer(
      {this.child,
      this.index,
      this.vertical = true,
      this.distance = 100,
      this.scale = false,
      this.duration});

  @override
  Widget build(BuildContext context) {
    return AnimationConfiguration.staggeredList(
      position: index!,
      duration: duration ?? DurationConstant.containerDuration,
      child: Visibility(
        child: ScaleAnimation(
          child: FadeInAnimation(
            child: child!,
          ),
        ),
        visible: scale,
        replacement: Visibility(
          child: SlideAnimation(
            verticalOffset: distance,
            child: FadeInAnimation(child: child!),
          ),
          visible: vertical,
          replacement: SlideAnimation(
            horizontalOffset: distance,
            child: FadeInAnimation(
              child: child!,
            ),
          ),
        ),
      ),
    );
  }
}
