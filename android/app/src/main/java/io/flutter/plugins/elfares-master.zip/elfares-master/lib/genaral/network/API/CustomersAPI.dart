import '../Http.dart';
import '../../models/CustomerModel.dart';

class CustomersAPI {
  HttpMethods _http = HttpMethods();
  Future<List<CustomerModel>> getCustomersFromApi() async {
    List<CustomerModel> customer = [];

    var _data = await _http.getData(url: "Customer");

    if (_data != null) {
      List<Map<String, dynamic>> _customersJson =
          List<Map<String, dynamic>>.from(_data);
      customer = _customersJson
          .map((customer) => CustomerModel.fromJson(customer))
          .toList();
      return customer;
    }

    return customer;
  }
}
