import 'package:flutter/material.dart';

import '../constants.dart';

class CustomDialoge extends StatelessWidget {
  String Message;
  Function Callback;
  BuildContext Anothercontext;
  CustomDialoge({@required this.Message,@required this.Anothercontext ,@required this.Callback});
  @override
  Widget build(Anothercontext) {
    return Dialog(
      shape: RoundedRectangleBorder(
          borderRadius:
          BorderRadius.circular(20.0)), //this right here
      child: SizedBox(

        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.end,
            // crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                textDirection: TextDirection.rtl,
                children: [
                  Text(
                  Message,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight:  FontWeight.bold,
                      fontFamily: 'cocon',
                      color: KmainColor,

                    ),
                  ),
                ],
              ),
              Row(
                textDirection: TextDirection.ltr,
                children: [
                  SizedBox(
                    width: 100.0,
                    child: RaisedButton(

                        onPressed: Callback,
                        child: Text(
                          "اغلاق",
                          style: TextStyle(
                              color: Colors.white,
                            fontFamily: 'cocon'

                          ),

                        ),
                        color: KmainColor
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
