part of "HomeImports.dart";

// ignore: must_be_immutable
class PurchasingInvoice extends StatelessWidget {
  String? paymentMethod, unit;
  TextEditingController qty = TextEditingController();
  TextEditingController price = TextEditingController();
  TextEditingController discount = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Consumer<SellingInvsProvider>(
      builder: (context, sellings, child) {
        return ItemsMainScreen(
            showTotal: true,
            title: "فاتورة شراء",
            content: Column(
              children: [
                IndexAndDate(),
                SizedBox(height: 10),
                PaymentAndDisCount(
                  discountController: discount,
                  paymentMethod: paymentMethod,
                  change: (value) => sellings.changePaymentMethod(value),
                ),
                SuppliersDropdown(),
                const SizedBox(height: 10),
                Consumer<ItemsProvider>(
                  builder: (context, itemsProvider, child) {
                    qty.text = itemsProvider.quantity.toString();
                    price.text = itemsProvider.price.toString();
                    return Container(
                      padding: EdgeInsets.all(10),
                      margin: EdgeInsets.symmetric(vertical: 5),
                      decoration: BoxDecoration(
                          color: MyColors.white,
                          borderRadius: BorderRadius.circular(10)),
                      child: Column(
                        children: [
                          ItemsDropdown(),
                          const SizedBox(height: 10),
                          UnitAndQtyAndPrice(
                            unit: itemsProvider.unitName,
                            showPrice: true,
                            qty: qty,
                            price: price,
                          ),
                          MyElevatedButton(
                            onPressed: () {
                              // addToBillModel(context);
                            },
                            title: 'إضافة',
                            size: Size(SizeConfig.screenWidth!, 50),
                          ),
                          const SizedBox(height: 10),
                        ],
                      ),
                    );
                  },
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 2),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topRight: Radius.circular(10))),
                        child: MyText(title: "م", size: 12),
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 2),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(color: Colors.white),
                        child: MyText(
                          title: "الوصف",
                          size: 12,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 2),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10))),
                        child: MyText(
                          title: "الأجمالي",
                          size: 12,
                        ),
                      ),
                    ),
                  ],
                ),
                Expanded(
                  child: Consumer<ItemsProvider>(
                    builder: (context, purchasingItems, child) {
                      return ListView.builder(
                        itemCount: purchasingItems.purchaseBillItems.length,
                        itemBuilder: (BuildContext context, int index) {
                          return ListItem(
                            desc: purchasingItems
                                .purchaseBillItems[index].itemName!,
                            index: (index + 1).toString(),
                            total: purchasingItems.purchaseBillItems[index].tot
                                .toString(),
                          );
                        },
                      );
                    },
                  ),
                )
              ],
            ));
      },
    );
  }
}
