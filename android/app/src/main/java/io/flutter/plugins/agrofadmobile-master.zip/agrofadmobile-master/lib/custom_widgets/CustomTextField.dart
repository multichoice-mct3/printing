import 'package:agrofad/constants.dart';
import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  String hint;
  IconData icon;
  final Function OnClick;

  CustomTextField(
      {@required this.hint, @required this.icon, @required this.OnClick});
  @override
  bool checked = false;

  getErrorMessage(hint) {
    switch (hint) {
      case 'اسم المستخدم':
        return 'من فضلك ادخل اسم المستخدم الخاص بك';
        break;
      case 'الرقم السري':
        return 'من فضلك ادخل الرقم السري الخاص بك';
        break;
      case 'اسم الشركة':
        return 'من فضلك ادخل اسم الشركة';
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 5),
      child: Container(
        // alignment: AlignmentDirectional.topEnd,
        child: Align(
          child: TextFormField(
            textAlign: TextAlign.end,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
            validator: (Value) {
              if (Value.isEmpty) {
                return getErrorMessage(hint);
              } else
                return null;
            },
            obscureText: hint == 'الرقم السري' ? true : false,
            onSaved: OnClick,
            decoration: InputDecoration(
              isDense: true,
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              hintText: hint,
              hintStyle: checked == false
                  ? TextStyle(
                      color: KmainColor, fontFamily: 'cocon', fontSize: 18)
                  : TextStyle(
                      color: KmainColor,
                      fontFamily: 'cocon',
                      fontSize: 14,
                    ),
              prefixIcon: Icon(
                //to add icon in textfield
                icon,
                color: KmainColor,
                size: 25, // for icon color
              ),
              filled: true,
              fillColor: Colors.white,
              errorText: null,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.grey,
                  )),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.grey,
                  )),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.grey,
                  )),
              focusedErrorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.grey,
                  )),
            ),
          ),
        ),
      ),
    );
  }
}
