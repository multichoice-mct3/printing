import 'package:elfares/genaral/constants/MyDropDown.dart';
import 'package:elfares/genaral/providers/CustomerProvider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CustomersDropdown extends StatelessWidget {
  const CustomersDropdown({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<CustomersProvider>(
      builder: (context, customers, child) => CustomDropDown(
        hint: "اختر العميل",
        items: customers.customersNames,
        value: customers.customerName,
        onChange: (value) => customers.changeCustomerName(value),
      ),
    );
  }
}
