import 'package:easy_localization/easy_localization.dart';
import 'package:elfares/genaral/widgets/WidgetsImport.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'genaral/utilities/CachHelper.dart';
import 'genaral/utilities/MainData.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  await CachHelper.init();
  runApp(EasyLocalization(
    supportedLocales: [Locale('ar', 'EG'), Locale('en', 'US')],
    path: 'assets/langs',
    fallbackLocale: Locale('ar', 'EG'),
    startLocale: Locale('ar', 'EG'),
    child: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  static final navigatorKey = GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: MainData.providers(context),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
        title: 'الفارس',
        theme: MainData.defaultThem,
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        home: Splash(),
      ),
    );
  }
}
