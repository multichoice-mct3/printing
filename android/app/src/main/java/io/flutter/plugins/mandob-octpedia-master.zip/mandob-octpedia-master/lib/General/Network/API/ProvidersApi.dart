import 'dart:convert';

import 'package:mandoboct/General/Models/ProviderModel.dart';

import '../Http.dart';

class ProviderApi {
  HttpMethods _http = HttpMethods();
  Future<List<ProviderModel>> getProvidersFromApi(int serviceId) async {
    List<ProviderModel>? providers;
    var _data =
        await _http.getData(url: "ProvidesByServices?ServicesId=$serviceId");
    if (_data != null) {
      List<Map<String, dynamic>> _providerJson =
          List<Map<String, dynamic>>.from(_data);
      providers = _providerJson
          .map((provider) => ProviderModel.fromJson(provider))
          .toList();
      return providers;
    }

    return providers!;
  }

  Future<List<ProviderModel>> getAllProvidersFromApi() async {
    List<ProviderModel>? providers;
    var _data = await _http.getData(url: "Provides");
    if (_data != null) {
      List<Map<String, dynamic>> _providerJson =
          List<Map<String, dynamic>>.from(_data);
      print(_providerJson[0]);
      providers = _providerJson
          .map((provider) => ProviderModel.fromJson(provider))
          .toList();
      return providers;
    }

    return providers!;
  }

  Future<String> addProvider(
      {String? name,
      String? disc,
      String? phone,
      String? phone2,
      String? social,
      String? address,
      double? lat,
      double? long,
      int? categoryId,
      int? serviceId}) async {
    String _data = await _http.postData(
      url: "Provides",
      body: jsonEncode({
        "providesName": name,
        "providesLogo": "string",
        "providesDisc": disc,
        "phone1": phone,
        "phone2": phone2,
        "socialMediaUrl1": social,
        "socialMediaUrl2": "string",
        "socialMediaUrl3": "string",
        "webUrl": address,
        "mapLatitude": lat,
        "mapLongitude": long,
        "categoriesId": categoryId,
        "servicesId": serviceId,
        // "providesOrder": 1
      }),
    );
    print(jsonEncode({
      "providesName": name,
      "providesLogo": "string",
      "providesDisc": disc,
      "phone1": phone,
      "phone2": phone2,
      "socialMediaUrl1": social,
      "socialMediaUrl2": "string",
      "socialMediaUrl3": "string",
      "webUrl": address,
      "mapLatitude": lat,
      "mapLongitude": long,
      "categoriesId": categoryId,
      "servicesId": serviceId,
      // "providesOrder": 1
    }));
    return _data;
  }
}
