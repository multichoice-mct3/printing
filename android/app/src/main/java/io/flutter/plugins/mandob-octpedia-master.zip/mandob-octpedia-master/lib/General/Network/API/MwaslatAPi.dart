import 'dart:convert';
import 'package:mandoboct/General/Models/StationModel.dart';
import 'package:mandoboct/General/Models/TrafficLinesModel.dart';
import '../Http.dart';

class StationsApi {
  HttpMethods _http = HttpMethods();
  Future<List<TrafficLinesModel>> getTrafficLinesFromApi(int providerId) async {
    List<TrafficLinesModel>? stations;
    var _data = await _http.getData(
        url: "TrafficLinesByProvidesId?ProvidesId=$providerId");
    if (_data != null) {
      List<Map<String, dynamic>> _itemsJson =
          List<Map<String, dynamic>>.from(_data);
      stations =
          _itemsJson.map((item) => TrafficLinesModel.fromJson(item)).toList();
      return stations;
    }

    return stations!;
  }

  Future<String> addStation(StationModel stations) async {
    print(json.encode(stations.toJson()));
    String result = await _http.postData(
      url: "Stations",
      body: json.encode(stations.toJson()),
    );
    return result;
  }
}
