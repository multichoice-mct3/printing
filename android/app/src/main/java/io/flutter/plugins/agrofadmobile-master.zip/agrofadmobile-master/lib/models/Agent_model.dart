

class Agent{
  int AgentId;
  String AgentName;

  Agent({this.AgentId, this.AgentName});


  factory Agent.FromJson(Map<String ,dynamic> agents){

    return Agent(
      AgentName: agents['AgentName'],
      AgentId: agents['AgentId']
    );
  }
}