import 'package:flutter/material.dart';
import 'package:mandoboct/General/Constants/MyColors.dart';

class AuthScreen extends StatelessWidget {
  final Widget content;
  const AuthScreen({Key? key, required this.content}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: MyColors.secondary,
        body: content);
  }
}
