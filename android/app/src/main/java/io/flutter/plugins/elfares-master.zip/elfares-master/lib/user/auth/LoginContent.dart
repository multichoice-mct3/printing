import 'package:elfares/genaral/constants/ElevatedButton.dart';
import 'package:elfares/genaral/constants/constants.dart';
import 'package:elfares/genaral/network/Http.dart';
import 'package:elfares/genaral/utilities/SizeConfig.dart';
import 'package:elfares/genaral/utilities/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../genaral/Constants/IconTextFiled.dart';
import '../../genaral/Constants/MyText.dart';
import '../../genaral/constants/DefaultButton.dart';
import '../../genaral/constants/MyColors.dart';
import '../../genaral/providers/AuthProvider.dart';
import '../../genaral/utilities/CachHelper.dart';
import '../../genaral/utilities/Validator.dart';

import 'AuthMainScreen.dart';

class LoginContent extends StatefulWidget {
  LoginContent({Key? key}) : super(key: key);

  @override
  _LoginContentState createState() => _LoginContentState();
}

class _LoginContentState extends State<LoginContent> {
  final TextEditingController _userName = TextEditingController();
  final TextEditingController _company = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool enable = false;
  Future<void> onTap() async {
    var result = await HttpMethods().companyLogin(company: _company.text);
    print("result $result");
    if (result != null) {
      setState(() {
        enable = true;
      });
    } else {
      print("object");
      Utils.showSnackBar('غير مسجل', Colors.red, context);
    }
  }

  @override
  Widget build(BuildContext context) {
    // HttpMethods().sessionExpired();
    return AuthScreen(
        content: Column(
      children: [
        Expanded(
            child: SizedBox(
              child: Container(
                padding: const EdgeInsets.only(top: 50, right: 15),
                width: double.infinity,
                decoration:
                    BoxDecoration(gradient: servGradients[3], boxShadow: [
                  BoxShadow(
                      color: MyColors.secondary.withOpacity(.7),
                      offset: Offset(2, 0),
                      blurRadius: 10,
                      spreadRadius: 5)
                ]),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    MyText(
                      title: "مرحباً بعودتك !",
                      size: 14,
                      color: MyColors.white,
                    ),
                    Divider(
                        thickness: 3,
                        color: Colors.white,
                        endIndent: SizeConfig.screenWidth! * .75),
                    MyText(title: "برجاء تسجيل الدخول", color: MyColors.white),
                  ],
                ),
              ),
            ),
            flex: 2),
        Form(
          key: _formKey,
          child: Expanded(
            flex: 5,
            child: Container(
              color: MyColors.primary,
              child: Container(
                decoration: BoxDecoration(
                    color: MyColors.white,
                    borderRadius:
                        BorderRadius.only(topRight: Radius.circular(30))),
                padding: const EdgeInsets.fromLTRB(20, 15, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Expanded(
                          child: IconTextFiled(
                            controller: _company,
                            margin: const EdgeInsets.symmetric(vertical: 10),
                            label: 'الشركة',
                            isPassword: false,
                            icon: Icon(Icons.person),
                            validate: (value) =>
                                Validator().validateEmpty(value: value),
                          ),
                        ),
                        const SizedBox(width: 10),
                        MyElevatedButton(
                          onPressed: () async => onTap(),
                          title: "تحقق",
                          size: Size(SizeConfig.screenWidth! * .2, 50),
                        )
                      ],
                    ),
                    IconTextFiled(
                      controller: _userName,
                      margin: const EdgeInsets.symmetric(vertical: 10),
                      label: 'اسم المستخدم',
                      isPassword: false,
                      icon: Icon(Icons.person),
                      enable: enable,
                      validate: (value) =>
                          Validator().validateEmpty(value: value),
                    ),
                    IconTextFiled(
                      controller: _password,
                      margin: const EdgeInsets.symmetric(vertical: 10),
                      label: "كلمة المرور",
                      enable: enable,
                      isPassword: true,
                      icon: Icon(Icons.lock),
                      validate: (value) =>
                          Validator().validateEmpty(value: value),
                    ),
                    Consumer<AuthProvider>(
                      builder: (context, auth, child) => DefaultButton(
                        color: MyColors.primary,
                        child: auth.isAuth
                            ? CircularProgressIndicator(
                                valueColor:
                                    AlwaysStoppedAnimation(Colors.white))
                            : MyText(
                                title: "تسجيل الدخول",
                                size: 16,
                                color: Colors.white,
                              ),
                        onTap: () async {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            await auth.login(
                                _userName.text, _password.text, context);
                            CachHelper.saveData(
                                key: "userName", value: _userName.text);
                          }
                        },
                        margin: const EdgeInsets.symmetric(vertical: 20),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ));
  }

  @override
  void dispose() {
    _password.dispose();
    _userName.dispose();
    super.dispose();
  }
}
