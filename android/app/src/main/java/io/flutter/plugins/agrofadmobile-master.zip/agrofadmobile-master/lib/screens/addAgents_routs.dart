import 'package:agrofad/api/get_customers-api.dart';
import 'package:agrofad/api/post_EmpDailyRouts_api.dart';
import 'package:agrofad/custom_widgets/custom_dialoge.dart';
import 'package:agrofad/models/avrCause_model.dart';
import 'package:agrofad/models/customer_model.dart';
import 'package:agrofad/models/routeType_model.dart';
import 'package:agrofad/models/route_model.dart';
import 'package:agrofad/provider_services/agentRouts_provider.dart';
import 'package:agrofad/provider_services/user_Detail_provider.dart';
import 'package:async/async.dart';
import 'package:awesome_loader/awesome_loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:intl/intl.dart' as intl;
import 'package:provider/provider.dart';
import 'package:search_choices/search_choices.dart';

import '../constants.dart';

class AddAgentRouts extends StatefulWidget {
  static String id = 'AddAgentRouts';
  @override
  _State createState() => _State();
}

class _State extends State<AddAgentRouts> {
  TextEditingController RoutNotes = TextEditingController();
  TextEditingController DateController = TextEditingController();
String SelectedDate;
  int SelectEdCustomerId;
  String CauseNameSelected;
  int CauseNameId;
  GetCustomersApi _customersApi = GetCustomersApi();
  PostEmpDailyRoutsApi _postEmpDailyRoutsApi=PostEmpDailyRoutsApi();
  List<Customer> Customers = [];
  final MemozizedFuture = new AsyncMemoizer();

  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    DateController.text =
        Provider.of<AgentRoutsProvider>(context).GetSelectedDate;
    return SafeArea(
      child: FutureBuilder(
        future: MemozizedFuture.runOnce(
          () => Future.wait(<Future<dynamic>>[
            Provider.of<AgentRoutsProvider>(context).getCustomers(),
            Provider.of<AgentRoutsProvider>(context).GetAvrCauses()
          ])),
        builder: (context, AsyncSnapshot snapshot) {
          return Scaffold(
              backgroundColor:
                  snapshot.connectionState == ConnectionState.waiting
                      ? Colors.white
                      : KmainColor,
              floatingActionButton:  snapshot.hasData?FloatingActionButton(
                backgroundColor: Colors.white,
                onPressed: () {
                  _openshowModalBottomSheet(context, ScreenWidth);
                },
                child: Icon(
                  Icons.add,
                  color: KmainColor,
                  size: 30,
                ),
              ):null,
              body: () {
                if (snapshot.connectionState == ConnectionState.done &&
                    snapshot.hasData) {
                  Customers = snapshot.data[0];
                  return Column(
                    children: [
                      FirstContainer(ScreenWidth),
                      Row(
                        children: [
                          Expanded(
                              child: Divider(
                            color: Colors.white,
                            thickness: 3,
                          )),
                          Text(
                            '  المسارات   ',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                                fontFamily: 'cocon'),
                          ),
                          Expanded(
                              child: Divider(
                            color: Colors.white,
                            thickness: 3,
                          )),
                        ],
                      ),
                      Consumer<AgentRoutsProvider>(
                        builder: (ctx, RoutesProvider, ch) {
                          return Expanded(
                            child: Container(
                              color: OfWhiteColor,
                              child: ListView.builder(
                                  itemCount: RoutesProvider.GetRoutList.length,
                                  itemBuilder: (ctx, index) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 2, vertical: 2),
                                      child: Slidable(
                                        actionPane: SlidableDrawerActionPane(),
                                        actionExtentRatio: 0.10,
                                        secondaryActions: [
                                          IconSlideAction(
                                            color: KmainColor,
                                            iconWidget: Icon(
                                              Icons.delete,
                                              color: Colors.red,
                                              size: 25,
                                            ),
                                            onTap: () {
                                              RoutesProvider.RemoveRoutToRoutList(
                                                  index);
                                            },
                                          ),
                                        ],
                                        child: Card(
                                          color: Colors.white,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(10.0),
                                            side: BorderSide(
                                              color: KmainColor,
                                              width: 2.0,
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10, vertical: 3),
                                            child: Column(
                                              children: [
                                                Row(
                                                  textDirection:
                                                      TextDirection.rtl,
                                                  children: [
                                                    Container(
                                                      width: ScreenWidth * .25,
                                                      child: Text(
                                                        ': العميل ',
                                                        textAlign: TextAlign.end,
                                                        style: TextStyle(
                                                            color: KmainColor,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 17),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Text(
                                                        RoutesProvider
                                                            .GetRoutList[index]
                                                            .CustomerName,
                                                        textAlign: TextAlign.end,
                                                        style: TextStyle(
                                                            color:Colors.black,
                                                            fontSize: 15),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                Row(
                                                  textDirection:
                                                      TextDirection.rtl,
                                                  children: [
                                                    Container(
                                                      width: ScreenWidth * .25,
                                                      child: Text(
                                                        ': سبب الزيارة ',
                                                        textAlign: TextAlign.end,
                                                        style: TextStyle(
                                                            color: KmainColor,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 17),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Text(
                                                        RoutesProvider
                                                            .GetRoutList[index]
                                                            .AVCName,
                                                        textAlign: TextAlign.end,
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 15),
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                Row(
                                                  textDirection:
                                                      TextDirection.rtl,
                                                  children: [
                                                    Container(
                                                      width: ScreenWidth * .25,
                                                      child: Text(
                                                        ': الملاحظات ',
                                                        textAlign: TextAlign.end,
                                                        style: TextStyle(
                                                            color: KmainColor,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 17),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Text(
                                                        RoutesProvider
                                                            .GetRoutList[index]
                                                            .ManualCauseNote,
                                                        textAlign: TextAlign.end,
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 15),
                                                      ),
                                                    )
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  }),
                            ),
                          );
                        },
                      )
                    ],
                  );
                } else if (snapshot.hasError)
                  return Center(
                    child: Text('Error'),
                  );
                else {
                  return Center(
                    child: Container(
                      height: 30,
                      width: 30,
                      child: AwesomeLoader(
                        loaderType: AwesomeLoader.AwesomeLoader3,
                        color: KmainColor,
                      ),
                    ),
                  );
                }
              }());
        },
      ),
    );
  }

  Widget FirstContainer(double ScreenWidth) {
    return Column(
      children: [
        Container(
          width: ScreenWidth,
          height: 40,
          color: OfWhiteColor,
          child: Padding(
            padding: const EdgeInsets.only(right: 25),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'اضافة مسارات مندوب',
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: KmainColor,
                    fontSize: 20,
                    fontFamily: 'cocon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 15, top: 3),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)),
                    color: Colors.amber,

                    onPressed:()async {
                      if (! Provider.of<AgentRoutsProvider>(context,listen: false).GetRoutList.isEmpty){
                        await   _postEmpDailyRoutsApi.PostEmpDailyRouts(Provider.of<AgentRoutsProvider>(context,listen: false).GetRoutList)
                            .then((value) {

                              if (value){
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return CustomDialoge(
                                        Anothercontext: context,
                                        Message: 'تم الحفظ بنجاح',
                                        Callback: () {
                                          Navigator.of(context).pop();
                                          Provider.of<AgentRoutsProvider>(context,listen: false).EmptyRoutList();
                                        },
                                      );
                                    });
                              }
                              else {
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return CustomDialoge(
                                        Anothercontext: context,
                                        Message: 'لم يتم الحفظ ',
                                        Callback: () {
                                          Navigator.of(context).pop();
                                        },
                                      );
                                    });
                              }

                        }



                        );

                      }
                      else {
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return CustomDialoge(
                                Anothercontext: context,
                                Message: 'الرجاء اضافة بعض المسارات',
                                Callback: () {
                                  Navigator.of(context).pop();
                                },
                              );
                            });
                      }

                    },
                    // onPressed: () async {
                    //   if (!ItemList.isEmpty &&
                    //       //  ItemList!=null&&
                    //       SelectedDate != null &&
                    //       SelectEdCustomerId != null) {
                    //     await PostApi();
                    //     if (posted) {
                    //       showDialog(
                    //           context: context,
                    //           builder: (BuildContext context) {
                    //             return CustomDialoge(
                    //               Anothercontext: context,
                    //               Message: 'تم الحفظ بنجاح',
                    //               Callback: () {
                    //                 Navigator.of(context).pop();
                    //                 ItemList = [];
                    //                 SelectedCustomerName = null;
                    //                 SelectEdCustomerId = null;
                    //                 ItemNameselectedValue = null;
                    //                 Qty = null;
                    //                 orderController.clear();
                    //                 UnitSelectValue = null;
                    //               },
                    //             );
                    //           });
                    //     } else {
                    //       showDialog(
                    //           context: context,
                    //           builder: (BuildContext context) {
                    //             return CustomDialoge(
                    //               Anothercontext: context,
                    //               Message: 'لم يتم الحفظ بنجاح',
                    //               Callback: () {
                    //                 Navigator.of(context).pop();
                    //               },
                    //             );
                    //           });
                    //     }
                    //   } else
                    //     showDialog(
                    //         context: context,
                    //         builder: (BuildContext context) {
                    //           return CustomDialoge(
                    //             Anothercontext: context,
                    //             Message: 'من فضلك قم بادخال كل البيانات  ',
                    //             Callback: () {
                    //               Navigator.of(context).pop();
                    //             },
                    //           );
                    //         });
                    child: Text(
                      'حفظ',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'cocon',
                          fontSize: 16),
                    ),
                  ),
                ),
                InkWell(
                 onTap: (){
                   Navigator.pop(context);
                 } ,
                    child: Icon(Icons.arrow_back,size: 25,)),
                SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        ),
        SizedBox(
          height: 10,
        ),
        DateRow1(),
        SizedBox(
          height: 10,
        ),
      ],
    );
  }

  Widget DateRow1() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        textDirection: TextDirection.rtl,
        children: [
          Text(
            'تاريخ المسارات',
            style: TextStyle(
                fontFamily: 'cocon',
                fontSize: 18,
                color: Colors.white,
                fontWeight: FontWeight.bold),
          ),
          SizedBox(
            width: 10,
          ),
          SizedBox(
            height: 35,
            width: 150,
            child: TextField(
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 15,
                  color: Colors.black,
                  fontWeight: FontWeight.bold),
              textDirection: TextDirection.rtl,
              controller: DateController,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                contentPadding: EdgeInsets.only(bottom: 5),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: Colors.grey,
                    )),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: Colors.grey,
                    )),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: Colors.grey,
                    )),
              ),
            ),
          ),
          SelectDate()
        ],
      ),
    );
  }

  Widget CustomerRow(ScreenWidth) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        // height:WidgetHiegt*22/100,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          //  textDirection: TextDirection.rtl,
          children: [
            Directionality(
              textDirection: TextDirection.rtl,
              child: Container(
                width: 85 / 100 * ScreenWidth,
                decoration: BoxDecoration(
                    color: OfWhiteColor,
                    border: Border.all(color: KmainColor, width: 2),
                    borderRadius: BorderRadius.circular(10)),
                child: getCustomertwo(Customers),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget getCustomertwo(List<Customer> Customers) {
    List<String> CustomerNames = [];

    int Id;
    for (Customer customer in Customers) {
      CustomerNames.add(customer.CustomerName);
    }
    int getCustomerId(String Customername) {
      for (Customer customer in Customers) {
        if (customer.CustomerName == Customername) {
          Id = customer.CustomerID;
        }
      }
      return Id;
    }

    return Consumer<AgentRoutsProvider>(
      builder: (ctx,AgentProvider,ch){
        return  SearchChoices.single(
          items: CustomerNames.map<DropdownMenuItem<String>>((string) {
            return (DropdownMenuItem<String>(
              child: Text(
                string,
                textDirection: TextDirection.rtl,
                style:
                TextStyle(fontSize: 17, fontFamily: 'cocon', color: KmainColor),
              ),
              value: string,
            ));
          }).toList(),
          /////////////////////
          icon: Icon(
            Icons.arrow_drop_down,
            size: 22,
            color: KmainColor,
          ),
          clearIcon: Icon(
            Icons.clear,
            size: 20,
            color: Colors.red,
          ),
          underline: Container(
            height: 0.0,
            padding: const EdgeInsets.all(0.0),
            margin: const EdgeInsets.all(0.0),
            decoration: BoxDecoration(border: null),
          ),
          ///////////////////////
          menuBackgroundColor: OfWhiteColor,
          value: AgentProvider.GetSelectedCustomerName,
          hint: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Text(
              "اختر العميل",
              textDirection: TextDirection.rtl,
              style:
              TextStyle(fontSize: 15, fontFamily: 'cocon', color: KmainColor),
            ),
          ),
          searchHint: Text(
            "اختر العميل",
            textDirection: TextDirection.rtl,
            style: TextStyle(fontSize: 18, fontFamily: 'cocon', color: KmainColor),
          ),
          closeButton: FlatButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text(
              "اغلاق",
              textDirection: TextDirection.rtl,
              style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'cocon',
                  color: KmainColor),
            ),
          ),
          onChanged: (String value) {
            SelectEdCustomerId = getCustomerId(value);
            AgentProvider.changeCustomer(value, SelectEdCustomerId);


          },
          isExpanded: true,
          rightToLeft: true,
          displayItem: (item, selected) {
            return (Row(textDirection: TextDirection.rtl, children: [
              selected
                  ? Icon(
                Icons.radio_button_checked,
                color: Colors.grey,
              )
                  : Icon(
                Icons.radio_button_unchecked,
                color: Colors.grey,
              ),
              SizedBox(width: 7),
              item,
              Expanded(
                child: SizedBox.shrink(),
              ),
            ]));
          },
          selectedValueWidgetFn: (item) {
            return Row(
              textDirection: TextDirection.rtl,
              children: <Widget>[
                (Text(
                  item,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                      fontSize: 18, fontFamily: 'cocon', color: KmainColor),
                )),
              ],
            );
          },
        );
      },

    );

    // return DropdownSearch(
    //   items:CustomerNames ,
    //   mode: Mode.BOTTOM_SHEET,
    //   hint:'المندوب',
    //   showSelectedItem: true,
    //   searchBoxDecoration: InputDecoration(
    //           hintText: 'ابحث في العملاء',
    //           hintStyle: TextStyle(
    //           color: Colors.black,
    //           fontSize: 18
    //         ),
    //    contentPadding: EdgeInsets.symmetric(horizontal: 130),
    //    filled: true,
    //    fillColor:OfWhiteColor
    //  ),
    //
    //   showSearchBox: true,
    //   popupTitle: Container(
    //     height: 40,
    //     decoration: BoxDecoration(
    //       color: KmainColor,
    //       borderRadius: BorderRadius.only(
    //         topLeft: Radius.circular(20),
    //         topRight: Radius.circular(20),
    //       ),
    //     ),
    //     child: Center(
    //       child: Text(
    //         'العملاء',
    //         style: TextStyle(
    //           fontSize: 24,
    //           fontWeight: FontWeight.bold,
    //           color: Colors.white,
    //         ),
    //       ),
    //     ),
    //   ),
    //   popupShape: RoundedRectangleBorder(
    //     borderRadius: BorderRadius.only(
    //       topLeft: Radius.circular(24),
    //       topRight: Radius.circular(24),
    //     ),
    //   ),
    //
    //   onChanged: (value){
    //     setState(() {
    //       SelectedCustomerName=value;
    //       SelectEdCustomerId=getCustomerId(SelectedCustomerName);
    //     });
    //   },
    //
    //   enabled: true,
    //   dropdownBuilder:_customDropDownExample ,
    //
    //
    // );
  }

  Widget SelectDate() {
    return MaterialButton(
      // height: double.infinity,
      minWidth: 0,
      padding: EdgeInsets.symmetric(horizontal: 20),
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      onPressed: () {
        DatePicker.showDatePicker(context,
            showTitleActions: true,
            minTime: DateTime(2019, 1, 1),
            maxTime: DateTime(2030, 1, 1),
            theme: DatePickerTheme(
                cancelStyle: TextStyle(
                    color: OfWhiteColor,
                    fontSize: 15,
                    fontWeight: FontWeight.bold),
                headerColor: Colors.amber,
                backgroundColor: Colors.white,
                itemStyle: TextStyle(
                    color: KmainColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 18),
                doneStyle: TextStyle(color: Colors.white, fontSize: 16)),
            onConfirm: (DateTime date) {
        Provider.of<AgentRoutsProvider>(context,listen: false).changeSelectedDate(date);

        }, currentTime: DateTime.now(), locale: LocaleType.en);
      },
      child: Icon(
        Icons.date_range,
        color: Colors.white,
      ),
    );
  }

  Widget GetRouteTypes(List<AvrCause>AvrCauses ) {

    List<String> causesNames = [];
    for (AvrCause cause in AvrCauses) {
     causesNames.add(cause.AVCName);
    }

    int GetCauseId(String causeName) {
      int Id;
      for (AvrCause cause in AvrCauses) {
        if (cause.AVCName == causeName) {
          Id = cause.AVCId;
        }
      }
      return Id;
    }
    return Consumer<AgentRoutsProvider>(
      builder: (ctx,routsProvider,ch){
        return  Padding(
          padding: const EdgeInsets.only(right: 15),
          child: Container(
            height: 45,
            child: Row(
              // mainAxisAlignment: MainAxisAlignment.center,
              textDirection: TextDirection.rtl,
              children: [
                Text(
                  'سبب الزيارة',
                  style: TextStyle(
                      fontFamily: 'cocon',
                      fontSize: 18,
                      color: KmainColor,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 10,
                ),
                Directionality(
                  textDirection: TextDirection.rtl,
                  child: Container(
                    height: 50,
                    width: 200,
                    margin: EdgeInsets.only(left: 10),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: KmainColor, width: 2),
                        color: Colors.white),
                    child: causesNames.isEmpty
                        ? Container()
                        : DropdownButton<String>(
                      // isExpanded: true,
                      // selectedItemBuilder: (BuildContext context) {
                      //   return TreasuryList.map((String Treasury) {
                      //     return Padding(
                      //       padding: const EdgeInsets.only(
                      //           right: 12, top: 12),
                      //       child: Text(
                      //         Treasury,
                      //         textAlign: TextAlign.center,
                      //       ),
                      //     );
                      //   }).toList();
                      // },
                      style: TextStyle(
                          color: KmainColor,
                          fontSize: 15,
                          fontFamily: 'cocon',
                          fontWeight: FontWeight.bold),
                      value: routsProvider.GetCauseNameSelected,
                      items:
                      causesNames.map<DropdownMenuItem<String>>((String Value) {
                        return DropdownMenuItem<String>(
                          value: Value,
                          child: Row(
                             textDirection: TextDirection.rtl,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 10),
                                child: Text(
                                  Value,
                                  textAlign: TextAlign.start
                                  ,style: TextStyle(
                                  color: KmainColor
                                ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),

                      underline: Container(
                        height: 0.0,
                        padding: const EdgeInsets.all(0.0),
                        margin: const EdgeInsets.all(0.0),
                        decoration: BoxDecoration(border: null),
                      ),
                      icon: Icon(
                        Icons.arrow_drop_down,
                        size: 22,
                        color: KmainColor,
                      ),
                      isExpanded: true,
                      onChanged: (value) {
                        int CauseId = GetCauseId(value);
                        routsProvider.changeCauseName(value, CauseId);
                      },

                      hint: Padding(
                        padding: const EdgeInsets.only(right: 10),
                        child: Text(
                          'سبب الزيارة',
                          style: TextStyle(
                              color: KmainColor,
                              fontSize: 15,
                              fontFamily: 'cocon',
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },

    );
  }

  Future _openshowModalBottomSheet(BuildContext ctx, double ScreenWidth) async {
    return await showModalBottomSheet(
        context: ctx,
        isScrollControlled: true,
        enableDrag: true,
        isDismissible: true,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(25.0))),
        builder: (BuildContext context) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Padding(
              padding: MediaQuery.of(context).viewInsets,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          ' بيانات المسار الجديد',
                          style: TextStyle(
                              fontFamily: 'cocon',
                              fontWeight: FontWeight.bold,
                              fontSize: 17,
                              color: KmainColor),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 70),
                    child: Divider(
                      thickness: 3,
                      color: KmainColor,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  GetRouteTypes(Provider.of<AgentRoutsProvider>(context).GetAvrCausee),
                  SizedBox(
                    height: 10,
                  ),
                  CustomerRow(ScreenWidth),
                  SizedBox(
                    height: 10,
                  ),
                  RNotes(ScreenWidth),
                  SizedBox(
                    height: 10,
                  ),
                  Consumer<AgentRoutsProvider>(
                    builder: (ctx,RouteProvider,ch){
                      return InkWell(
                        onTap: () {
                          if (RouteProvider.GetCauseNameSelected !=null&&RouteProvider.GetSelectedCustomerName!=null){
                            AgentVisitRouteModel route = AgentVisitRouteModel(
                                AVCName:RouteProvider.GetCauseNameSelected,
                                AVCId: RouteProvider.GetCauseNameId,
                                AVRDate: RouteProvider.GetSelectedDate,
                                CustomerId:RouteProvider.GetSelectEdCustomerId,
                                CustomerName: RouteProvider.GetSelectedCustomerName,
                                ManualCauseNote:  Provider.of<AgentRoutsProvider>(context,listen: false).GetRouteNotes,
                                EmpId: Provider.of<UserDetail>(context,listen: false).GetEmpId
                            );
                            Provider.of<AgentRoutsProvider>(context, listen: false)
                                .AddRoutToRoutList(route);
                            Navigator.pop(context);
                          }
                          else {
                            showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return Dialog(
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            20.0)), //this right here
                                    child: Container(
                                      height: 120,
                                      child: Padding(
                                        padding: const EdgeInsets.all(20.0),
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Align(
                                              alignment: AlignmentDirectional.topEnd,
                                              child: Text(
                                                'يجب ادخال العميل وسبب الزيارة ',
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold,
                                                  fontFamily: 'cocon',
                                                  color: KmainColor,
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 100.0,
                                              child: RaisedButton(
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  },
                                                  child: Text(
                                                    "اغلاق",
                                                    style:
                                                    TextStyle(color: Colors.white),
                                                  ),
                                                  color: KmainColor),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                });
                          }

                        },
                        child: Container(
                          height: 40,
                          width: ScreenWidth / 4,
                          decoration: BoxDecoration(
                            color: KmainColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Text(
                              'اضافة',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontFamily: 'cocon',
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      );
                    },

                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
          );
        });
  }

  Widget RNotes(double ScreenWidth) {
    return Row(
      textDirection: TextDirection.rtl,
      children: [
        Container(
          width: 85 / 100 * ScreenWidth,
          margin: EdgeInsets.symmetric(horizontal: 15),
          child: TextField(
            textAlign: TextAlign.end,
            cursorColor: KmainColor,
           // controller: RoutNotes,
            maxLines: 2,
            onChanged: (value){
             // RoutNotes.text=value;
              Provider.of<AgentRoutsProvider>(context,listen: false).changeNotes(value);
            },
            style: TextStyle(color: KmainColor, fontSize: 14),
            decoration: InputDecoration(
              filled: true,
              fillColor: WhiteColor,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: KmainColor, width: 2)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: KmainColor, width: 2)),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: KmainColor, width: 2)),
              //labelText: 'البيان',
              hintText: 'الملاحظات',
              hintStyle: TextStyle(color: KmainColor, fontSize: 15),
              alignLabelWithHint: false,
            ),
            keyboardType: TextInputType.multiline,
          ),
        ),
      ],
    );
  }
}
