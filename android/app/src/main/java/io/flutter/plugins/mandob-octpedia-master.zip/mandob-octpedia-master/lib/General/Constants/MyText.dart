import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class MyText extends StatelessWidget {
  String title;
  Color? color = Colors.black;
  double? size = 16;
  TextAlign? alien = TextAlign.start;
  TextDecoration? decoration = TextDecoration.none;
  TextOverflow? overflow;
  bool isNumber;
  FontWeight fontWeight;

  MyText({
    required this.title,
    this.color,
    this.size,
    this.alien,
    this.decoration,
    this.overflow,
    this.isNumber = false,
    this.fontWeight = FontWeight.bold,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      "$title",
      textAlign: alien,
      textScaleFactor: 1,
//      overflow: TextOverflow.ellipsis,
      style: TextStyle(
          color: color,
          fontSize: size,
          fontFamily: "Almarai",
          decoration: decoration,
          fontWeight: fontWeight),
      overflow: overflow,
    );
  }
}
