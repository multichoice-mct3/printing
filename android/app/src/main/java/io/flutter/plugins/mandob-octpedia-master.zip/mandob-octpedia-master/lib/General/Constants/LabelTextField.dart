import 'package:flutter/material.dart';

import 'MyColors.dart';
import 'constants.dart';

// ignore: must_be_immutable
class LabelTextField extends StatelessWidget {
  TextEditingController? controller;
  String? label;
  EdgeInsets? margin = EdgeInsets.all(0);
  bool? isPassword = false;
  TextInputType? type = TextInputType.text;
  Function? onChange;
  final Function(String value)? validate;

  LabelTextField({
    required this.label,
    this.controller,
    this.margin,
    this.isPassword,
    this.type,
    this.onChange,
    this.validate,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 55,
      margin: margin,
      decoration: BoxDecoration(boxShadow: kBoxShadow2),
      child: TextFormField(
        controller: controller,
        keyboardType: type,
        onChanged: (value) => onChange,
        obscureText: isPassword!,
        validator: (value) => validate!(value!),
        style: TextStyle(
            fontSize: 14,
            fontFamily: "Almarai",
            color: Colors.black.withOpacity(.7)),
        decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    color: MyColors.primary.withOpacity(.5), width: .5),
                borderRadius: BorderRadius.circular(10)),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                    color: MyColors.primary.withOpacity(.5), width: 2)),
            hintText: "  $label  ",
            hintStyle: TextStyle(
                fontFamily: "Almarai", fontSize: 14, color: MyColors.grey),
            contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            filled: true,
            fillColor: Colors.white),
      ),
    );
  }
}
