import 'dart:convert';
import 'package:agrofad/models/Statment_model.dart';
import 'package:http/http.dart' as http;
import 'login_apis.dart';


class GetStatmentApi{
  LoginApi _loginApi=LoginApi();
  List<StatmentModel> Statments=[];
  Future<List<StatmentModel>> Getstatments(String AccountId, String ToDate,String FromDate) async {
    await _loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${_loginApi.token}',
    };
    var response = await http.get(
        "http://104.196.134.107/AfitAPI/api/Statement?Account_Id="+"$AccountId"+"&fromDate="+"$FromDate"+"&toDate="+ToDate,
        headers:Headers
    );
    if (response.statusCode == 200) {
      //var result=jsonDecode(response.body);
      print(response.body);
      Statments=ParseItems(response.body);
      // if (result.length==0){
      //   UserAuth=false;
      }
      else {
        // await saveUserData(result);
         print(response.body);
        // UserAuth=true;
      }

    return Statments;
  }
  List<StatmentModel> ParseItems(String responseBody) {
    final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();

    return parsedItems.map<StatmentModel>((json) => StatmentModel.FromJson(json)).toList();
  }


}