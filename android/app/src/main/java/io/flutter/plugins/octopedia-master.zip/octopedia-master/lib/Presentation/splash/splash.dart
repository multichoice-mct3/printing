import 'package:flutter/material.dart';
import 'package:octpedia/App/Utilities/my_route.dart';
import 'package:octpedia/App/Utilities/size_config.dart';
import 'package:octpedia/Presentation/Home/home.dart';
import 'package:octpedia/Presentation/Resources/assets_manager.dart';
import 'package:octpedia/Presentation/Resources/color_manager.dart';
import 'package:octpedia/Presentation/Resources/values_manager.dart';
import 'package:octpedia/Presentation/widgets/animation_container.dart';

class Splash extends StatefulWidget {
  const Splash({Key? key}) : super(key: key);

  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();

    Future.delayed(DurationConstant.splashDuration, () async {
      MyRoute().navigate(context: context, route: const HomeScreen());
    });
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: ColorManager.white,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimationContainer(
              distance: MediaQuery.of(context).size.width * .5,
              index: 0,
              duration: DurationConstant.splashDuration,
              vertical: true,
              child: Image(
                width: 250,
                height: MediaQuery.of(context).size.width,
                image: const AssetImage(ImageAssets.splashLogo),
                fit: BoxFit.contain,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
