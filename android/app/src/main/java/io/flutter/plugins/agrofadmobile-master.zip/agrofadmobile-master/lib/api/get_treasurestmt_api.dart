import 'dart:convert';
import 'package:agrofad/models/account_model.dart';
import 'package:http/http.dart' as http;

import 'login_apis.dart';

class GetTreasureAccountsApi{
  LoginApi loginApi = new LoginApi();
  List <Account>Accounts=[];
  String BaseUrl = 'http://104.196.134.107/AfitAPI';
  Future<List <Account>> GetTreasureAccounts() async {
    await loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var response = await http.get("http://104.196.134.107/AfitAPI/api/Accounts",
        headers: Headers);
    if (response.statusCode == 200) {
      Accounts= ParseItems(response.body);
      print (Accounts[1].AccountName);

    } else {
      print(response.body);
    }
    return Accounts;
  }
  //fn get the item list
  List<Account> ParseItems(String responseBody) {
    final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();
    return parsedItems.map<Account>((json) => Account.fromJson(json)).toList();
  }
}