
import 'package:agrofad/api/post_customerAdded.dart';
import 'package:agrofad/custom_widgets/custom_dialoge.dart';
import 'package:agrofad/models/customer_model.dart';
import 'package:agrofad/provider_services/agentRouts_provider.dart';
import 'package:awesome_loader/awesome_loader.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;
import 'package:provider/provider.dart';
import '../constants.dart';

class AddCustomer extends StatefulWidget {
  static String id = 'AddCustomer';
  @override
  _State createState() => _State();
}
class _State extends State<AddCustomer> {
  TextEditingController CustomerName=TextEditingController();
  TextEditingController Tel1=TextEditingController();
  TextEditingController Tel2=TextEditingController();
  TextEditingController Mobile1=TextEditingController();
  TextEditingController Mobile2=TextEditingController();
  TextEditingController Adress=TextEditingController();
  PostCustomerApi _postCustomerApi=PostCustomerApi();

  bool saved=false;
  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery
        .of(context)
        .size
        .width;


    return SafeArea(
   child: Scaffold(
     backgroundColor: KmainColor,
     body: ListView(
       children: [
         FirstContainer(ScreenWidth),
         SaveCustomer(),
     saved?Center(
       child: Container(
         height: 30,
         width: 30,
         child: AwesomeLoader(
           loaderType: AwesomeLoader.AwesomeLoader3,
           color: Colors.white,
         ),
       ),
     ):Container(),
       ],
     ),
   ),
    );
  }

  Widget FirstContainer(double ScreenWidth) {
    return Column(
      children: [
        Container(
          width: ScreenWidth,
          height: 40,
          color: OfWhiteColor,
          child: Padding(
            padding: const EdgeInsets.only(right: 25),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'اضافة عميل ',
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: KmainColor,
                    fontSize: 20,
                    fontFamily: 'cocon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 15, top: 3),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)),
                    color: Colors.amber,

                    onPressed:()async {


                      if (CustomerName !='null'){
                        print('null');
                      }
                      else {
                        print('not ');
                      }
                      Navigator.pop(context);
                    },
                    child: Text(
                      'رجوع',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'cocon',
                          fontSize: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        SizedBox(
          height: 20,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              Expanded(
                flex: 3,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  textDirection: TextDirection.rtl,
                  children: [
                    Text(
                      ' مـ',
                      style: TextStyle(
                          fontFamily: 'cocon',
                          fontSize: 20,
                          color: Colors.white),
                    ),
                    SizedBox(width: 30),
                    SizedBox(
                      height: 40,
                      width: ScreenWidth *.4,
                      child: TextField(
                        textAlign: TextAlign.center,
                        enabled: false,
                        style: TextStyle(fontSize: 12, color: Colors.black),
                        textDirection: TextDirection.rtl,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          enabled: false,
                          hintText: 'Auto',
                          contentPadding: EdgeInsets.only(top: 7),
                          hintStyle: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                color: Colors.grey,
                              )),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                color: Colors.grey,
                              )),
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                color: Colors.grey,
                              )),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 15,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            textDirection: TextDirection.rtl,
            children: [
              Expanded(
                flex: 3,
                child: Row(
                  textDirection: TextDirection.rtl,
                  children: [
                    Text(
                      ' العميل',
                      style: TextStyle(
                          fontFamily: 'cocon',
                          fontSize: 20,
                          color: Colors.white),
                    ),
                    SizedBox(
                      width: 3,
                    ),
                    Expanded(
                      child: SizedBox(
                        // width: ScreenWidth / 4.62,
                        height: 40,
                        child: TextFieldCustom(CustomerName)
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 15,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            textDirection: TextDirection.rtl,
            children: [
              Row(
        textDirection: TextDirection.rtl,
        children: [
          Text(
            ' هاتف1',
            style: TextStyle(
                fontFamily: 'cocon',
                fontSize: 20,
                color: Colors.white),
          ),
          SizedBox(
            width: 10,
          ),
          SizedBox(
              width:  ScreenWidth / 3.3,
              height: 40,
              child: TextFieldCustom(Tel1)
          ),
        ],
      ),
              SizedBox(
                width: 10,
              ),
              Row(
                textDirection: TextDirection.rtl,
                children: [
                  Text(
                    ' هاتف2',
                    style: TextStyle(
                        fontFamily: 'cocon',
                        fontSize: 20,
                        color: Colors.white),
                  ),
                  SizedBox(
                    width: 13,
                  ),
                  SizedBox(
                      width:  ScreenWidth / 3.3,
                      height: 40,
                      child: TextFieldCustom(Tel2)
                  ),
                ],
              ),
            ],
          ),
        ),
        SizedBox(
          height: 15,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            textDirection: TextDirection.rtl,
            children: [
              Row(
                textDirection: TextDirection.rtl,
                children: [
                  Text(
                    'موبايل1',
                    style: TextStyle(
                        fontFamily: 'cocon',
                        fontSize: 20,
                        color: Colors.white),
                  ),
                  SizedBox(
                    width: 2,
                  ),
                  SizedBox(
                      width: ScreenWidth / 3.3,
                      height: 40,
                      child: TextFieldCustom(Mobile1)
                  ),
                ],
              ),
              SizedBox(
                width: 10,
              ),
              Row(
                textDirection: TextDirection.rtl,
                children: [
                  Text(
                    'موبايل2',
                    style: TextStyle(
                        fontFamily: 'cocon',
                        fontSize: 20,
                        color: Colors.white),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  SizedBox(
                      width: ScreenWidth / 3.3,
                      height: 40,
                      child: TextFieldCustom(Mobile2)
                  ),
                ],
              ),
            ],
          ),
        ),
        SizedBox(
          height: 15,
        ),
        Padding(
          padding: const EdgeInsets.only(right: 20),
          child: Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              textDirection: TextDirection.rtl,
              children: [
                Text(
                  'العنوان',
                  style: TextStyle(
                      fontFamily: 'cocon', fontSize: 20, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 12),
          child: TextField(
            textAlign: TextAlign.end,
            cursorColor: KmainColor,
            controller: Adress,
            style: TextStyle(
                fontWeight: FontWeight.bold, color: KmainColor, fontSize: 15),
            decoration: InputDecoration(
              filled: true,
              fillColor: WhiteColor,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.grey,
                  )),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.grey,
                  )),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(
                    color: Colors.grey,
                  )),
              //labelText: 'البيان',
              alignLabelWithHint: false,
            ),
            keyboardType: TextInputType.multiline,
            maxLines: 2,
          ),
        ),

      ],
    );
  }
  Widget TextFieldCustom(TextEditingController controller){
    return TextField(
      textAlign: TextAlign.center,
      controller: controller,
      style: TextStyle(
          fontSize: 15,
          color: Colors.black,
          fontWeight: FontWeight.bold),
      textDirection: TextDirection.rtl,
      onChanged: (value) {
        // SelingInvTot.ChangeDisc(double.parse(value));
      },
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        contentPadding: EdgeInsets.only(bottom: 5),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(
              color: Colors.grey,
            )),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(
              color: Colors.grey,
            )),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(
              color: Colors.grey,
            )),
      ),
    );

  }


  Widget SaveCustomer(){
      return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20,horizontal: 80),
      child: Container(
        height: 45,
        child: RaisedButton(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15.0),
              side: BorderSide(color: KmainColor)),
          color: Colors.white,
          onPressed: saved==false?() async {
            if (CustomerName.text.isNotEmpty){
            Customer customer=Customer(
              CustomerName: CustomerName.text,
              address: Adress.text,
              mob1: Mobile1.text,
              mob2: Mobile2.text,
              Tele1: Tel1.text,
              tele2: Tel2.text
            );
              setState(() {
                saved=true;
              });
            await _postCustomerApi.PostCustomer(customer).then((succes){
                if (succes) {
                  setState(() {
                    saved=false;
                  });
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return CustomDialoge(
                          Anothercontext: context,
                          Message: 'تم الحفظ بنجاح',
                          Callback: () {
                            Navigator.of(context).pop();
                          },
                        );
                      });
                } else {
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return CustomDialoge(
                          Anothercontext: context,
                          Message: 'لم يتم الحفظ ',
                          Callback: () {
                            Navigator.of(context).pop();
                          },
                        );
                      });
                }
            } );


            }

            else {

              showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return CustomDialoge(
                            Anothercontext: context,
                            Message: 'من فضلك قم بادخال اسم العميل   ',
                            Callback: () {
                              Navigator.of(context).pop();
                            },
                          );
                        });
            }
          }:null,
          child: Text(
            'حفظ العميل',
            style: TextStyle(
                color: KmainColor,
                fontFamily: 'cocon',
                fontWeight: FontWeight.bold,
                fontSize: 20),
          ),
        ),
      ),
    );


  }
}
