import 'package:flutter/material.dart';
import 'package:mandoboct/General/Constants/LoadingDialog.dart';
import 'package:mandoboct/General/Utilities/utils.dart';
import 'package:mandoboct/general/Constants/LabelTextField.dart';
import 'package:mandoboct/general/Constants/MyColors.dart';
import 'package:mandoboct/general/Constants/MyDialog.dart';
import 'package:mandoboct/general/Constants/MyDropDown.dart';
import 'package:mandoboct/general/Constants/MyText.dart';
import 'package:mandoboct/general/Constants/MyToast.dart';
import 'package:mandoboct/General/Network/API/ProvidersApi.dart';
import 'package:mandoboct/General/Provider/CategoriesProvider.dart';
import 'package:mandoboct/General/Provider/MainProvider.dart';
import 'package:mandoboct/General/Provider/ServiceProvider.dart';
import 'package:provider/provider.dart';

class DesktopHome extends StatefulWidget {
  @override
  _DesktopHomeState createState() => _DesktopHomeState();
}

class _DesktopHomeState extends State<DesktopHome> {
  TextEditingController provName = TextEditingController();
  TextEditingController prodDesc = TextEditingController();
  TextEditingController provPhone = TextEditingController();
  TextEditingController provPhone2 = TextEditingController();
  TextEditingController social = TextEditingController();
  TextEditingController address = TextEditingController();
  TextEditingController lat = TextEditingController();
  TextEditingController long = TextEditingController();
  @override
  void dispose() {
    provName.dispose();
    prodDesc.dispose();
    provPhone.dispose();
    provPhone2.dispose();
    social.dispose();
    address.dispose();
    lat.dispose();
    long.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          title: Text("تسجيل مقدم خدمة"),
        ),
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                CustomDropDown(
                    items: context.read<CategoriesProvider>().categoriesNames,
                    hint: "اختر الفئة",
                    onChange: (value) async {
                      await context
                          .read<CategoriesProvider>()
                          .changeDropDownValue(value);
                      LoadingDialog(context).showDilaog();
                      Provider.of<ServiceProvider>(context, listen: false)
                          .getAllServices(Provider.of<CategoriesProvider>(
                                      context,
                                      listen: false)
                                  .categoryId ??
                              1);
                      Navigator.pop(context);
                    },
                    value:
                        Provider.of<CategoriesProvider>(context).categoryName),
                const SizedBox(height: 10),
                CustomDropDown(
                    items: context.read<ServiceProvider>().serNames,
                    hint: "اختر الخدمة",
                    onChange: (value) => context
                        .read<ServiceProvider>()
                        .changeDropDownValue(value),
                    value: Provider.of<ServiceProvider>(context).serviceName),
                LabelTextField(
                    controller: provName,
                    label: "اسم مزود الخدمة",
                    isPassword: false,
                    margin: const EdgeInsets.symmetric(vertical: 5.0)),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: prodDesc,
                        maxLines: 8,
                        decoration: InputDecoration(
                          fillColor: MyColors.white,
                          filled: true,
                          enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.grey, width: 1.5),
                              borderRadius: BorderRadius.circular(5)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5),
                              borderSide: BorderSide(
                                  color: MyColors.primary.withOpacity(.5),
                                  width: 2)),
                          hintText: "اكتب وصف المنتج هنا",
                          hintStyle: TextStyle(
                              fontFamily: "Almarai",
                              fontSize: 14,
                              color: Colors.black45),
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 14),
                          suffixIcon: Icon(Icons.description_rounded),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        children: [
                          LabelTextField(
                              controller: provPhone,
                              label: "رقم الهاتف",
                              isPassword: false,
                              margin:
                                  const EdgeInsets.symmetric(vertical: 5.0)),
                          LabelTextField(
                              controller: provPhone2,
                              label: "رقم الهاتف (اختياري)",
                              isPassword: false,
                              margin:
                                  const EdgeInsets.symmetric(vertical: 5.0)),
                          LabelTextField(
                              controller: social,
                              label: "رابط موقع التواصل الإجتماعي",
                              isPassword: false,
                              margin:
                                  const EdgeInsets.symmetric(vertical: 5.0)),
                        ],
                      ),
                    ),
                  ],
                ),
                LabelTextField(
                    controller: address,
                    label: "العنوان",
                    isPassword: false,
                    margin: const EdgeInsets.symmetric(vertical: 5.0)),
                Row(
                  children: [
                    Expanded(
                      child: LabelTextField(
                          controller: lat,
                          label: "Latitude",
                          isPassword: false,
                          margin: const EdgeInsets.all(5)),
                    ),
                    Expanded(
                      child: LabelTextField(
                          controller: long,
                          label: "Longitude",
                          isPassword: false,
                          margin: const EdgeInsets.all(5)),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: () => MyDialog(context).showMyDialog(),
                      child: MyText(
                        title: "إضافة عناصر",
                        color: MyColors.white,
                      ),
                      style: ElevatedButton.styleFrom(
                        fixedSize: Size(
                            screenSize.width * .4, screenSize.height * .06),
                        primary: MyColors.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    Consumer<ServiceProvider>(
                      builder: (ctx, serviceProvid, ch) {
                        // if (kIsWeb)
                        return ElevatedButton(
                          onPressed: () {
                            print(serviceProvid.serviceName);
                            if (serviceProvid.serviceName == null ||
                                provName.text == '') {
                              MyToast().showToast(
                                  "برجاء اضاقة الخدمة والمزود", Colors.green);
                            } else {
                              Utils.showSnackBar(
                                  "انتظر", Colors.yellowAccent, context);
                              ProviderApi()
                                  .addProvider(
                                name: provName.text,
                                disc: prodDesc.text,
                                phone: provPhone.text,
                                phone2: provPhone2.text,
                                address: address.text,
                                social: social.text,
                                lat: lat.text.isNotEmpty
                                    ? double.parse(lat.text)
                                    : context.read<MainProvider>().getLat,
                                long: long.text.isNotEmpty
                                    ? double.parse(long.text)
                                    : context.read<MainProvider>().getLong,
                                categoryId: Provider.of<CategoriesProvider>(
                                        context,
                                        listen: false)
                                    .categoryId!,
                                serviceId: Provider.of<ServiceProvider>(context,
                                        listen: false)
                                    .serviceId!,
                              )
                                  .then((value) {
                                if (value == "تمت الإضافة") {
                                  address.clear();
                                  prodDesc.clear();
                                  provName.clear();
                                  provPhone.clear();
                                  provPhone2.clear();
                                  social.clear();
                                  lat.clear();
                                  long.clear();

                                  Utils.showSnackBar(
                                      value, Colors.green, context);
                                } else {
                                  Utils.showSnackBar(
                                      value, Colors.red, context);
                                }
                              });
                            }
                          },
                          child: MyText(
                            title: "حفظ وتسجيل",
                            color: MyColors.white,
                          ),
                          style: ElevatedButton.styleFrom(
                            fixedSize: Size(
                                screenSize.width * .4, screenSize.height * .06),
                            primary: MyColors.primary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ));
  }
}
