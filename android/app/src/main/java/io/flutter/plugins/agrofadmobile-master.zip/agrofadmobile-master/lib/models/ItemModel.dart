
class Item {
  String ItemName;
  String UnitName;
  int ItemId;
  int UnitId;
  double AvailableQty;
  Item({
          this.ItemName,
          this.UnitName,
           this.UnitId,
          this.ItemId,
    this.AvailableQty

       });
  factory Item.FromJson(Map<String, dynamic> item) {
        return
         Item(
             ItemName: item['ItemName'],
             UnitName: item['UnitName'],
             ItemId:item['ItemID'],
              UnitId:item['UnitId'],
           AvailableQty: item['AvailableQty']
             );
  }
}
