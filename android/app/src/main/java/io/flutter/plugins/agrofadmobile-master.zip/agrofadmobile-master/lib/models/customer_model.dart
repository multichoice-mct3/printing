class Customer{
  int CustomerID;
  String CustomerName;
  String Tele1;
  String tele2;
  String mob1;
  String mob2;
  String address;
  double OpenBalDebit;
  double OpenBalCredit;
  Customer({this.CustomerID,
    this.CustomerName,
    this.address,
    this.mob1,
    this.mob2,
    this.Tele1,
    this.tele2,
    this.OpenBalCredit,
    this.OpenBalDebit
                });
  factory Customer.formjson(Map<String ,dynamic> customer){
    return Customer(
      CustomerID: customer['CustomerID'],
      CustomerName: customer['CustomerName']
                  );
                  }
  Map <String ,dynamic>ToJson(){
    return {
       'CustomerName':this.CustomerName,
      'address':this.address,
      'mob1':this.mob1,
      'Tele':this.Tele1,
      'mob2':this.mob2,
      'tele2':this.tele2,
      'OpenBalCredit':0,
      'OpenBalDebit':0
             };
              }

}

