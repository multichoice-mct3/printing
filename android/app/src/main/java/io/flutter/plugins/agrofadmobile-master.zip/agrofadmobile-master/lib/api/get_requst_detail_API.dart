import 'dart:convert';
import 'package:agrofad/models/AddOrderedSupply_model.dart';
import 'package:http/http.dart' as http;
import 'login_apis.dart';

class GetRequstDetailApi {
  LoginApi loginApi = new LoginApi();
  OrderedSupplyModel model;
  String BaseUrl = 'http://104.196.134.107/AfitAPI';
  Future<OrderedSupplyModel> GetRequstDetail(int OrderId) async {
    await loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var response = await http.get(
        "http://104.196.134.107/AfitAPI/api/RequestOrders/${OrderId}",
        headers: Headers);
    if (response.statusCode == 200) {
      print(response.statusCode.toString());
      print(response.body);
      final JsonBody = jsonDecode(response.body);
      print(JsonBody);
      return OrderedSupplyModel.GetRequstOrderDetail(JsonBody);
      print(model.RequestOrderID.toString());
      // model= ParseItems(response.body);

    } else {
      print(response.statusCode.toString());
      print(response.body);
    }
  }
}
