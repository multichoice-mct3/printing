import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mandoboct/General/Constants/LabelTextField.dart';
import 'package:mandoboct/General/Constants/MyDropDown.dart';
import 'package:mandoboct/General/Constants/MyElevatedBtn.dart';
import 'package:mandoboct/General/Models/ItemModel.dart';
import 'package:mandoboct/General/Models/StationModel.dart';
import 'package:mandoboct/General/Network/API/ItemsApi.dart';
import 'package:mandoboct/General/Network/API/MwaslatAPi.dart';
import 'package:mandoboct/General/Provider/MainProvider.dart';
import 'package:mandoboct/General/Utilities/SizeConfig.dart';
import 'package:mandoboct/General/Utilities/utils.dart';
import 'package:provider/provider.dart';
import 'MyColors.dart';
import 'MyText.dart';

class MyDialog {
  BuildContext ctx;
  TextEditingController _item = TextEditingController();
  TextEditingController _price = TextEditingController();
  MyDialog(this.ctx);
  show() {
    showDialog(
      context: ctx,
      builder: (context) => AlertDialog(
        content: Consumer<MainProvider>(
          builder: (context, items, child) => Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * .6,
            child: Column(
              children: [
                CustomDropDown(
                    items: items.providerNames,
                    onChange: (value) {
                      items.changeDropDownValue(value);
                      items.getTrafficLines();
                    },
                    hint: "اختر النشاط",
                    value: items.providerName),
                const SizedBox(height: 10),
                CustomDropDown(
                    items: items.trafficLinesNames,
                    onChange: (value) =>
                        items.changeTrafficDropDownValue(value),
                    hint: "اختر الموقف",
                    value: items.trafficLineName),
                SizedBox(height: 10),
                LabelTextField(
                  controller: _item,
                  label: "اسم المحطة",
                  isPassword: false,
                  margin: EdgeInsets.symmetric(horizontal: 10),
                ),
                Row(
                  children: [
                    Expanded(
                      child: LabelTextField(
                        controller: _price,
                        label: "سعر المحطة",
                        isPassword: false,
                        margin: EdgeInsets.symmetric(horizontal: 10),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        if (_item.text.isEmpty) {
                          Utils.showSnackBar(
                              "يجب تحديد اسم المحطة", Colors.red, context);
                        } else {
                          Utils.showSnackBar("انتظر", Colors.yellow, context);
                          StationModel _station = StationModel(
                              stationsName: _item.text,
                              stationsPrice: double.parse(_price.text),
                              trafficLinesId: items.trafficLineId,
                              trafficLinesName: items.providerName);
                          print(_station.toJson());
                          await StationsApi().addStation(_station).then(
                              (value) => Utils.showSnackBar(
                                  value, Colors.green, context));
                          // _item.clear();
                        }
                      },
                      child: MyText(
                        title: "إضافة",
                        color: MyColors.white,
                      ),
                      style: ElevatedButton.styleFrom(
                        primary: MyColors.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ],
                ),
                Expanded(
                    child: Container(
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Wrap(
                    alignment: WrapAlignment.start,
                    runAlignment: WrapAlignment.start,
                    children: List.generate(
                      items.itemsFromApi.length,
                      (index) => Container(
                        width: 100,
                        margin: const EdgeInsets.all(5),
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: MyColors.primary)),
                        child: Row(
                          children: [
                            Expanded(
                              child: MyText(
                                  title: items.itemsFromApi[index].itemName!,
                                  size: 14,
                                  overflow: TextOverflow.ellipsis),
                            ),
                            // InkWell(
                            //   onTap: () =>
                            //       items.deleteFromItems(items.items[index]),
                            //   child: Container(
                            //     padding: const EdgeInsets.symmetric(
                            //         horizontal: 10, vertical: 6),
                            //     decoration: BoxDecoration(
                            //         color: Colors.red, shape: BoxShape.circle),
                            //     child: Icon(
                            //       Icons.close,
                            //       color: Colors.white,
                            //       size: 15,
                            //     ),
                            //   ),
                            // ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ))
              ],
            ),
          ),
        ),
      ),
    );
  }

  showMyDialog() {
    showDialog(
      context: ctx,
      builder: (context) => AlertDialog(
        content: Consumer<MainProvider>(
          builder: (context, items, child) => Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * .6,
            child: Column(
              children: [
                CustomDropDown(
                    items: items.providerNames,
                    onChange: (value) => items.changeDropDownValue(value),
                    hint: "اختر النشاط",
                    value: items.providerName),
                SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: LabelTextField(
                        controller: _item,
                        label: "اسم العنصر",
                        isPassword: false,
                        margin: EdgeInsets.symmetric(horizontal: 10),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        if (_item.text.isEmpty) {
                          Utils.showSnackBar(
                              "يجب تحديد مقدم الخدمة", Colors.red, context);
                        } else {
                          Utils.showSnackBar("انتظر", Colors.green, context);
                          ItemModel item = ItemModel(
                              itemName: _item.text,
                              providesId: items.providerId,
                              providesName: items.providerName);
                          await ItemsApi().addItem(item).then((value) =>
                              Utils.showSnackBar(value, Colors.green, context));
                          _item.clear();
                        }
                      },
                      child: MyText(
                        title: "إضافة",
                        color: MyColors.white,
                      ),
                      style: ElevatedButton.styleFrom(
                        primary: MyColors.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ],
                ),
                Expanded(
                    child: Container(
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Wrap(
                    alignment: WrapAlignment.start,
                    runAlignment: WrapAlignment.start,
                    children: List.generate(
                      items.itemsFromApi.length,
                      (index) => Container(
                        width: 100,
                        margin: const EdgeInsets.all(5),
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(color: MyColors.primary)),
                        child: Row(
                          children: [
                            Expanded(
                              child: MyText(
                                  title: items.itemsFromApi[index].itemName!,
                                  size: 14,
                                  overflow: TextOverflow.ellipsis),
                            ),
                            // InkWell(
                            //   onTap: () =>
                            //       items.deleteFromItems(items.items[index]),
                            //   child: Container(
                            //     padding: const EdgeInsets.symmetric(
                            //         horizontal: 10, vertical: 6),
                            //     decoration: BoxDecoration(
                            //         color: Colors.red, shape: BoxShape.circle),
                            //     child: Icon(
                            //       Icons.close,
                            //       color: Colors.white,
                            //       size: 15,
                            //     ),
                            //   ),
                            // ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ))
              ],
            ),
          ),
        ),
      ),
    );
  }

  showConfirmDialog({required Function onTap}) {
    showDialog(
        context: ctx,
        builder: (context) => AlertDialog(
              content: Container(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    MyText(title: "يوجد مقدم خدمة بنفس الإسم !"),
                    SizedBox(height: 15),
                    MyText(title: "تأكيد الإضافة ؟"),
                    SizedBox(height: 15),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        MyElevatedBtn(
                            size: Size(SizeConfig.screenWidth! * .2,
                                SizeConfig.screenHeight! * .06),
                            onTap: () => Navigator.pop(context),
                            child: MyText(
                              title: "الغاء",
                              color: Colors.white,
                            )),
                        MyElevatedBtn(
                            size: Size(SizeConfig.screenWidth! * .2,
                                SizeConfig.screenHeight! * .06),
                            onTap: () async => await onTap(),
                            child: MyText(
                              title: "تأكيد",
                              color: Colors.white,
                            )),
                      ],
                    )
                  ],
                ),
              ),
            ));
  }
}
