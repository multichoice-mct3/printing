import 'package:agrofad/api/approved_refused-api.dart';
import 'package:agrofad/api/get_request_orders_api.dart';
import 'package:agrofad/api/get_requst_detail_API.dart';
import 'package:agrofad/custom_widgets/custom_dialoge.dart';
import 'package:agrofad/models/AddItem_model.dart';
import 'package:agrofad/models/AddOrderedSupply_model.dart';
import 'package:agrofad/provider_services/user_Detail_provider.dart';
import 'package:awesome_loader/awesome_loader.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;
import 'package:provider/provider.dart';
import '../constants.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';

import 'get_orders.dart';

class OrderSupplyDet extends StatefulWidget {
  static String id = 'OrderSupplyDet';
  final int OrderId;
  OrderSupplyDet({this.OrderId});
  @override
  _OrderSupplyDetState createState() => _OrderSupplyDetState();
}

class _OrderSupplyDetState extends State<OrderSupplyDet> {
  String UserType;
  bool done = false;

  bool Checked = false;

  GetRequstsApi _getRequstsApi = GetRequstsApi();
  GetRequstDetailApi _detailApi = GetRequstDetailApi();
  OrderedSupplyModel model;
  TextEditingController OrderNo = TextEditingController();
  TextEditingController OrderDate = TextEditingController();
  TextEditingController AgentName = TextEditingController();
  TextEditingController CustomerName = TextEditingController();

  Future<OrderedSupplyModel> getRequest() async {
    //  print( await _detailApi.GetRequstDetail(widget.OrderId));
    return await _detailApi.GetRequstDetail(widget.OrderId);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    () async {
      await _getRequstsApi.getUserDateail();
      UserType = _getRequstsApi.UserType;
      model = OrderedSupplyModel();
      model = await getRequest();
      OrderNo.text = model.RequestOrderID.toString();
      OrderDate.text = model.RequestOrderDate;
      AgentName.text = model.EmpName;
      CustomerName.text = model.CustomerName;
      setState(() {
        done = true;
      });
    }();
  }

  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    double ScreenHieght = MediaQuery.of(context).size.height;
    print(Provider.of<UserDetail>(context).GetUType);
    return SafeArea(
      child: Scaffold(
          backgroundColor: !done ? Colors.white : KmainColor,
          floatingActionButton:
              Provider.of<UserDetail>(context).GetUType == 'USER'
                  ? null
                  : buildSpeedDial(),
          body: !done
              ? Center(
                  child: Container(
                    height: 30,
                    width: 30,
                    child: AwesomeLoader(
                      loaderType: AwesomeLoader.AwesomeLoader3,
                      color: KmainColor,
                    ),
                  ),
                )
              : ListView(
                  children: [
                    Column(
                      //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        FirstContainer(ScreenWidth),
                        Container(
                            width: ScreenWidth,
                            height: ScreenHieght * .5,
                            color: KmainColor,
                            child: Column(
                              children: [
                                ItemsMainRow(),
                                Expanded(
                                  child: ListView.builder(
                                      itemCount: model.RequestOrderDet.length,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        return ItemsRecord(
                                            model.RequestOrderDet[index],
                                            index);
                                      }),
                                ),
                              ],
                            )),
                      ],
                    ),
                  ],
                )
          //:Center(child: CircularProgressIndicator()),
          ),
    );
  }

  Widget ItemsMainRow() {
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          textDirection: TextDirection.rtl,
          children: [
            Expanded(
              flex: 1,
              child: Container(
                decoration: BoxDecoration(
                    color: WhiteColor,
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(10),
                        bottomRight: Radius.circular(10))),
                child: Center(
                  child: Text(
                    'م',
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: KmainColor,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 3,
            ),
            Expanded(
              flex: 6,
              child: Container(
                color: OfWhiteColor,
                child: Padding(
                  padding: const EdgeInsets.only(right: 25),
                  child: Text(
                    'صنف ',
                    textAlign: TextAlign.end,
                    style: TextStyle(
                      color: KmainColor,
                      fontSize: 20,
                      fontFamily: 'cocon',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 3,
            ),
            Expanded(
              flex: 2,
              child: Container(
                //     width: MediaQuery.of(context).size.width*1/4,
                //  height: MediaQuery.of(context).size.height*4/100,
                color: OfWhiteColor,

                child: Align(
                  alignment: AlignmentDirectional.center,
                  child: Text(
                    'كمية ',
                    //   textDirection: TextDirection.rtl,
                    textAlign: TextAlign.end,
                    style: TextStyle(
                      color: KmainColor,
                      fontSize: 20,
                      fontFamily: 'cocon',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 3,
            ),
            Expanded(
              flex: 2,
              child: Container(
                //   width: MediaQuery.of(context).size.width*1/4,
                //  height: MediaQuery.of(context).size.height*4/100,

                decoration: BoxDecoration(
                    color: OfWhiteColor,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        bottomLeft: Radius.circular(10))),

                child: Align(
                  alignment: AlignmentDirectional.center,
                  child: Text(
                    'وحدة ',
                    textAlign: TextAlign.end,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      color: KmainColor,
                      fontSize: 20,
                      fontFamily: 'cocon',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ));
  }

  Widget ItemsRecord(AddItemModel item, int index) {
    model.RequestOrderDet[index].SerNo = index + 1;
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          children: [
            SizedBox(
              height: 3,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              textDirection: TextDirection.rtl,
              children: [
                Expanded(
                  flex: 1,
                  child: Container(
                    //   width: MediaQuery.of(context).size.width*1/2,
                    height: MediaQuery.of(context).size.height * 4 / 100,
                    decoration: BoxDecoration(
                        color: WhiteColor,
                        borderRadius: BorderRadius.only(
                            topRight: Radius.circular(10),
                            bottomRight: Radius.circular(10))),

                    child: Center(
                      child: Text(
                        item.SerNo.toString(),
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 3,
                ),
                Expanded(
                  flex: 6,
                  child: Container(
                    //   width: MediaQuery.of(context).size.width*1/2,
                    height: MediaQuery.of(context).size.height * 4 / 100,
                    color: WhiteColor,
                    padding: const EdgeInsets.only(right: 13),
                    child: Text(
                      item.ItemName,
                      overflow: TextOverflow.visible,
                      style: TextStyle(
                        color: KmainColor,
                        fontSize: 18,
                        fontFamily: 'cocon',
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 3,
                ),
                Expanded(
                  flex: 2,
                  child: Container(
                    //     width: MediaQuery.of(context).size.width*1/4,
                    height: MediaQuery.of(context).size.height * 4 / 100,
                    color: WhiteColor,
                    child: Align(
                      alignment: AlignmentDirectional.center,
                      child: Text(
                        item.qty.toString(),
                        textAlign: TextAlign.end,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18,
                          fontFamily: 'cocon',
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 3,
                ),
                Expanded(
                  flex: 2,
                  child: Container(
                    //   width: MediaQuery.of(context).size.width*1/4,
                    height: MediaQuery.of(context).size.height * 4 / 100,

                    decoration: BoxDecoration(
                        color: WhiteColor,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                        )),

                    child: Align(
                      alignment: AlignmentDirectional.center,
                      child: Text(
                        item.UnitName,
                        textAlign: TextAlign.end,
                        style: TextStyle(
                          color: KmainColor,
                          fontSize: 18,
                          fontFamily: 'cocon',
                        ),
                      ),
                    ),
                  ),
                ),
                // Expanded(
                //   flex: 1,
                //   child: InkWell(
                //     onTap: () {
                //       RemoveItem(index);
                //     },
                //     child: Container(
                //       //   width: MediaQuery.of(context).size.width*1/2,
                //       height: MediaQuery.of(context).size.height * 4 / 100,
                //       decoration: BoxDecoration(
                //           color: Colors.redAccent,
                //           borderRadius: BorderRadius.only(
                //               topLeft: Radius.circular(10),
                //               bottomLeft: Radius.circular(10)
                //           )
                //       ),
                //
                //       child: Center(
                //         child: Text(
                //           'X',
                //           textAlign: TextAlign.start,
                //           style: TextStyle(
                //             color: Colors.white,
                //             fontSize: 15,
                //             fontWeight: FontWeight.bold,
                //
                //           ),
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
              ],
            )
          ],
        ));
  }

  SpeedDial buildSpeedDial() {
    return SpeedDial(
      // child: Text('Admin',
      // style: TextStyle(
      //   fontFamily: 'cocon',
      //   fontSize: 18,
      //   color: KmainColor,
      //   fontWeight: FontWeight.bold
      // ),
      // ),
      animatedIcon: AnimatedIcons.menu_close,
      animatedIconTheme: IconThemeData(size: 40.0, color: KmainColor),
      backgroundColor: Colors.white,
      visible: true,
      curve: Curves.bounceInOut,
      children: [
        SpeedDialChild(
          child: Icon(
            Icons.done,
            color: Colors.white,
            size: 40,
            semanticLabel: 'اعتماد',
          ),
          backgroundColor: KmainColor,
          onTap: () async {
            SendStatusApi _send = SendStatusApi();
            Checked = await _send.SendApprovedorRefusedOrder(
                widget.OrderId, 'Approved');

            if (Checked) {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return CustomDialoge(
                      Anothercontext: context,
                      Message: 'تم الاعتماد بنجاح',
                      Callback: () {
                        Navigator.pushReplacementNamed(context, Orders.id);
                      },
                    );
                  });
            } else {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return CustomDialoge(
                      Anothercontext: context,
                      Message: 'لم يتم الاعتماد',
                      Callback: () {
                        Navigator.of(context).pop();
                      },
                    );
                  });
            }
          },
          label: 'اعتماد',
          labelStyle: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              fontFamily: 'cocon',
              color: Colors.white),
          labelBackgroundColor: Colors.black,
        ),
        SpeedDialChild(
          child: Icon(Icons.close, size: 40, color: Colors.white),
          backgroundColor: Colors.red,
          onTap: () async {
            SendStatusApi _send = SendStatusApi();
            Checked = await _send.SendApprovedorRefusedOrder(
                widget.OrderId, 'Refused');

            if (Checked) {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return CustomDialoge(
                      Anothercontext: context,
                      Message: 'تم رفض الطلب',
                      Callback: () {
                        Navigator.pushReplacementNamed(context, Orders.id);
                      },
                    );
                  });
            } else {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return CustomDialoge(
                      Anothercontext: context,
                      Message: 'لم يتم الرفض بنجاع ',
                      Callback: () {
                        Navigator.of(context).pop();
                      },
                    );
                  });
            }
          },
          label: 'رفض',
          labelStyle: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontSize: 18,
              fontFamily: 'cocon'),
          labelBackgroundColor: BlackColor,
        ),
      ],
    );
  }

  Widget FirstContainer(double ScreenWidth) {
    return Column(
      children: [
        Container(
          height: 40,
          width: ScreenWidth,
          color: OfWhiteColor,
          child: Padding(
            padding: const EdgeInsets.only(right: 25),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'تفاصيل امر التوريد',
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: KmainColor,
                    fontSize: 25,
                    fontFamily: 'cocon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 15, top: 3),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)),
                    color: Colors.amber,
                    onPressed: () async {
                      Navigator.pop(context);
                    },
                    child: Text(
                      'رجوع',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'cocon',
                          fontSize: 18),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: DateRow1(),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15),
          child: Row(
            //mainAxisAlignment: MainAxisAlignment.spaceBetween,
            textDirection: TextDirection.rtl,
            children: [
              Text(
                'العميل',
                style: TextStyle(
                    fontFamily: 'cocon', fontSize: 20, color: Colors.white),
              ),
              SizedBox(
                width: 15,
              ),
              Expanded(child: CustomTextField(CustomerName))
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: Row(
            //mainAxisAlignment: MainAxisAlignment.spaceBetween,
            textDirection: TextDirection.rtl,
            children: [
              Text(
                'المندوب',
                style: TextStyle(
                    fontFamily: 'cocon', fontSize: 20, color: Colors.white),
              ),
              SizedBox(
                width: 9,
              ),
              Expanded(child: CustomTextField(AgentName))
            ],
          ),
        ),
      ],
    );
  }

//////test
  Widget DateRow1() {
    return Row(
      //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      textDirection: TextDirection.rtl,
      children: [
        Expanded(
          flex: 2,
          child: Row(
            // mainAxisAlignment: MainAxisAlignment.center,
            textDirection: TextDirection.rtl,
            children: [
              Text(
                'مسلسل',
                style: TextStyle(
                    fontFamily: 'cocon', fontSize: 20, color: Colors.white),
              ),
              SizedBox(
                width: 5,
              ),
              Expanded(child: CustomTextField(OrderNo))
            ],
          ),
        ),
        SizedBox(
          width: 15,
        ),
        Expanded(
          flex: 4,
          child: Row(
            //mainAxisAlignment: MainAxisAlignment.spaceBetween,
            textDirection: TextDirection.rtl,
            children: [
              Text(
                'التاريخ',
                style: TextStyle(
                    fontFamily: 'cocon', fontSize: 20, color: Colors.white),
              ),
              SizedBox(
                width: 15,
              ),
              Expanded(child: CustomTextField(OrderDate))
            ],
          ),
        )
      ],
    );
  }

  Widget CustomTextField(TextEditingController controller) {
    return Container(
      height: 35,
      child: Center(
        child: TextField(
          //controller==CustomerName?TextAlign.start:controller==AgentName?TextAlign.start:
          textAlign: TextAlign.center,
          style: TextStyle(
              fontFamily: 'cocon',
              fontSize: 20,
              color: controller == CustomerName
                  ? KmainColor
                  : controller == AgentName
                      ? KmainColor
                      : Colors.black,
              fontWeight: FontWeight.bold),
          textDirection: TextDirection.rtl,
          controller: controller,
          enabled: false,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(vertical: 5),
            filled: true,
            fillColor: Colors.white,
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                  color: Colors.grey,
                )),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                  color: Colors.grey,
                )),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                  color: Colors.grey,
                )),
          ),
        ),
      ),
    );
  }
}
