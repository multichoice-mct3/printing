import 'package:elfares/genaral/models/AccountModel.dart';
import 'package:elfares/genaral/network/API/AccountsApi.dart';
import 'package:flutter/cupertino.dart';

class AccountsProvider extends ChangeNotifier {
  AccountsApi _api = AccountsApi();
  List<AccountModel> _accounts = [];
  List<String> _accountsNames = [];
  List<String> get accountsNames => _accountsNames;
  String? _accountId;
  String get accountId => _accountId!;
  String? accountName;
  Future<void> getAccount() async {
    _accounts = await _api.getAccountsByUser();
    fillNames();
    print(" ------------- ${_accounts.length}");
    notifyListeners();
  }

  fillNames() {
    for (var item in _accounts) {
      _accountsNames.add(item.accountName!);
    }
  }

  changeAccountName(String newValue) {
    accountName = newValue;
    getAccountsId(newValue);
    notifyListeners();
  }

  getAccountsId(String name) {
    int supId = _accounts.indexWhere((element) => element.accountId == name);
    _accountId = _accounts[supId].accountId;
  }
}
