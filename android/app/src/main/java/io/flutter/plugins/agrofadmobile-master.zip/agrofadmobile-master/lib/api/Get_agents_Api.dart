import 'dart:convert';
import 'package:agrofad/models/Agent_model.dart';

import 'login_apis.dart';


class GetAgentApi{
  LoginApi loginApi = new LoginApi();
  List <Agent>Agents=[];
  String BaseUrl = 'http://104.196.134.107/AfitAPI';

  get http => null;
  Future<List <Agent>> GetAgents() async {
    await loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var response = await http.get("http://104.196.134.107/AfitAPI/api/Agent",
        headers: Headers);
    if (response.statusCode == 200) {
      Agents= ParseItems(response.body);
      print (Agents[1].AgentName);

    } else {
      print(response.body);
    }
    return Agents;
  }
  //fn get the item list
  List<Agent> ParseItems(String responseBody) {
    final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();

    return parsedItems.map<Agent>((json) => Agent.FromJson(json)).toList();
  }

}