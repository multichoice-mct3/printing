part of "WidgetsImport.dart";

class Splash extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  String token = CachHelper.getData(key: "token") ?? "";
  @override
  void initState() {
    super.initState();
    
    Future.delayed(Duration(seconds: 3), () async {
      if (token != "") {
        await Utils().getData(context);
        MyRoute().navigateAndRemove(context: context, route: Home());
      } else {
        MyRoute().navigateAndRemove(context: context, route: LoginContent());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(color: MyColors.primary),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimationContainer(
              index: 1,
              distance: 100,
              vertical: false,
              child: Padding(
                padding: const EdgeInsets.all(30),
                child: Image.asset(
                  "assets/minicode_logo.png",
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
