import 'package:mandoboct/General/Models/ServiceModel.dart';

import '../Http.dart';

class ServicesApi {
  HttpMethods _httpMethods = HttpMethods();
  Future<List<ServiceModel>> getServicesfromApi(String url) async {
    List<ServiceModel> _services = [];
    var _data = await _httpMethods.getData(url: url);
    if (_data != null) {
      List<Map<String, dynamic>> _servicesJson =
          List<Map<String, dynamic>>.from(_data);
      _services = _servicesJson
          .map((service) => ServiceModel.fromJson(service))
          .toList();
    }
    return _services;
  }

  Future<List<ServiceModel>> getServicesByCategoryFromApi(
      int categoryId) async {
    List<ServiceModel> _services = await getServicesfromApi(
        "ServicesByCategories?CategoriesId=$categoryId");
    return _services;
  }

  Future<List<ServiceModel>> getServicesByParentFromApi(int parentId) async {
    List<ServiceModel> _services = await getServicesfromApi(
        "ServicesByServicesParant?ServicesParantId=$parentId");
    return _services;
  }

  Future<List<ServiceModel>> getAllServicesFromApi() async {
    List<ServiceModel> _services = await getServicesfromApi("Services");
    return _services;
  }
}
