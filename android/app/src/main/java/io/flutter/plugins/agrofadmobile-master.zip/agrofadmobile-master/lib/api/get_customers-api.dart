import 'dart:convert';
import 'package:agrofad/models/customer_model.dart';
import 'package:http/http.dart' as http;

import 'login_apis.dart';

class GetCustomersApi {

  LoginApi loginApi = new LoginApi();
  List <Customer>Customers=[];
  String BaseUrl = 'http://104.196.134.107/AfitAPI';
  Future<List <Customer>> GetCustomers() async {
    await loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var response = await http.get("http://104.196.134.107/AfitAPI/api/Customer",
        headers: Headers);
    if (response.statusCode == 200) {
      Customers= ParseItems(response.body);
    } else {
      print(response.body);
    }
    return Customers;
  }
  //fn get the item list
  List<Customer> ParseItems(String responseBody) {
    final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();

    return parsedItems.map<Customer>((json) => Customer.formjson(json)).toList();
  }

}
