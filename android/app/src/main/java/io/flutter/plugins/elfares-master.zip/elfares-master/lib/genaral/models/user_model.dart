import 'package:json_annotation/json_annotation.dart';
part 'user_model.g.dart';

@JsonSerializable()
class UserModel {
  @JsonKey(name: 'UserId')
  final int? userId;
  @JsonKey(name: 'UserName')
  final String? userName;
  @JsonKey(name: 'EmpID')
  final int? empId;
  @JsonKey(name: 'UserType')
  final String? userType;
  @JsonKey(name: 'EnterpriseId')
  final int? enterpriseId;

  const UserModel({
    this.userId,
    this.userName,
    this.empId,
    this.userType,
    this.enterpriseId,
  });
  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);
  Map<String, dynamic> toJson() => _$UserModelToJson(this);
}
