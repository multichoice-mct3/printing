import 'package:LocarionWallet/Constants/IconTextFiled.dart';
import 'package:LocarionWallet/Constants/MyText.dart';
import 'package:LocarionWallet/Constants/someData.dart';
import 'package:LocarionWallet/Public/Provider/LocationProvider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SearchScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // context.read<LocationProvider>().getUserLocation();
    // context.read<LocationProvider>().getLocations();
    // print("object ${context.read<LocationProvider>().locations.length}");
    return Consumer<LocationProvider>(
      builder: (ctx, locations, child) {
        // print("locations.locations.length ${locations.locations.length}");
        return RefreshIndicator(
          onRefresh: () => locations.getLocations(),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: IconTextFiled(
                  label: tr("search"),
                  isPassword: false,
                  icon: Icon(Icons.search),
                  onChange: (value) => locations.searchList(value),
                ),
              ),
              Expanded(
                child: ListView.separated(
                  physics: BouncingScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: locations.filterdLocations.length,
                  separatorBuilder: (BuildContext context, int index) {
                    return Divider(
                      color: Colors.grey[400],
                      indent: 15,
                      thickness: 2,
                      endIndent: 0,
                    );
                  },
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      onTap: () => MapUtils.launchMapsUrl(
                          locations.getLat,
                          locations.getLong,
                          locations.filterdLocations[index].mapLatitude,
                          locations.filterdLocations[index].mapLongitude),
                      child: Container(
                        margin: EdgeInsets.all(10),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Icon(Icons.location_pin),
                                MyText(
                                  title: locations
                                      .filterdLocations[index].locationName,
                                ),
                              ],
                            ),
                            SizedBox(height: 15),
                            Row(
                              children: [
                                Icon(Icons.description_rounded),
                                MyText(
                                  title: locations.filterdLocations[index]
                                      .locationDescription,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
