import 'dart:ui';

class MyColors {
  static Color secondary = Color(0xff9CC0DB);
  static Color primary = Color(0xff046CB6);
  static Color bg = Color(0xffEEF2F4);
  static Color grey = Color(0xffDBE2E8);
  static Color pink = Color(0xffE2E2F3);
  static Color blackOpacity = Color(0xff313135);
  static Color white = Color(0xffEEF2F4);
  static Color med = Color(0xff97a2c0);
  static Color dark = Color(0xff7a87ae);

  static setColors({Color? primaryColor, Color? secondaryColor}) {
    primary = primaryColor!;
    secondary = secondaryColor!;
  }
}
