import 'package:elfares/genaral/models/BillItemModel.dart';
import 'package:flutter/material.dart';

class SellingInvsProvider extends ChangeNotifier {
  String? paymentType;
  double? discount;
  double total = 0;
  double afterDiscount = 0;
  changePaymentMethod(String value) {
    paymentType = value;
    notifyListeners();
  }

  count(BillItemModel item) {
    total = total + item.tot!;

    notifyListeners();
  }
}
