class AgentVisitRouteModel {
  int AVRId;
  String AVRDate;
  int EmpId;
  String EmpName;
  int CustomerId;
  String CustomerName;
  int AVCId;
  String AVCName;
  int AVRStatus;
  String ManualCauseNote;
  String ManualResultNote;
  AgentVisitRouteModel(
      {
    this.AVRId,
    this.AVRDate,
    this.EmpId,
    this.CustomerId,
    this.CustomerName,
    this.AVCId,
    this.AVCName,
    this.ManualCauseNote,
    this.ManualResultNote,
       this.EmpName,
       this.AVRStatus
     }
      );
  Map<String,dynamic>ToJson(){
    return {
      'AVRDate':this.AVRDate,
      'EmpId':this.EmpId,
      'CustomerId':this.CustomerId,
      'CustomerName':this.CustomerName,
      'AVCId':this.AVCId,
      'AVCName':this.AVCName,
      'ManualCauseNote':this.ManualCauseNote
    };
    }
  factory AgentVisitRouteModel.fromJson(Map<String,dynamic> JsonObject ){
    String FormatedDate= (JsonObject['AVRDate']).substring(0,10);
    return AgentVisitRouteModel(
      EmpId: JsonObject['EmpId'],
      EmpName: JsonObject['EmpName'],
      CustomerId:JsonObject ['CustomerId'],
      CustomerName: JsonObject['CustomerName'],
      AVRDate: FormatedDate,
      AVCId: JsonObject['AVCId'],
      ManualCauseNote: JsonObject['ManualCauseNote'],
      AVCName: JsonObject['AVCName'],
      AVRId:JsonObject['AVRId'] ,
    );
    }
  factory AgentVisitRouteModel.CompletedVisitfromJson(Map<String,dynamic> JsonObject ){
    String FormatedDate= (JsonObject['AVRDate']).substring(0,10);
    return AgentVisitRouteModel(
      EmpId: JsonObject['EmpId'],
      EmpName: JsonObject['EmpName'],
      CustomerId:JsonObject ['CustomerId'],
      CustomerName: JsonObject['CustomerName'],
      AVRDate: FormatedDate,
      AVCId: JsonObject['AVCId'],
      ManualCauseNote: JsonObject['ManualCauseNote'],
      AVCName: JsonObject['AVCName'],
      AVRId:JsonObject['AVRId'] ,
      AVRStatus: JsonObject['AVRStatus'],
        ManualResultNote: JsonObject['ManualResultNote']
                            );
                            }
}

