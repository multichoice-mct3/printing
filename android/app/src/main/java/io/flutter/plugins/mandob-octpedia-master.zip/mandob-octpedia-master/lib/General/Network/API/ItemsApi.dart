import 'dart:convert';

import 'package:mandoboct/General/Models/ItemModel.dart';

import '../Http.dart';

class ItemsApi {
  HttpMethods _http = HttpMethods();
  Future<List<ItemModel>> getItemsFromApi(int providerId) async {
    List<ItemModel>? items;
    var _data =
        await _http.getData(url: "ItemsByProvides?ProvidesId=$providerId");
    if (_data != null) {
      List<Map<String, dynamic>> _itemsJson =
          List<Map<String, dynamic>>.from(_data);
      items = _itemsJson.map((item) => ItemModel.fromJson(item)).toList();
      return items;
    }

    return items!;
  }

  Future<List<ItemModel>> getAllItemsromApi() async {
    List<ItemModel>? items;
    var _data = await _http.getData(url: "Items");
    if (_data != null) {
      List<Map<String, dynamic>> _itemsJson =
          List<Map<String, dynamic>>.from(_data);

      items = _itemsJson.map((item) => ItemModel.fromJson(item)).toList();
      return items;
    }

    return items!;
  }

  Future<String> addItem(ItemModel item) async {
    String result = "";
    print(json.encode(item.toJson()));
    await _http
        .postData(
          url: "Items",
          body: json.encode(item.toJson()),
        )
        .then((value) => value = result);
    return result;
  }
}
