import 'package:elfares/genaral/providers/sellingInvsProvider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:elfares/genaral/providers/WidgetsProvider.dart';
import './../Constants/MyColors.dart';
import './../providers/AuthProvider.dart';
import '../providers/CustomerProvider.dart';
import '../providers/StoresProvider.dart';
import '../providers/SuppliersProvider.dart';
import './../providers/ItemsProvider.dart';
import './../providers/StoresProvider.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

class MainData {
  static ThemeData defaultThem = ThemeData(
    scaffoldBackgroundColor: MyColors.bg,
    primarySwatch: Colors.grey,
    textSelectionTheme: TextSelectionThemeData(cursorColor: MyColors.primary),
    focusColor: MyColors.primary,
    primaryColor: MyColors.primary,
    platform: TargetPlatform.android,
    fontFamily: GoogleFonts.cairo().fontFamily,
    textTheme: TextTheme(subtitle1: GoogleFonts.cairo(fontSize: 14)),
    pageTransitionsTheme: PageTransitionsTheme(
        builders: {TargetPlatform.android: CupertinoPageTransitionsBuilder()}),
  );

  static List<SingleChildWidget> providers(BuildContext context) => [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(create: (context) => CustomersProvider()),
        ChangeNotifierProvider(create: (context) => StoresProvider()),
        ChangeNotifierProvider(create: (context) => SuppliersProvider()),
        ChangeNotifierProvider(create: (context) => ItemsProvider()),
        ChangeNotifierProvider(create: (context) => WidgetProvider()),
        ChangeNotifierProvider(create: (context) => SellingInvsProvider())
      ];
}
