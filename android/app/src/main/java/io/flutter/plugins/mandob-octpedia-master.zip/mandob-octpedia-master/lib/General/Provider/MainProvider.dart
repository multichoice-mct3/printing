import 'package:flutter/cupertino.dart';
import 'package:location/location.dart';
import 'package:mandoboct/General/Models/ItemModel.dart';
import 'package:mandoboct/General/Models/ProviderModel.dart';
import 'package:mandoboct/General/Network/API/ItemsApi.dart';
import 'package:mandoboct/General/Network/API/ProvidersApi.dart';
import 'package:mandoboct/General/Models/TrafficLinesModel.dart';
import 'package:mandoboct/General/Network/API/MwaslatAPi.dart';

class MainProvider extends ChangeNotifier {
  /////get current Location
  double _lat = 0.0;
  double _long = 0.0;
  double get getLat => _lat;
  double get getLong => _long;
  getUserLocation() async {
    Location location = new Location();
    bool _serviceEnabled;
    PermissionStatus _permissionGranted;
    LocationData _currentLocation;
    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }
    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
    _currentLocation = await location.getLocation();
    _lat = _currentLocation.latitude!;
    _long = _currentLocation.longitude!;
  }

  String? _providerName;
  String? get providerName => _providerName;

  changeDropDownValue(String value) {
    _providerName = value;
    getProviderId(value);
    print(providerId);
    print("_providerName $_providerName");
    getItems();
    print(_providerId);
    notifyListeners();
  }

  List<String> _items = [];
  List<String> get items => _items;
  addToItems(String item) {
    _items.add(item);
    notifyListeners();
  }

  deleteFromItems(String item) {
    _items.remove(item);
    notifyListeners();
  }

  ProviderApi _providersFromApi = ProviderApi();
  List<ProviderModel> _providers = [];
  List<ProviderModel> get providers => _providers;
  List<String> _providersNames = [];
  List<String> get providerNames => _providersNames;
  int? _providerId;
  int? get providerId => _providerId;
  getProviders(int serviceId) async {
    _providers = await _providersFromApi.getProvidersFromApi(serviceId);
    print(_providers.length);
    fillNames();
    notifyListeners();
  }

  fillNames() {
    for (var provider in _providers) {
      _providersNames.add(provider.providesName!);
    }
  }

  getProviderId(String name) {
    int itemId =
        _providers.indexWhere((element) => element.providesName == name);
    _providerId = _providers[itemId].providesId;
  }

  List<ItemModel> _itemsFromApi = [];
  List<ItemModel> get itemsFromApi => _itemsFromApi;
  Future<void> getItems() async {
    _itemsFromApi = await ItemsApi().getAllItemsromApi();
    notifyListeners();
  }

  Future<void> addItem(ItemModel item) async {
    await ItemsApi().addItem(item);
    notifyListeners();
  }

  //// Traffic Lines

  StationsApi _stationsApi = StationsApi();
  List<TrafficLinesModel> _trafficLines = [];
  List<TrafficLinesModel> get trafficLines => _trafficLines;
  List<String> _trafficLinesNames = [];
  List<String> get trafficLinesNames => _trafficLinesNames;
  String? trafficLineName;
  int? _trafficLineId;
  int? get trafficLineId => _trafficLineId;
  getTrafficLines() async {
    _trafficLines = await _stationsApi.getTrafficLinesFromApi(_providerId!);
    print(_providers.length);
    fillTrafficNames();
    notifyListeners();
  }

  fillTrafficNames() {
    for (var trafficLine in _trafficLines) {
      _trafficLinesNames.add(trafficLine.trafficLinesName!);
    }
  }

  getTrafficLineId(String name) {
    int index =
        _trafficLines.indexWhere((element) => element.trafficLinesName == name);
    _trafficLineId = _trafficLines[index].trafficLinesId;
  }

  changeTrafficDropDownValue(String value) {
    trafficLineName = value;
    getTrafficLineId(value);
    print(_providerId);
    notifyListeners();
  }

  bool isExist = false;
  checkProviderExistance(String name) {
    print(isExist);
    var pros =
        _providers.where((element) => element.providesName == name).toList();
    switch (pros.length) {
      case 0:
        isExist = false;
        break;
      default:
        isExist = false;
    }
    print("pros.length ${pros.length}");
    print(isExist);
    notifyListeners();
  }
}
