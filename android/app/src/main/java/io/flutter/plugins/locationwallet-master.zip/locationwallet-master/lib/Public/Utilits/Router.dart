import 'package:LocarionWallet/Home.dart';
import 'package:LocarionWallet/Public/Screens/LocationScreen.dart';
import 'package:LocarionWallet/Public/Screens/LoginScreen.dart';
import 'package:LocarionWallet/Public/Screens/Regestration.dart';
import 'package:LocarionWallet/Public/Screens/Splash.dart';
import 'package:LocarionWallet/Public/Screens/savedPlaces.dart';
import 'package:auto_route/auto_route.dart';
import 'package:auto_route/auto_route_annotations.dart';

@MaterialAutoRouter(
  routes: <AutoRoute>[
    //general routes
    MaterialRoute(page: Splash, initial: true),
    CustomRoute(
        page: UserLogin,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade),
    CustomRoute(
        page: Registeration,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade),
    CustomRoute(
        page: Home, transitionsBuilder: TransitionsBuilders.slideRightWithFade),
    CustomRoute(
        page: SavedPlaces,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade),
    CustomRoute(
        page: LocationDetails,
        transitionsBuilder: TransitionsBuilders.slideRightWithFade),
  ],
  
)
class $AppRouter {}
