import 'package:json_annotation/json_annotation.dart';
part 'BillItemModel.g.dart';

@JsonSerializable()
class BillItemModel {
  @JsonKey(name: 'ItemName')
  final String? itemName;
  @JsonKey(name: 'ItemId')
  final int? itemId;
  @JsonKey(name: 'UnitId')
  final int? unitId;
  @JsonKey(name: 'UnitName')
  final String? unitName;
  @JsonKey(name: 'Qty')
  final double? qty;
  @JsonKey(name: 'price')
  final double? price;
  @JsonKey(name: 'Tot')
  final double? tot;

  BillItemModel({
    this.itemName,
    this.itemId,
    this.unitName,
    this.qty,
    this.price,
    this.tot,
    this.unitId,
  });
  factory BillItemModel.fromJson(Map<String, dynamic> json) =>
      _$BillItemModelFromJson(json);
  Map<String, dynamic> toJson() => _$BillItemModelToJson(this);
}
