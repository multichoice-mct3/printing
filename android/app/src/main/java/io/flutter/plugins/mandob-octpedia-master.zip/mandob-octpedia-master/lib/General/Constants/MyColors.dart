import 'dart:ui';

import 'package:flutter/material.dart';

class MyColors {
  static Color primary = Color(0xff7C2EF1);
  static Color secondary = Color(0xffF0AA2E);
  static Color bg = Color(0xffFBFBFF);
  static Color grey = Color(0xff787B8A);
  static Color greyWhite = Color(0xffCACDD8);
  static Color blackOpacity = Color(0xff313135);
  static Color white = Color(0xfff5f5f5);

  static setColors({Color? primaryColor, Color? secondaryColor}) {
    primary = primaryColor!;
    secondary = secondaryColor!;
  }
}
