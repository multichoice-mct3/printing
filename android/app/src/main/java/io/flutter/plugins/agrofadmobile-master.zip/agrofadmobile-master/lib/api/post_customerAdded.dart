import 'dart:convert';
import 'package:agrofad/models/AddOrderedSupply_model.dart';
import 'package:agrofad/models/customer_model.dart';
import 'package:http/http.dart' as http;
import 'login_apis.dart';


class PostCustomerApi {
  LoginApi loginApi = new LoginApi();
  String BaseUrl = 'http://104.196.134.107/AfitAPI/api';
  bool Posted;
  Future<bool> PostCustomer(Customer customer) async {
    Map<String, dynamic> CustomerDet = customer.ToJson();
    String CustomerJsonData = jsonEncode(CustomerDet);
    print(CustomerJsonData);
    await loginApi.getAccessToken();
    print('${loginApi.token}');
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
                                 };
    var Response = await http.post(
        'http://104.196.134.107/AfitAPI/api/Customers',
        body: CustomerJsonData,
        headers: Headers);
    if (Response.statusCode == 201 ||Response.statusCode == 200  ) {
      print(Response.statusCode);
      var PostResult = jsonDecode(Response.body);
      Posted = true;
      print(PostResult);
    } else {
      print(Response.statusCode);
      var PostResult = jsonDecode(Response.body);
      Posted = false;
     // print(PostResult);
    }
    return Posted;
  }
}
