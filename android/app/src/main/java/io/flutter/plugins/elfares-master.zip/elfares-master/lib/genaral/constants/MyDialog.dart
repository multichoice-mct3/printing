import 'package:flutter/material.dart';
// import '../../genaral/widgets/TransferDetailsdialog.dart';
// import '../../genaral/widgets/addItemDialog.dart';

class MyDialog {
  BuildContext context;
  MyDialog(this.context);
  showAddItemsDialouge() {
    // showDialog(
    //     context: context,
    //     builder: (context) => AlertDialog(content: AddItemsDialog()));
  }

  showTransferDetailsDialouge() {
    // showDialog(
    //     context: context,
    //     builder: (context) => AlertDialog(content: TransferDetailsDialog()));
  }
}
