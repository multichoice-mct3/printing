import 'dart:convert';
import 'package:LocarionWallet/Constants/GlobalState.dart';
import 'package:LocarionWallet/Constants/Http.dart';
import 'package:LocarionWallet/Models/LocationModel.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:LocarionWallet/Public/resources/dio_helper/DioImports.dart';
import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';

import 'package:flutter/material.dart';

class GeneralHttpMethods {
  DioHelper _helper = DioHelper();
  Future login(String phone, String pass) async {
    bool userAuth = false;
    var body = {"username": "$phone", "password": "$pass"};

    var response = await _helper.post(
      "Authenticate/login",
      body,
    );

    if (response['token'] != null) {
      GlobalState.instance.set('token', response['token']);
      ExtendedNavigator.root.pushAndRemoveUntil(Routes.home, (route) => false);
    }

    return userAuth;
  }

  Future<String> register(String phone, String pass, String email) async {
    String registerationStatus;
    var body = {
      "username": "$phone",
      "password": "$pass",
      "email": "$email",
    };

    var response = await _helper.post(
      "Authenticate/register",
      body,
    );
    var result;
    result = jsonDecode(response.body);
    String msg = result["message"];
    if (response.statusCode == 200) {
      if (result == null) {
        registerationStatus = tr("smthWentWrong");
        print("null result");
      } else if (msg == "User created successfully!") {
        registerationStatus = tr("registerSuccess");
        ExtendedNavigator.root.push(Routes.userLogin);
        login(phone, pass);
        print(msg);
        print("result $result");
      } else if (msg == "User already exists!") {
        registerationStatus = tr("userExists");
        print(msg);
        print("result $result");
      }
    } else {
      print("bad request ${response.statusCode} in Register");
      if (msg == "User already exists!") {
        registerationStatus = tr("userExists");
        print(msg);
        print("result $result");
      }
      print(response.body);
    }

    return registerationStatus;
  }

  Future<List<LocationModel>> getLocations() async {
    try {
      var _data = await _helper.get("LocationWallets/LocationWalletsByUser");
      if (_data != null) {
        List<Map<String, dynamic>> _locationsJson =
            List<Map<String, dynamic>>.from(_data);
        List<LocationModel> locations = _locationsJson
            .map((location) => LocationModel.fromJson(location))
            .toList();

        return locations;
      }
    } on Exception catch (locations) {
      print("get Locations exception $locations");
    }
    return [];
  }

  Future<bool> addLocation({
    @required String locationName,
    @required String locationDescription,
    @required double mapLatitude,
    @required double mapLongitude,
  }) async {
    bool added = false;
    try {
      var _data = await _helper.post("LocationWallets", {
        "userId": "e930a25a-c041-41e0-9de0-4886dc42c41c",
        "mapLatitude": mapLatitude,
        "mapLongitude": mapLongitude,
        "locationName": locationName,
        "locationDescription": locationDescription
      });
      if (_data != null) {
        added = true;
      } else {
        added = false;
      }

      return added;
    } on Exception catch (addLocationException) {
      print("addLocationException $addLocationException");
    }
    return added;
  }

  Future<bool> deleteLocation(locationWalletId) async {
    bool deleted = false;
    try {
      var _data =
          await HttpMethods().deleteData(locationWalletId: locationWalletId);
      if (_data == true) {
        deleted = true;
      } else {
        deleted = false;
      }

      return deleted;
    } on Exception catch (delLocationException) {
      print("delLocationException $delLocationException");
    }
    return deleted;
  }

  Future<bool> editLocation(LocationModel location) async {
    bool edited = false;
    try {
      print(location.toJson());
      var _data = await HttpMethods().putData(
          url: "LocationWallets/${location.locationWalletId}",
          body: jsonEncode(location.toJson()));
      if (_data != null) {
        print(_data);
        edited = true;
      } else {
        edited = false;
        print(tr("smthWentWrong"));
      }
    } on Exception catch (editingException) {
      print("editingException $editingException");
    }
    return edited;
  }

  // Future<List<LocationModel>> getCachLocations() async {
  //   try {
  //     // var _data = await HttpMethods()
  //     //     .getData(url: "LocationWallets/LocationWalletsByUser");
  //     String fileName = "pathString.json";
  //     var dir = await getTemporaryDirectory();
  //     File file = File(dir.path + "/" + fileName);
  //     if (file.existsSync()) {
  //       print("read from cach");

  //       ///read from cach
  //       final _data = file.readAsStringSync();
  //       final res = jsonDecode(_data);
  //       List<Map<String, dynamic>> _locationsJson =
  //           List<Map<String, dynamic>>.from(res);
  //       List<LocationModel> locations = _locationsJson
  //           .map((location) => LocationModel.fromJson(location))
  //           .toList();
  //       return locations;
  //     } else {
  //       print("Fetching from network");

  //       ///Fetching from network
  //       var _data = await HttpMethods()
  //           .getData(url: "LocationWallets/LocationWalletsByUser");
  //       if (_data != null) {
  //         // save to json cach
  //         String _cachData = jsonEncode(_data);
  //         file.writeAsStringSync(_cachData, flush: true, mode: FileMode.write);
  //         List<Map<String, dynamic>> _locationsJson =
  //             List<Map<String, dynamic>>.from(_data);
  //         List<LocationModel> locations = _locationsJson
  //             .map((location) => LocationModel.fromJson(location))
  //             .toList();

  //         return locations;
  //       }
  //     }

  //     // if (_data != null) {
  //     //   List<Map<String, dynamic>> _locationsJson =
  //     //       List<Map<String, dynamic>>.from(_data);
  //     //   List<LocationModel> locations = _locationsJson
  //     //       .map((location) => LocationModel.fromJson(location))
  //     //       .toList();

  //     //   return locations;
  //     // }
  //   } on Exception catch (locations) {
  //     print("get Locations exception $locations");
  //   }
  // }
}
// {
//   locationWalletId: 13,
//  userName: 01156631969,
//   userPhoneNumber: ,
//    mapLatitude: 30.05273439381082,
//     mapLongitude: 31.200750293020146,
//      locationName: "فرغلى",
//  locationDescription: "بتاع عصير"
//  }
