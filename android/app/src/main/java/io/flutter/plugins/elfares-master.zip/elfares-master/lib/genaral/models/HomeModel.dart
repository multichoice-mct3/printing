class HomeModel {
  final String name, icon;
  final Function onTap;
  const HomeModel(this.name, this.icon, this.onTap);
}
