part of "HomeImports.dart";

// ignore: must_be_immutable
class ItemsMainScreen extends StatelessWidget {
  ItemsMainScreen(
      {Key? key,
      required this.content,
      required this.title,
      this.onTap,
      this.fabExist = false,
      this.afterDiscount = 0,
      this.total = 0,
      this.showTotal = false})
      : super(key: key);
  final String title;
  final Widget content;
  bool showTotal;
  final VoidCallback? onTap;
  bool fabExist;
  final double total;
  double afterDiscount;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColors.primary,
      floatingActionButton: fabExist
          ? FloatingActionButton(
              onPressed: () => onTap!(),
              backgroundColor: MyColors.white,
              child: Icon(
                Icons.save,
                color: MyColors.primary,
              ),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      appBar: DefaultAppBar(
        title: "$title",
        color: MyColors.white,
      ),
      body: SafeArea(
          minimum: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          child: content),
      bottomSheet: showTotal
          ? Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                  color: MyColors.primary,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10),
                  )),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      MyText(
                        title: "اجمالي الفاتورة :",
                        size: 12,
                        color: MyColors.white,
                      ),
                      const SizedBox(width: 10),
                      MyText(
                        title: "$total",
                        size: 12,
                        color: MyColors.white,
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      MyText(
                        title: "بعد الخصم :",
                        size: 12,
                        color: MyColors.white,
                      ),
                      const SizedBox(width: 10),
                      MyText(
                        title: "${(total - afterDiscount)}",
                        size: 12,
                        color: MyColors.white,
                      ),
                    ],
                  ),
                ],
              ),
            )
          : const SizedBox(),
    );
  }
}
