import 'package:elfares/genaral/constants/MyColors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class NotesTextField extends StatelessWidget {
  const NotesTextField({
    required this.notes,
    this.enabled = false,
  });

  final TextEditingController notes;
  final bool enabled;
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: notes,
      maxLines: 7,
      enabled: enabled,
      decoration: InputDecoration(
        fillColor: MyColors.white,
        filled: true,
        labelStyle: GoogleFonts.cairo(fontSize: 14),
        enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey, width: 1.5),
            borderRadius: BorderRadius.circular(5)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide:
                BorderSide(color: MyColors.primary.withOpacity(.5), width: 2)),
        hintText: "اكتب ملاحظاتك هنا",
        hintStyle: GoogleFonts.cairo(fontSize: 14),
        contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 14),
        suffixIcon: Icon(Icons.description_rounded),
      ),
    );
  }
}
