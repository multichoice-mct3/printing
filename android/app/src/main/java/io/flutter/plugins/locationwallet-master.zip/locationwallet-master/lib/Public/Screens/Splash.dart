import 'package:LocarionWallet/Constants/AnimationContainer.dart';
import 'package:LocarionWallet/Constants/MyColors.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';

class Splash extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();

    Future.delayed(Duration(seconds: 3), () async {
      ExtendedNavigator.root.push(Routes.home);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: MyColors.primary,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimationContainer(
              distance: MediaQuery.of(context).size.width * .5,
              index: 0,
              duration: Duration(seconds: 2),
              vertical: true,
              child: Image(
                width: 250,
                height: MediaQuery.of(context).size.width,
                image: AssetImage('assets/images/splash.png'),
                fit: BoxFit.contain,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
