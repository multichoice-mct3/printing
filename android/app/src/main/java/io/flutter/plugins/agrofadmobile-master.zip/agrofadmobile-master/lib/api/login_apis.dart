import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';


class LoginApi {
  String BaseUrl = 'http://104.196.134.107/AfitAPI';
  String token;

  Future<bool> login(String userName, String pass) async {
    await getAccessToken();
    print(token);
    bool UserAuth = false;
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer$token',
    };
    var response = await http.get(
        "http://104.196.134.107/AfitAPI/api/user"+"?userName="+"$userName"+"&PSWRD="+pass,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': 'Bearer $token',
        }

);
    if (response.statusCode == 200) {
      var result=jsonDecode(response.body);
         if (result.length==0){
           UserAuth=false;
         }
         else {
           await saveUserData(result);
           print(result[0]);
           UserAuth=true;
         }
    } else {
      print(response.body);
    }
    return UserAuth;
  }

  Future<bool> confirmCode(String CompanyCode) async {
    bool Auth = false;
    Map BodyData = {
      "username": CompanyCode,
      "password": CompanyCode,
      "grant_type": "password"
    };
    var response = await http.post(
      "$BaseUrl/token",
      body: BodyData,
    );

    if (response.statusCode == 200) {
      var result = json.decode(response.body);
      saveAccessToken(result["access_token"]);
      Auth = true;
    } else {
      print(response.body);
    }
    return Auth;
  }

  Future<void> saveAccessToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString("accessToken", token);
  }

  Future<void> getAccessToken() async {
    final prefs = await SharedPreferences.getInstance();
    token = prefs.getString("accessToken");
  }

  Future<void> saveUserData(userData) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt("UserId", userData[0]["UserId"]);
    prefs.setString("UserName", userData[0]["UserName"]);
    prefs.setString("PSWRD", userData[0]["PSWRD"]);
    prefs.setInt("EmpID", userData[0]["EmpID"]);
    prefs.setString('UserType', userData[0]["UserType"]);
  }
}




// var response = await Dio(BaseOptions(headers: {
// 'Content-Type': 'application/json',
// 'Accept': 'application/json',
// })).get("http://104.196.134.107/AfitAPI/api/user",
// queryParameters: {'userName': userName, 'PSWRD': pass},
// options: Options(headers: {'Authorization':'Bearer $token'}));