import 'package:flutter/material.dart';
import 'package:octpedia/Presentation/Resources/assets_manager.dart';
import 'package:octpedia/Presentation/Resources/color_manager.dart';

class HomeModel {
  final String image;
  final String title;
  final String icon;
  final Color iconColor;
  HomeModel(this.image, this.title, this.icon, this.iconColor);
}

List<HomeModel> homeCategories = [
  HomeModel(
    ImageAssets.medical,
    'medical',
    IconAssets.medical,
    ColorManager.skyBlue,
  ),
  HomeModel(
    ImageAssets.tarfehy,
    'entertainment',
    IconAssets.entertainment,
    ColorManager.purple,
  ),
  HomeModel(
    ImageAssets.services,
    'services',
    IconAssets.services,
    ColorManager.green,
  ),
  HomeModel(
    ImageAssets.industrial,
    'industrial',
    IconAssets.industrial,
    ColorManager.orange,
  ),
  HomeModel(
    ImageAssets.logistic,
    'logistic',
    IconAssets.logistic,
    ColorManager.pink,
  ),
  HomeModel(
    ImageAssets.realState,
    'realState',
    IconAssets.realState,
    ColorManager.blue,
  ),
  HomeModel(
    ImageAssets.education,
    'education',
    IconAssets.education,
    ColorManager.primary,
  ),
  HomeModel(
    ImageAssets.fixing,
    'fixing',
    IconAssets.fixing,
    ColorManager.grey,
  ),
  HomeModel(
    ImageAssets.mwaslat,
    'transportation',
    IconAssets.transportation,
    ColorManager.darkGreen,
  ),
];
