import 'package:elfares/genaral/constants/MyDropDown.dart';
import 'package:elfares/genaral/providers/SuppliersProvider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SuppliersDropdown extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // context.read<SuppliersProvider>().getSuppliers();
    return Consumer<SuppliersProvider>(
      builder: (context, suppliers, child) => CustomDropDown(
        hint: "اختر المورد",
        items: suppliers.suppliersNames,
        value: suppliers.supplierName,
        onChange: (value) => suppliers.changeSupplierName(value),
      ),
    );
  }
}
