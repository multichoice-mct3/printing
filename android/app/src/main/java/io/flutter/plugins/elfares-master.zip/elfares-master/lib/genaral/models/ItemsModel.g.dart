// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ItemsModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Items _$ItemsFromJson(Map<String, dynamic> json) {
  return Items(
    itemName: json['ItemName'] as String?,
    unitName: json['UnitName'] as String?,
    unitId: json['UnitId'] as int?,
    itemId: json['ItemID'] as int?,
    itemSalePrice: (json['ItemSalePrice'] as num?)?.toDouble(),
    availableQty: (json['AvailableQty'] as num?)?.toDouble(),
    companyName: json['CompanyName'] as String?,
    groupId: json['GroupID'] as int?,
    itemNo: json['ItemNO'] as String?,
    itemNote1: json['ItemNote1'] as String?,
    itemNote2: json['ItemNote2'] as String?,
  );
}

Map<String, dynamic> _$ItemsToJson(Items instance) => <String, dynamic>{
      'ItemName': instance.itemName,
      'UnitName': instance.unitName,
      'ItemID': instance.itemId,
      'UnitId': instance.unitId,
      'ItemSalePrice': instance.itemSalePrice,
      'AvailableQty': instance.availableQty,
      'CompanyName': instance.companyName,
      'ItemNote1': instance.itemNote1,
      'ItemNote2': instance.itemNote2,
      'ItemNO': instance.itemNo,
      'GroupID': instance.groupId,
    };
