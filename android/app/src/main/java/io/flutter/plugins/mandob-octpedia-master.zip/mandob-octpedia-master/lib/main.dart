import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:mandoboct/General/Constants/MyColors.dart';
import 'package:mandoboct/General/Provider/AuthProvider.dart';
import 'package:mandoboct/General/Provider/CategoriesProvider.dart';
import 'package:mandoboct/General/Provider/MainProvider.dart';
import 'package:mandoboct/General/Provider/ServiceProvider.dart';
import 'package:mandoboct/General/Provider/provider.dart';
import 'package:mandoboct/Screens/Splash.dart';
import 'package:provider/provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(EasyLocalization(
    supportedLocales: [Locale('ar', 'EG'), Locale('en', 'US')],
    path: 'assets/langs',
    fallbackLocale: Locale('ar', 'EG'),
    startLocale: Locale('ar', 'EG'),
    child: MyApp(),
  ));
}

// ignore: must_be_immutable
class MyApp extends StatelessWidget {
  ThemeData _defaultThem = ThemeData(
    fontFamily: "Almarai",
    primarySwatch: Colors.grey,
    focusColor: MyColors.primary,
    accentColor: MyColors.primary,
    primaryColor: MyColors.primary,
    platform: TargetPlatform.android,
    pageTransitionsTheme: PageTransitionsTheme(builders: {
      TargetPlatform.android: CupertinoPageTransitionsBuilder(),
    }),
  );
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => CategoriesProvider()),
        ChangeNotifierProvider(create: (context) => ServiceProvider()),
        ChangeNotifierProvider(create: (context) => MainProvider()),
        ChangeNotifierProvider<MokademKhedma>(
            create: (context) => MokademKhedma()),
        ChangeNotifierProvider<AuthProvider>(
            create: (context) => AuthProvider())
      ],
      child: MaterialApp(
        title: 'إضافة مزود خدمة',
        debugShowCheckedModeBanner: false,
        theme: _defaultThem,
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        home: Splash(),
      ),
    );
  }
}
