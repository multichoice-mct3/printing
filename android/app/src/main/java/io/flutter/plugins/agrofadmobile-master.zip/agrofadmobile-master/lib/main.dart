import 'package:agrofad/provider_services/agentRouts_provider.dart';
import 'package:agrofad/provider_services/emps_provider.dart';
import 'package:agrofad/provider_services/item_provider.dart';
import 'package:agrofad/provider_services/user_Detail_provider.dart';
import 'package:agrofad/screens/Agent_routes.dart';
import 'package:agrofad/screens/account_stmt.dart';
import 'package:agrofad/screens/addAgents_routs.dart';
import 'package:agrofad/screens/addCustomer.dart';
import 'package:agrofad/screens/agent_resultRouts.dart';
import 'package:agrofad/screens/bank_stmt.dart';
import 'package:agrofad/screens/get_orders.dart';
import 'package:agrofad/screens/order_detail.dart';
import 'package:agrofad/screens/ordered_supply.dart';
import 'package:agrofad/screens/treasure_stmt.dart';
import 'package:agrofad/splash_screen.dart';
import 'package:device_preview/device_preview.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'AgrofadMainScreen.dart';
import 'screens/user_login.dart';
void main() {
  // runApp( DevicePreview(builder: (context)=>MyApp(),));
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => UserDetail(),
        ),
        ChangeNotifierProvider(create: (context) => AgentRoutsProvider()),
        ChangeNotifierProvider(create: (context) => EmpsProvider()),
        ChangeNotifierProvider(create: (context) => ItemProvider()),

      ],
      child: MaterialApp(
          //builder: (ctx, widget)=>Directionality(textDirection: TextDirection.rtl, child: DevicePreview.appBuilder(ctx, widget)),
          builder: DevicePreview.appBuilder,
          title: 'The Capital Erp',
          initialRoute: SplashWidget.id,
          routes: {
            SplashWidget.id: (Context) => SplashWidget(),
            UserLogin.id: (context) => UserLogin(),
            AgrofadMainScreen.id: (context) => AgrofadMainScreen(),
            AccountStatment.id: (context) => AccountStatment(),
            OrderedSupply.id: (Context) => OrderedSupply(),
            Orders.id: (context) => Orders(),
            OrderSupplyDet.id: (context) => OrderSupplyDet(),
            TreasureAccountStmt.id: (context) => TreasureAccountStmt(),
            BankAccountStmt.id: (context) => BankAccountStmt(),
            AddAgentRouts.id: (context) => AddAgentRouts(),
            EmpRoutes.id: (context) => EmpRoutes(),
            AddCustomer.id:(context)=>AddCustomer(),
            AgentResultRoutes.id:(context)=>AgentResultRoutes()

          }),
    );
  }
}
