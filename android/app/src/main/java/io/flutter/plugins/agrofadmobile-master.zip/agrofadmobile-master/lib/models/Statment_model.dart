class StatmentModel{

double Credit;
double Debit;
double StatementBal;
String StatementNotes;
String EntryDate;

StatmentModel({this.Credit, this.Debit, this.StatementBal, this.StatementNotes,
  this.EntryDate});

factory StatmentModel.FromJson(Map<String,dynamic> Stmt){
  return StatmentModel(
    Credit: Stmt['Credit'],
    Debit: Stmt['Debit'],
    EntryDate: Stmt['EntryDate'],
    StatementBal: Stmt['StatementBal'],
    StatementNotes: Stmt['StatementNotes']
  );
}
}



