part of "HomeImports.dart";

// ignore: must_be_immutable
class StoresTransfer extends StatelessWidget {
  String? unit;
  TextEditingController qty = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ItemsMainScreen(
      title: "تحويل بين مخازن",
      content: Column(
        children: [
          IndexAndDate(),
          Row(
            children: [
              MyText(
                title: 'من',
                color: MyColors.white,
                size: 14,
              ),
              Flexible(child: StoresDropdown()),
            ],
          ),
          Row(
            children: [
              MyText(
                title: 'الى',
                color: MyColors.white,
                size: 14,
              ),
              Flexible(child: StoresDropdown()),
            ],
          ),
          const SizedBox(height: 10),
          ItemsDropdown(),
          const SizedBox(height: 10),
          UnitAndQtyAndPrice(
            qty: qty,
            unit: unit!,
            showPrice: false,
          ),
        ],
      ),
    );
  }
}
