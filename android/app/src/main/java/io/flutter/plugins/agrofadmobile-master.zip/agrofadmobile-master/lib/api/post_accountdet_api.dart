import 'dart:convert';

import 'package:agrofad/models/post_account_det.dart';
import 'package:http/http.dart' as http;

import 'login_apis.dart';



class GetAccountStatmentsApi {
  LoginApi loginApi = new LoginApi();
  String BaseUrl = 'http://104.196.134.107/AfitAPI/api';
  Future<bool> GetDataFromModel(AccountDetModel accountDetModel) async {
    Map<String, dynamic> AccountDet = accountDetModel.toJson();
    String AccountDetForSatatment = jsonEncode(accountDetModel);
    await loginApi.getAccessToken();
    print('${loginApi.token}');
    Map Headers = <String, String>{
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var Response = await http.post(
        'http://104.196.134.107/AfitAPI/api/RequestOrders',
        body: AccountDetForSatatment,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${loginApi.token}',
        });
    if (Response.statusCode == 201) {
      var PostResult = jsonDecode(Response.body);
    } else {
      var PostResult = jsonDecode(Response.body);

      print(PostResult);
    }
  }
  // List<AccountStatmentModel> ParseItems(String responseBody) {
  //   final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();
  //
  //   return parsedItems.map<Customer>((json) => Customer.formjson(json)).toList();
  // }

}
