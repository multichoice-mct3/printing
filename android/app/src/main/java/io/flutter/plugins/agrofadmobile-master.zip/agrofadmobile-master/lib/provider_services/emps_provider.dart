import 'package:agrofad/api/get_emps_api.dart';
import 'package:agrofad/models/emp+model.dart';
import 'package:flutter/cupertino.dart';
class EmpsProvider extends ChangeNotifier{
  int _SelectedEmpId;
  String _SelectedEmpName;
  GetEmpsApi _getEmpsApi=GetEmpsApi();
List<Emp>_Emps=[];
List<Emp> get GetEmps=>_Emps;
  int get GetEmpId=>_SelectedEmpId;
  String get GetEmpName=> _SelectedEmpName;

getEmpsFromApi()async{
  _SelectedEmpId=null;
  _SelectedEmpName=null;
  _Emps=await _getEmpsApi.GetEmps();
  return _Emps;
}
  updateEmpId(String EmpName){
    for(Emp emp in _Emps){
      if (emp.EmpName==EmpName){
        _SelectedEmpId=emp.EmpId;
      }
    }
  }
  changeSelectedEmp(String EmpName){
    _SelectedEmpName=EmpName;
    updateEmpId(EmpName);
    notifyListeners();
  }
  clearEmpId(){
    _SelectedEmpId=null;
  }



}