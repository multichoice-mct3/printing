import 'package:json_annotation/json_annotation.dart';
part 'AccountModel.g.dart';

@JsonSerializable(includeIfNull: true)
class AccountModel {
  @JsonKey(name: "ACCOUNTID")
  String? accountId;
  @JsonKey(name: "AccountName")
  String? accountName;
  AccountModel({this.accountId, this.accountName});
  factory AccountModel.fromJson(Map<String, dynamic> json) =>
      _$AccountModelFromJson(json);
  Map<String, dynamic> toJson() => _$AccountModelToJson(this);
}
