class Category {
  int? categoriesId;
  String? categoriesName;
  String? categoriesIcone;
  String? categoriesColor;

  Category(
      {this.categoriesId,
      this.categoriesName,
      this.categoriesIcone,
      this.categoriesColor});

  Category.fromJson(Map<String, dynamic> json) {
    categoriesId = json['categoriesId'];
    categoriesName = json['categoriesName'];
    categoriesIcone = json['categoriesIcone'];
    categoriesColor = json['categoriesColor'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['categoriesId'] = this.categoriesId;
    data['categoriesName'] = this.categoriesName;
    data['categoriesIcone'] = this.categoriesIcone;
    data['categoriesColor'] = this.categoriesColor;
    return data;
  }
}
