import 'package:flutter/material.dart';
import 'package:mandoboct/General/Constants/MyColors.dart';

class MyElevatedBtn extends StatefulWidget {
  const MyElevatedBtn({
    Key? key,
    required this.onTap,
    required this.child,
    this.size,
  }) : super(key: key);
  final Function onTap;
  final Widget child;
  final Size? size;
  @override
  _MyElevatedBtnState createState() => _MyElevatedBtnState();
}

class _MyElevatedBtnState extends State<MyElevatedBtn> {
  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Center(
      child: ElevatedButton(
        onPressed: () => widget.onTap(),
        child: widget.child,
        style: ElevatedButton.styleFrom(
          fixedSize: widget.size ?? Size(size.width * .4, size.height * .06),
          primary: MyColors.primary,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}
