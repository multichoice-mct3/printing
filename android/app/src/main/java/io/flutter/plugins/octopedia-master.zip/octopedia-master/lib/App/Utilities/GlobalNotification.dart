import 'dart:convert';
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:octpedia/App/Utilities/cach_helper.dart';
import 'package:octpedia/App/Utilities/global_state.dart';
import 'package:octpedia/Presentation/Authentication/Login/login_screen.dart';

class GlobalNotification {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  FlutterLocalNotificationsPlugin? _flutterLocalNotificationsPlugin;
  final int _id = 0;
  static GlobalKey<NavigatorState>? navigatorKey;
  // Function reset = () {};
  static GlobalNotification instance = GlobalNotification._();

  GlobalNotification._();

  setupNotification({GlobalKey<NavigatorState>? navKey, Function? func}) {
    navigatorKey = navKey;
    // reset = func!;
    _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    var android = const AndroidInitializationSettings("@mipmap/launcher_icon");
    var ios = const IOSInitializationSettings();
    var initSettings = InitializationSettings(android: android, iOS: ios);
    _flutterLocalNotificationsPlugin?.initialize(
      initSettings,
      onSelectNotification: onSelectNotification,
    );
    // _firebaseMessaging.configure(
    //   onMessage: (Map<String, dynamic> message) {
    //     _showLocalNotification(message, _id);
    //     if (message["data"]["type"].toString() == "2") {
    //       _logoutBackGround();
    //     }
    //     return;
    //   },
    //   onResume: (Map<String, dynamic> message) {
    //     if (message["data"]["type"].toString() == "2") {
    //       _logoutBackGround();
    //     }
    //     return;
    //   },
    //   onLaunch: (Map<String, dynamic> message) {
    //     if (message["data"]["type"].toString() == "2") {
    //       _logoutBackGround();
    //     }
    //     return;
    //   },
    // );
    _firebaseMessaging.getToken().then((token) {});
  }

  _showLocalNotification(message, id) async {
    var _notify = message["notification"];
    if (Platform.isAndroid) {
      _notify = message["data"];
    }

    var android = AndroidNotificationDetails(
      DateTime.now().toIso8601String(),
      "${_notify["title"]}",
      channelDescription: "${_notify["body"]}",
      priority: Priority.high,
      importance: Importance.max,
      playSound: true,
    );
    var ios = const IOSNotificationDetails();
    var _platform = NotificationDetails(android: android, iOS: ios);

    _flutterLocalNotificationsPlugin?.show(DateTime.now().microsecond,
        "${_notify["title"]}", "${_notify["body"]}", _platform,
        payload: json.encode(message["data"]));
    if (_notify["type"].toString() == "2") {
      _logout();
    }
  }

  _logout() async {
    CachHelper.saveData(key: 'user', value: null);
    GlobalState.instance.set("user", null);
    Navigator.of(navigatorKey!.currentContext!).pushAndRemoveUntil(
        CupertinoPageRoute(builder: (_) => const LoginScreen()),
        (Route<dynamic> route) => false);
  }

  _logoutBackGround() async {
    CachHelper.saveData(key: 'user', value: null);
    GlobalState.instance.set("user", null);
  }

  Future onSelectNotification(payload) async {
    var obj = payload;
    if (payload is String) {
      obj = json.decode(payload);
    }
    print(obj);
    Future.delayed(const Duration(seconds: 1), () {
      if (obj["type"] == "1") {
        GlobalState.instance
            .set("orderId", int.parse(obj["order_id"].toString()));
        // navigatorKey?.currentState
        //     ?.push(MaterialPageRoute(builder: (context) => Notifications()));
      } else if (obj["type"] == "2") {
        GlobalState.instance
            .set("orderId", int.parse(obj["order_id"].toString()));
        // navigatorKey?.currentState
        //     ?.push(MaterialPageRoute(builder: (context) => Notifications()));
      }
    });
  }
}
