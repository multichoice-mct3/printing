// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'StoresModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Stores _$StoresFromJson(Map<String, dynamic> json) {
  return Stores(
    storeId: json['StoreId'] as int?,
    storeName: json['StoreName'] as String?,
  );
}

Map<String, dynamic> _$StoresToJson(Stores instance) => <String, dynamic>{
      'StoreId': instance.storeId,
      'StoreName': instance.storeName,
    };
