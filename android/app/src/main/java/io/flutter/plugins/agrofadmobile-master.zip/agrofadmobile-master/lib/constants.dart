import 'package:flutter/material.dart';

Color KmainColor=Color(0XFF13703A);
Color OfWhiteColor=Color(0XFFE6E7E8);
Color ErpMainColor=Color(0XFFA3F1DC);
Color WhiteColor=Colors.white;
Color BlackColor=Colors.black;



