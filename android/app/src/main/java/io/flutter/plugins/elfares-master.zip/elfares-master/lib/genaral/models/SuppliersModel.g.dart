// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'SuppliersModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SuppliersModel _$SuppliersModelFromJson(Map<String, dynamic> json) {
  return SuppliersModel(
    supplierId: json['SupplierId'] as int?,
    supplierName: json['SupplierName'] as String?,
  );
}

Map<String, dynamic> _$SuppliersModelToJson(SuppliersModel instance) =>
    <String, dynamic>{
      'SupplierId': instance.supplierId,
      'SupplierName': instance.supplierName,
    };
