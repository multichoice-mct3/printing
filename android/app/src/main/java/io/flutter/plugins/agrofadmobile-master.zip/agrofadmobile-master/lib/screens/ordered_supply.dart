import 'package:agrofad/api/Purchasing_apis.dart';
import 'package:agrofad/api/get_customers-api.dart';
import 'package:agrofad/api/post_OrderedSupply_api.dart';
import 'package:agrofad/custom_widgets/LifeCycleWidget.dart';
import 'package:agrofad/custom_widgets/custom_dialoge.dart';
import 'package:agrofad/models/AddItem_model.dart';
import 'package:agrofad/models/AddOrderedSupply_model.dart';
import 'package:agrofad/models/ItemModel.dart';
import 'package:agrofad/models/customer_model.dart';
import 'package:agrofad/provider_services/item_provider.dart';
import 'package:awesome_loader/awesome_loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:intl/intl.dart' as intl;
import 'package:provider/provider.dart';
import 'package:search_choices/search_choices.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants.dart';
import 'package:async/async.dart';
class OrderedSupply extends StatefulWidget {
  static String id = 'OrderedSupply';
  @override
  _OrderedSupplyState createState() => _OrderedSupplyState();
}

class _OrderedSupplyState extends State<OrderedSupply> {
  TextEditingController DateController = TextEditingController();
  TextEditingController orderController = TextEditingController();
  TextEditingController AvailableQty = TextEditingController();

  int Counter = 0;
  int serial;
  double Qty;
  String SelectedDate;
  String SelectedCustomerName;
  int SelectEdCustomerId;
  String ItemNameselectedValue;
  int ItemSelectedId;
  String UnitSelectValue;
  int UnitSelectedId;
  String SelectedCustomer;
  int EmpId;
  String EmpName;
  String IsApproved = '0';
  bool active = false;
  double showHeight = 0;
  bool posted;



  PostApi() async {
    OredredSupplyApi api = OredredSupplyApi();
    OrderedSupplyModel model = new OrderedSupplyModel(
        RequestOrderDate: SelectedDate,
        CustomerName: SelectedCustomerName,
        EmpID: EmpId,
        EmpName: EmpName,
        IsApproved: IsApproved,
        RequestOrderDet: ItemList,
        CustomerId: SelectEdCustomerId);
    posted = await api.GetDataFromModel(model);
  }

  PurchasingApi ItemApi = PurchasingApi(); //create object from PurchasingApi
  GetCustomersApi _customersApi =
      GetCustomersApi(); //create aboject from GetCustomersApi
  AddItemModel _addItemModel;

  List<String> items = [];
  List<String> units = ['عبوة'];
  List<Item> itemObjs = [];
  List<Customer> Customers = [];
  List<AddItemModel> ItemList = [];
  List<Item> GetItemsList;
  List<Customer> CustomerList;

  bool done = false;
//  final Future futures=Future

  //apis
  Future<List<Item>> GetItems() async {
    //getallitems api
    itemObjs = await ItemApi.GetItems();
    return itemObjs;
  }

  int GetUnitId(String UnitName) {
    int Id;
    for (Item item in itemObjs) {
      if (item.UnitName == UnitName) {
        Id = item.UnitId;
      }
    }
    return Id;
  }

  Future<List<Customer>> GetCustomers() async {
    //getallitems api
    Customers = await _customersApi.GetCustomers();
    return Customers;
  }

  void RemoveItem(int index) {
    setState(() {
      ItemList.removeAt(index);
    });
  }

  Future<void> getUserDateail() async {
    final prefs = await SharedPreferences.getInstance();
    EmpId = prefs.getInt("EmpID");
    EmpName = prefs.getString('UserName');
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    () async {
      // GetItemsList = await GetItems();
      // CustomerList = await GetCustomers();
      DateController.text =
          intl.DateFormat('yyyy/MM/dd').format(DateTime.now());
      SelectedDate = DateController.text;
      ItemList = [];
      await getUserDateail();
      setState(() {
        done = true;
      });
    }();
  }
  final memoizedFuture = AsyncMemoizer<List<dynamic>>();
  @override
  Widget build(BuildContext context) {
    double ScreenWidth = MediaQuery.of(context).size.width;
    double ScreenHieght = MediaQuery.of(context).size.height;
    return SafeArea(
      child: FutureBuilder(
        future: memoizedFuture.runOnce(() => Future.wait(<Future<dynamic>>[
          Provider.of<ItemProvider>(context).GetItemsFromApi(),
          Provider.of<ItemProvider>(context).GetCustomerFromApi()
        ])),
        builder: (context,AsyncSnapshot snapshot){

          return Scaffold(
              backgroundColor: snapshot.connectionState==ConnectionState.waiting?Colors.white:KmainColor,
              body: (){
                if (snapshot.connectionState==ConnectionState.done&&snapshot.hasData){
                  itemObjs=snapshot.data[0];
                  Customers=snapshot.data[1];
                  return  ListView(
                    children: [
                      Column(
                        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          FirstContainer(ScreenWidth),
                          Padding(
                              padding: const EdgeInsets.only(
                                  right: 10, top: 10, left: 10, bottom: 5),
                              child:
                              Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  Column(
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                            color: OfWhiteColor,
                                            borderRadius:
                                            BorderRadius.circular(20)),
                                        child: Column(
                                          //   crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets
                                                  .symmetric(
                                                  horizontal: 20,
                                                  vertical: 5),
                                              child: SearchableDrDown(
                                                  itemObjs),
                                            ),
                                            ItemDet(),
                                            SizedBox(
                                              height: 24,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: showHeight / 3.5,
                                        color: KmainColor,
                                      ),
                                    ],
                                  ),
                                  LifeCycleWidget(
                                    onMounted: (Size) {
                                      setState(() {
                                        showHeight = Size.height;
                                      });
                                    },
                                    child: Container(
                                      height: 40,
                                      width: 60,
                                      child: RaisedButton(
                                        color: Colors.amber,
                                        onPressed: () {
                                          if (ItemNameselectedValue != null &&
                                              UnitSelectValue != null &&
                                              Qty != null) {
                                            AddItemModel _model = new AddItemModel(
                                                ItemName: ItemNameselectedValue,
                                                UnitName: UnitSelectValue,
                                                qty: Qty,
                                                ItemId: ItemSelectedId,
                                                UnitId: UnitSelectedId);
                                            setState(() {
                                              // Counter=Counter+1;
                                              ItemList.add(_model);
                                              ItemNameselectedValue = null;
                                              Qty = null;
                                            });
                                          } else {
                                            showDialog(
                                                context: context,
                                                builder: (BuildContext context) {
                                                  return CustomDialoge(
                                                    Anothercontext: context,
                                                    Message: 'من فضلك قم بادخال كل البيانات  ',
                                                    Callback: () {
                                                      Navigator.pop(context);
                                                    },
                                                  );
                                                });
                                          }
                                        },
                                        textColor: KmainColor,
                                        child: Text(
                                          '+',
                                          style: TextStyle(
                                            fontFamily: 'cocon',
                                            fontSize: 30,
                                            color: Colors.white,
                                          ),
                                        ),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(100.0),
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              )


                          ),


                          Container(
                              width: ScreenWidth,
                              height: ScreenHieght * .5,
                              color: KmainColor,
                              child: Column(
                                children: [
                                  ItemsMainRow(),
                                  Expanded(
                                    child: ListView.builder(
                                        itemCount: ItemList.length,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return Slidable(

                                            child: ItemsRecord(
                                                ItemList[index], index),

                                            actionPane:
                                            SlidableDrawerActionPane(),
                                            actionExtentRatio: .09,
                                            secondaryActions: [
                                              IconSlideAction(

                                                //     icon: Icons.delete,
                                                onTap: () {
                                                  RemoveItem(index);
                                                },
                                                color: KmainColor,
                                                iconWidget: Icon(
                                                  Icons.delete,
                                                  size: 25,
                                                  color: Colors.red,
                                                ),
                                              )
                                            ],
                                          );
                                        }),
                                  ),
                                ],
                              )),

                          // SizedBox(
                          //   height: 20,
                          // ),
                          // Center(
                          //   child: Container(
                          //     width: 100,
                          //     height: 50,
                          //     child: RaisedButton(
                          //       color: OfWhiteColor,
                          //       onPressed: () {
                          //         Navigator.pushNamed(context, AgrofadMainScreen.id);
                          //       },
                          //       textColor: KmainColor,
                          //       child: Text(
                          //         'رجوع',
                          //         style: TextStyle(
                          //           fontFamily: 'cocon',
                          //           fontSize: 22,
                          //         ),
                          //       ),
                          //       shape: RoundedRectangleBorder(
                          //           borderRadius: BorderRadius.circular(20.0),
                          //           side: BorderSide(color: Colors.white)),
                          //     ),
                          //   ),
                          // )
                        ],
                      ),
                    ],
                  );
                }
                else if (snapshot.hasError)
                  return Center(child: Text('قم بفحص الاتصال بالانترنت'));
                else {
                  return Center(
                      child: Container(
                        height: 30,
                        width: 30,
                        child: AwesomeLoader(
                          loaderType: AwesomeLoader.AwesomeLoader3,
                          color: KmainColor,
                        ),
                      ));
                }
              }()
            //:Center(child: CircularProgressIndicator()),
          );
        },
      ),
    );
  }
  Widget DateRow({@required double WidgetWidth, @required double WidgetHiegt}) {
    return Container(
      height: WidgetHiegt / 4,
      child: Expanded(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          textDirection: TextDirection.rtl,
          children: [
            SizedBox(
              width: 5,
            ),
            Expanded(
              flex: 1,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                textDirection: TextDirection.rtl,
                children: [
                  Text(
                    'م',
                    style: TextStyle(
                        fontFamily: 'cocon', fontSize: 20, color: Colors.white),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  OrderdSuppliedTextField(
                      Format:
                          FilteringTextInputFormatter.allow((RegExp(r'[0-9]'))),
                      TextCallBack: (value) {
                        setState(() {
                          serial = int.parse(value);
                        });
                      },
                      FieldWidth: WidgetWidth * 15 / 100,
                      FieldHieht: WidgetHiegt * 20 / 100),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                textDirection: TextDirection.rtl,
                children: [
                  Text(
                    'التاريخ',
                    style: TextStyle(
                        fontFamily: 'cocon', fontSize: 20, color: Colors.white),
                  ),
                  Row(
                    children: [
                      Container(
                        width: WidgetWidth * 3 / 10,
                        height: WidgetHiegt * 20 / 100,
                        child: TextField(
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12, color: Colors.black),
                          controller: DateController,
                          textDirection: TextDirection.rtl,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(
                                  color: Colors.grey,
                                )),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(
                                  color: Colors.grey,
                                )),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(
                                  color: Colors.grey,
                                )),
                          ),
                        ),
                      ),
                      Expanded(child: SelectDate())
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget SelectDate() {
    return MaterialButton(
      // height: double.infinity,
      minWidth: 0,
      padding: EdgeInsets.symmetric(horizontal: 20),
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      onPressed: () {
        DatePicker.showDatePicker(context,
            showTitleActions: true,
            minTime: DateTime(2019, 1, 1),
            maxTime: DateTime(2030, 1, 1),
            theme: DatePickerTheme(
                cancelStyle: TextStyle(
                    color: OfWhiteColor,
                    fontSize: 15,
                    fontWeight: FontWeight.bold),
                headerColor: Colors.amber,
                backgroundColor: Colors.white,
                itemStyle: TextStyle(
                    color: KmainColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 18),
                doneStyle: TextStyle(color: Colors.white, fontSize: 16)),
            onConfirm: (date) {
          setState(() {
            DateController.text = intl.DateFormat('yyyy/MM/dd').format(date);
            SelectedDate = DateController.text;
            print(SelectedDate);
          });
        }, currentTime: DateTime.now(), locale: LocaleType.en);
      },
      child: Icon(
        Icons.date_range,
        color: Colors.white,
      ),
    );
  }

  Widget ItemDet() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 5,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        textDirection: TextDirection.rtl,
        children: [
          Expanded(
            flex: 5,
            child: Row(
             // mainAxisAlignment: MainAxisAlignment.end,
              textDirection: TextDirection.rtl,
              children: [
                Expanded(
                  flex:2,
                  child: Text(
                    'الوحدة',
                    style: TextStyle(
                        fontFamily: 'cocon', fontSize: 15, color: KmainColor),
                  ),
                ),
                SizedBox(
                  width: 5,
                ),
                Expanded(
                  flex: 3,
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white),
                      child: units.isEmpty
                          ? Container()
                          : DropdownButton<String>(
                              // isExpanded: true,
                              selectedItemBuilder: (BuildContext context) {
                                return units.map((String UnitName) {
                                  return Padding(
                                    padding: const EdgeInsets.only(
                                        right: 12, top: 12),
                                    child: Text(UnitName),
                                  );
                                }).toList();
                              },
                              style: TextStyle(
                                color: KmainColor,
                                fontSize: 18,
                                fontFamily: 'cocon',
                              ),
                              value: UnitSelectValue,
                              items: units.map<DropdownMenuItem<String>>(
                                  (String Value) {
                                return DropdownMenuItem<String>(
                                  value: Value != null ? Value : null,
                                  child: Text(Value),
                                );
                              }).toList(),
                              underline: Container(
                                height: 0.0,
                                padding: const EdgeInsets.all(0.0),
                                margin: const EdgeInsets.all(0.0),
                                decoration: BoxDecoration(border: null),
                              ),
                              icon: Icon(
                                Icons.arrow_drop_down,
                                size: 25,
                                color: KmainColor,
                              ),
                              onChanged: (value) {
                                setState(() {
                                  this.UnitSelectValue = value;
                                  UnitSelectedId = GetUnitId(UnitSelectValue);
                                });
                              },
                            ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 4,
            child: Row(
              children: [
                OrderdSuppliedTextField(
                  controller: orderController,
                  FieldWidth:60,
                  // FieldHieht: WidgetHiegt * 27 / 100,
                  TextCallBack: (value) {
                    setState(() {
                      Qty = double.parse(value);
                    });
                  },
                  Format: FilteringTextInputFormatter.allow((RegExp(r'[0-9]'))),
                ),
                SizedBox(
                  width: 5,
                ),
                Text(
                  'الكمية',
                  style: TextStyle(
                      fontFamily: 'cocon', fontSize: 15, color: KmainColor),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 4,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                OrderdSuppliedTextField(
                  controller: AvailableQty,
                  FieldWidth: 60,
                  Format: FilteringTextInputFormatter.allow((RegExp(r'[0-9]'))),
                ),

                Text(
                  'المتاح',
                  style: TextStyle(
                      fontFamily: 'cocon', fontSize: 15, color: KmainColor),
                ),
              ],
            ),
          ),
          // Container(
          //   height: 50,
          //   width: 50,
          //   child: RaisedButton(
          //     color: Colors.amber,
          //     onPressed: () {
          //       if (ItemNameselectedValue != null &&
          //           UnitSelectValue != null &&
          //           Qty != null) {
          //         AddItemModel _model = new AddItemModel(
          //             ItemName: ItemNameselectedValue,
          //             UnitName: UnitSelectValue,
          //             qty: Qty,
          //             ItemId: ItemSelectedId,
          //             UnitId: UnitSelectedId);
          //         setState(() {
          //           // Counter=Counter+1;
          //           ItemList.add(_model);
          //           ItemNameselectedValue = null;
          //           Qty = null;
          //         });
          //       } else {
          //         showDialog(
          //             context: context,
          //             builder: (BuildContext context) {
          //               return CustomDialoge(
          //                 Anothercontext: context,
          //                 Message: 'من فضلك قم بادخال كل البيانات  ',
          //                 Callback: () {
          //                   Navigator.pop(context);
          //                 },
          //               );
          //             });
          //       }
          //     },
          //     textColor: KmainColor,
          //     child: Text(
          //       '+',
          //       style: TextStyle(
          //         fontFamily: 'cocon',
          //         fontSize: 30,
          //         color: Colors.white,
          //       ),
          //     ),
          //     shape: RoundedRectangleBorder(
          //       borderRadius: BorderRadius.circular(100.0),
          //     ),
          //   ),
          // ),
          // SizedBox(
          //   width: 10,
          // ),
        ],
      ),
    );
  }

  Widget CustomerRow(ScreenWidth) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        // height:WidgetHiegt*22/100,
        width: ScreenWidth,

        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          //  textDirection: TextDirection.rtl,
          children: [
            Directionality(
              textDirection: TextDirection.rtl,
              child: Container(
                //   height: 70,
                width: 92 / 100 * ScreenWidth,
                decoration: BoxDecoration(
                    color: OfWhiteColor,
                    borderRadius: BorderRadius.circular(10)),
                child: getCustomertwo(Customers),
                // FutureBuilder<List<Customer>>(
                //     future: CustomerList,
                //     builder: (Context, AsyncSnapshot snapshot) {
                //
                //       List <Customer>Customers = snapshot.data;
                //       // print(items);
                //       switch(snapshot.connectionState){
                //
                //         case ConnectionState.done:return Container(
                //           decoration: BoxDecoration(
                //             borderRadius: BorderRadius.circular(20)
                //           ),
                //             child: getCustomertwo(Customers));
                //         break;
                //         case ConnectionState.active:return getCustomertwo(Customers);
                //         break;
                //         case ConnectionState.waiting:return CircularProgressIndicator();
                //         break;
                //         case ConnectionState.none:return CircularProgressIndicator();
                //         break;
                //       }
                //     }
                // ),
              ),
            )
          ],
        ),
      ),
    );
  }
  Widget OrderdSuppliedTextField(
      {@required double FieldWidth,
      @required double FieldHieht,
      @required Function TextCallBack,
      TextEditingController controller,
      FilteringTextInputFormatter Format}) {
    return Container(
      width: FieldWidth,
      height: FieldHieht,
      child: TextField(
        controller: controller ?? TextEditingController(),
        inputFormatters: [Format],
        onChanged: TextCallBack,
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        textDirection: TextDirection.rtl,
        textAlign: TextAlign.center,
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.only(top: 7),
          enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: Colors.white,
              )),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: Colors.white,
              )),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: Colors.white,
              )),
        ),
      ),
    );
  }

  Widget ItemsMainRow() {
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          textDirection: TextDirection.rtl,
          children: [
            Expanded(
              flex: 1,
              child: Container(
                //   width: MediaQuery.of(context).size.width*1/2,
                //  height: MediaQuery.of(context).size.height * 4 / 100,
                decoration: BoxDecoration(
                    color: OfWhiteColor,
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(10),
                        bottomRight: Radius.circular(10))),

                child: Center(
                  child: Text(
                    'م',
                    textAlign: TextAlign.start,
                    style: TextStyle(
                        color: KmainColor,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'cocon'),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 3,
            ),
            Expanded(
              flex: 6,
              child: Container(
                color: OfWhiteColor,
                child: Padding(
                  padding: const EdgeInsets.only(right: 25),
                  child: Text(
                    'صنف ',
                    textAlign: TextAlign.end,
                    style: TextStyle(
                      color: KmainColor,
                      fontSize: 17,
                      fontFamily: 'cocon',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 3,
            ),
            Expanded(
              flex: 2,
              child: Container(
                //     width: MediaQuery.of(context).size.width*1/4,
                //  height: MediaQuery.of(context).size.height*4/100,
                color: OfWhiteColor,

                child: Align(
                  alignment: AlignmentDirectional.center,
                  child: Text(
                    'كمية ',
                    //   textDirection: TextDirection.rtl,
                    textAlign: TextAlign.end,
                    style: TextStyle(
                      color: KmainColor,
                      fontSize: 17,
                      fontFamily: 'cocon',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              width: 3,
            ),
            Expanded(
              flex: 2,
              child: Container(
                decoration: BoxDecoration(
                    color: OfWhiteColor,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(10),
                        bottomLeft: Radius.circular(10))),

                child: Align(
                  alignment: AlignmentDirectional.center,
                  child: Text(
                    'وحدة ',
                    textAlign: TextAlign.end,
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      color: KmainColor,
                      fontSize: 17,
                      fontFamily: 'cocon',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),

            // Expanded(
            //   flex: 1,
            //   child: Container(
            //     //   width: MediaQuery.of(context).size.width*1/2,
            //     // height: MediaQuery.of(context).size.height * 4 / 100,
            //
            //     decoration: BoxDecoration(
            //       color: OfWhiteColor,
            //       borderRadius: BorderRadius.only(
            //           topLeft: Radius.circular(10),
            //           bottomLeft: Radius.circular(10)),
            //     ),
            //
            //     child: Center(
            //       child: Text(
            //         "x",
            //         textAlign: TextAlign.center,
            //         style: TextStyle(
            //           color: Colors.red,
            //           fontSize: 20,
            //           fontWeight: FontWeight.bold,
            //         ),
            //       ),
            //     ),
            //   ),
            // ),
          ],
        ));
  }

  Widget ItemsRecord(AddItemModel item, int index) {
    ItemList[index].SerNo = index + 1;
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          children: [
            SizedBox(
              height: 3,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              textDirection: TextDirection.rtl,
              children: [
                Expanded(
                  flex: 1,
                  child: Container(
                    //   width: MediaQuery.of(context).size.width*1/2,
                    height: MediaQuery.of(context).size.height * 4 / 100,
                    decoration: BoxDecoration(
                        color: WhiteColor,
                        borderRadius: BorderRadius.only(
                            topRight: Radius.circular(10),
                            bottomRight: Radius.circular(10))),

                    child: Center(
                      child: Text(
                        (item.SerNo).toString(),
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 3,
                ),
                Expanded(
                  flex: 6,
                  child: Container(
                    //   width: MediaQuery.of(context).size.width*1/2,
                    height: MediaQuery.of(context).size.height * 4 / 100,
                    color: WhiteColor,

                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 13),
                          child: Text(
                            item.ItemName,
                            style: TextStyle(
                              color: KmainColor,
                              fontSize: 16,
                              fontFamily: 'cocon',
                              //  fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  width: 3,
                ),
                Expanded(
                  flex: 2,
                  child: Container(
                    //     width: MediaQuery.of(context).size.width*1/4,
                    height: MediaQuery.of(context).size.height * 4 / 100,
                    color: WhiteColor,

                    child: Align(
                      alignment: AlignmentDirectional.center,
                      child: Text(
                        item.qty.toString(),
                        textAlign: TextAlign.end,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontFamily: 'cocon',
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 3,
                ),
                Expanded(
                  flex: 2,
                  child: Container(
                    //   width: MediaQuery.of(context).size.width*1/4,
                    height: MediaQuery.of(context).size.height * 4 / 100,
                decoration: BoxDecoration(
                    color: WhiteColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    bottomLeft: Radius.circular(10),
                  )
                ),

                    child: Align(
                      alignment: AlignmentDirectional.center,
                      child: Text(
                        item.UnitName,
                        textAlign: TextAlign.end,
                        style: TextStyle(
                          color: KmainColor,
                          fontSize: 16,
                          fontFamily: 'cocon',
                        ),
                      ),
                    ),
                  ),
                ),

              ],
            )
          ],
        ));
  }

  Widget SearchableDrDown(List<Item> AllItems) {
    int Id;
    double Qty;
    List<String> items = [];
    for (Item item in AllItems) {
      items.add(item.ItemName);
    }
    changeUnitlist(String ItemName) {
      for (Item item in AllItems) {
        if (item.ItemName == ItemName) {
          units.clear();
          setState(() {
            this.UnitSelectValue = null;
            units.add(item.UnitName);
          });
        }
        // print(units[1]);
      }
    }
    double GetAvailableQty(String ItemName) {
      for (Item item in AllItems) {
        if (item.ItemName == ItemName) {
          Qty = item.AvailableQty;
        }
      }
      return Qty;
    }
    int GetItemId(String ItemName) {
      for (Item item in AllItems) {
        if (item.ItemName == ItemName) {
          Id = item.ItemId;
        }
      }
      return Id;
    }

    return SearchChoices.single(
      items: items.map<DropdownMenuItem<String>>((string) {
        return (DropdownMenuItem<String>(
          child: Text(
            string,
            textDirection: TextDirection.rtl,
            style:
                TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
          ),
          value: string,
        ));
      }).toList(),
      menuBackgroundColor: OfWhiteColor,
      value: ItemNameselectedValue,
      hint: Text(
        "اختر الصنف",
        textDirection: TextDirection.rtl,
        style: TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
      ),
      icon: Icon(
        Icons.arrow_drop_down,
        size: 25,
        color: KmainColor,
      ),
      clearIcon: Icon(
        Icons.clear,
        size: 22,
        color: Colors.red,
      ),
      searchHint: Text(
        "اختر الصنف",
        textDirection: TextDirection.rtl,
        style: TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
      ),
      closeButton: FlatButton(
        onPressed: () {
          Navigator.pop(context);
        },
        child: Text(
          "اغلاق",
          textDirection: TextDirection.rtl,
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'cocon',
              color: KmainColor),
        ),
      ),
      onChanged: (value) {
        setState(() {
          ItemNameselectedValue = value;
          ItemSelectedId = GetItemId(ItemNameselectedValue);
          AvailableQty.text=GetAvailableQty(ItemNameselectedValue).toString();
        });
        changeUnitlist(value);
      },
      isExpanded: true,
      rightToLeft: true,
      displayItem: (item, selected) {
        return (Row(textDirection: TextDirection.rtl, children: [
          selected
              ? Icon(
                  Icons.radio_button_checked,
                  color: Colors.grey,
                )
              : Icon(
                  Icons.radio_button_unchecked,
                  color: Colors.grey,
                ),
          SizedBox(width: 7),
          item,
          Expanded(
            child: SizedBox.shrink(),
          ),
        ]));
      },
      selectedValueWidgetFn: (item) {
        return Row(
          textDirection: TextDirection.rtl,
          children: <Widget>[
            (Text(
              item,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                  fontSize: 20, fontFamily: 'cocon', color: KmainColor),
            )),
          ],
        );
      },
    );
    // return SearchableDropdown.single(
    //   items: items.map<DropdownMenuItem<String>>((String value) {
    //     return DropdownMenuItem<String>(
    //       value: value,
    //       child: Text(
    //         value,
    //         textAlign: TextAlign.start,
    //         style:
    //             TextStyle(fontFamily: 'cocon', color: KmainColor, fontSize: 18),
    //       ),
    //     );
    //   }).toList(),
    //   value: ItemNameselectedValue,
    //   hint: Align(
    //     alignment: AlignmentDirectional.topEnd,
    //     child: Text(
    //       'اختار الصنف ',
    //       style:
    //           TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
    //     ),
    //   ),
    //   searchHint: Align(
    //     alignment: AlignmentDirectional.topEnd,
    //     child: Text(
    //       'اختار الصنف ',
    //       style:
    //           TextStyle(fontSize: 25, fontFamily: 'cocon', color: KmainColor),
    //     ),
    //   ),
    //   onChanged: (value) {
    //     setState(() {
    //       ItemNameselectedValue = value;
    //       ItemSelectedId = GetItemId(ItemNameselectedValue);
    //       changeUnitlist(value);
    //     });
    //   },
    //   isExpanded: true,
    //   displayClearIcon: true,
    //   closeButton: 'اغلاق',
    //   menuBackgroundColor: OfWhiteColor,
    // );
  }

  // Widget getCustomers(List<Customer> Customers) {
  //   List<String> CustomerNames = [];
  //
  //   for (Customer customer in Customers) {
  //     CustomerNames.add(customer.CustomerName);
  //   }
  //   return SearchableDropdown.single(
  //     items: CustomerNames.map<DropdownMenuItem<String>>((String value) {
  //       return DropdownMenuItem<String>(
  //         value: value,
  //         child: Text(value),
  //       );
  //     }).toList(),
  //     value: SelectedCustomer,
  //     hint: Align(
  //       alignment: AlignmentDirectional.topEnd,
  //       child: Text(
  //         'اختار العميل ',
  //         style:
  //             TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
  //       ),
  //     ),
  //     searchHint: Align(
  //       alignment: AlignmentDirectional.topEnd,
  //       child: Text(
  //         'اختار العميل ',
  //         style:
  //             TextStyle(fontSize: 25, fontFamily: 'cocon', color: Colors.white),
  //           ),
  //           ),
  //       onChanged: (value) {
  //       setState(() {
  //         SelectedCustomer = value;
  //       });
  //     },
  //     isExpanded: true,
  //     displayClearIcon: true,
  //     closeButton: 'اغلاق',
  //     menuBackgroundColor: Colors.white,
  //   );
  // }
  Widget getCustomertwo(List<Customer> Customers) {
    List<String> CustomerNames = [];

    int Id;
    for (Customer customer in Customers) {
      CustomerNames.add(customer.CustomerName);
    }
    int getCustomerId(String Customername) {
      for (Customer customer in Customers) {
        if (customer.CustomerName == Customername) {
          Id = customer.CustomerID;
        }
      }
      return Id;
    }

    return SearchChoices.single(
      items: CustomerNames.map<DropdownMenuItem<String>>((string) {
        return (DropdownMenuItem<String>(
          child: Text(
            string,
            textDirection: TextDirection.rtl,
            style:
                TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
          ),
          value: string,
        ));
      }).toList(),
      /////////////////////
      icon: Icon(
        Icons.arrow_drop_down,
        size: 25,
        color: KmainColor,
      ),
      clearIcon: Icon(
        Icons.clear,
        size: 22,
        color: Colors.red,
      ),
      underline: Container(
        height: 0.0,
        padding: const EdgeInsets.all(0.0),
        margin: const EdgeInsets.all(0.0),
        decoration: BoxDecoration(border: null),
      ),
      ///////////////////////
      menuBackgroundColor: OfWhiteColor,
      value: SelectedCustomerName,
      hint: Padding(
        padding: const EdgeInsets.all(0.0),
        child: Text(
          "اختر العميل",
          textDirection: TextDirection.rtl,
          style:
              TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
        ),
      ),
      searchHint: Text(
        "اختر العميل",
        textDirection: TextDirection.rtl,
        style: TextStyle(fontSize: 20, fontFamily: 'cocon', color: KmainColor),
      ),
      closeButton: FlatButton(
        onPressed: () {
          Navigator.pop(context);
        },
        child: Text(
          "اغلاق",
          textDirection: TextDirection.rtl,
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'cocon',
              color: KmainColor),
        ),
      ),
      onChanged: (value) {
        setState(() {
          SelectedCustomerName = value;
          SelectEdCustomerId = getCustomerId(SelectedCustomerName);
        });
      },
      isExpanded: true,
      rightToLeft: true,
      displayItem: (item, selected) {
        return (Row(textDirection: TextDirection.rtl, children: [
          selected
              ? Icon(
                  Icons.radio_button_checked,
                  color: Colors.grey,
                )
              : Icon(
                  Icons.radio_button_unchecked,
                  color: Colors.grey,
                ),
          SizedBox(width: 7),
          item,
          Expanded(
            child: SizedBox.shrink(),
          ),
        ]));
      },
      selectedValueWidgetFn: (item) {
        return Row(
          textDirection: TextDirection.rtl,
          children: <Widget>[
            (Text(
              item,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                  fontSize: 20, fontFamily: 'cocon', color: KmainColor),
            )),
          ],
        );
      },
    );

    // return DropdownSearch(
    //   items:CustomerNames ,
    //   mode: Mode.BOTTOM_SHEET,
    //   hint:'المندوب',
    //   showSelectedItem: true,
    //   searchBoxDecoration: InputDecoration(
    //           hintText: 'ابحث في العملاء',
    //           hintStyle: TextStyle(
    //           color: Colors.black,
    //           fontSize: 18
    //         ),
    //    contentPadding: EdgeInsets.symmetric(horizontal: 130),
    //    filled: true,
    //    fillColor:OfWhiteColor
    //  ),
    //
    //   showSearchBox: true,
    //   popupTitle: Container(
    //     height: 40,
    //     decoration: BoxDecoration(
    //       color: KmainColor,
    //       borderRadius: BorderRadius.only(
    //         topLeft: Radius.circular(20),
    //         topRight: Radius.circular(20),
    //       ),
    //     ),
    //     child: Center(
    //       child: Text(
    //         'العملاء',
    //         style: TextStyle(
    //           fontSize: 24,
    //           fontWeight: FontWeight.bold,
    //           color: Colors.white,
    //         ),
    //       ),
    //     ),
    //   ),
    //   popupShape: RoundedRectangleBorder(
    //     borderRadius: BorderRadius.only(
    //       topLeft: Radius.circular(24),
    //       topRight: Radius.circular(24),
    //     ),
    //   ),
    //
    //   onChanged: (value){
    //     setState(() {
    //       SelectedCustomerName=value;
    //       SelectEdCustomerId=getCustomerId(SelectedCustomerName);
    //     });
    //   },
    //
    //   enabled: true,
    //   dropdownBuilder:_customDropDownExample ,
    //
    //
    // );
  }

  Widget DropDownUnitBuilder(
      BuildContext context, String UnitName, String itemDesignation) {
    return Container(
      child: (UnitName == null)
          ? ListTile(
              contentPadding: EdgeInsets.symmetric(
                horizontal: 20,
              ),
              title: Text(
                "قطعة ",
                style: DrDwnText,
              ))
          : ListTile(
              contentPadding: EdgeInsets.symmetric(horizontal: 20),
              title: Text(
                UnitName,
                style: DrDwnText,
              ),
            ),
    );
  }

  Widget _customDropDownExample(
      BuildContext context, String CustomerName, String itemDesignation) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
      ),
      child: (CustomerName == null)
          ? ListTile(
              contentPadding: EdgeInsets.symmetric(
                horizontal: 10,
              ),
              title: Text(
                "العميل ",
                style: DrDwnText,
              ))
          : ListTile(
              contentPadding: EdgeInsets.symmetric(horizontal: 10),
              title: Text(
                CustomerName,
                style: DrDwnText,
              ),
            ),
    );
  }

  TextStyle DrDwnText = TextStyle(
    fontSize: 20,
    color: KmainColor,
    fontFamily: 'cocon',
  );

  Widget FirstContainer(double ScreenWidth) {
    return Column(
      children: [
        Container(
          width: ScreenWidth,
          height: 40,
          color: OfWhiteColor,
          child: Padding(
            padding: const EdgeInsets.only(right: 25),
            child: Row(
              textDirection: TextDirection.rtl,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'امر توريد لعميل',
                  textAlign: TextAlign.end,
                  style: TextStyle(
                    color: KmainColor,
                    fontSize: 25,
                    fontFamily: 'cocon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 3, left: 15, top: 3),
                  child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18.0),
                        side: BorderSide(color: Colors.amber)),
                    color: Colors.amber,
                    onPressed: () async {
                      if (!ItemList.isEmpty &&
                          //  ItemList!=null&&
                          SelectedDate != null &&
                          SelectEdCustomerId != null) {
                        await PostApi();
                        if (posted) {
                          showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return CustomDialoge(
                                  Anothercontext: context,
                                  Message: 'تم الحفظ بنجاح',
                                  Callback: () {
                                    Navigator.of(context).pop();
                                    ItemList = [];
                                    SelectedCustomerName = null;
                                    SelectEdCustomerId = null;
                                    ItemNameselectedValue = null;
                                    Qty = null;
                                    orderController.clear();
                                    UnitSelectValue = null;
                                  },
                                );
                              });
                        } else {
                          showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return CustomDialoge(
                                  Anothercontext: context,
                                  Message: 'لم يتم الحفظ بنجاح',
                                  Callback: () {
                                    Navigator.of(context).pop();
                                  },
                                );
                              });
                        }
                      } else
                        showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return CustomDialoge(
                                Anothercontext: context,
                                Message: 'من فضلك قم بادخال كل البيانات  ',
                                Callback: () {
                                  Navigator.of(context).pop();
                                },
                              );
                            });
                    },
                    child: Text(
                      'حفظ',
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'cocon',
                          fontSize: 18),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
        SizedBox(
          height: 10,
        ),
        DateRow1(),
        SizedBox(
          height: 10,
        ),
        CustomerRow(ScreenWidth),
        SizedBox(
          height: 5,
        ),
      ],
    );
  }

//////test
  Widget DateRow1() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      textDirection: TextDirection.rtl,
      children: [
        SizedBox(
          width: 15,
        ),
        Expanded(
          flex: 1,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            textDirection: TextDirection.rtl,
            children: [
              Text(
                'م',
                style: TextStyle(
                    fontFamily: 'cocon', fontSize: 20, color: Colors.white),
              ),
              SizedBox(
                width: 5,
              ),
              Expanded(
                child: SizedBox(
                  height: 40,
                  child: TextField(
                    textAlign: TextAlign.center,
                    enabled: false,
                    style: TextStyle(fontSize: 12, color: Colors.black),
                    textDirection: TextDirection.rtl,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      enabled: false,
                      hintText: 'Auto',
                      contentPadding: EdgeInsets.only(top: 7),
                      hintStyle: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Colors.grey,
                          )),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Colors.grey,
                          )),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(
                            color: Colors.grey,
                          )),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          width: 60,
        ),
        Expanded(
          flex: 3,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            textDirection: TextDirection.rtl,
            children: [
              Text(
                'التاريخ',
                style: TextStyle(
                    fontFamily: 'cocon', fontSize: 20, color: Colors.white),
              ),
              SizedBox(
                height: 40,
                width: 120,
                child: TextField(
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 15,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                  textDirection: TextDirection.rtl,
                  controller: DateController,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: EdgeInsets.only(bottom: 5),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: Colors.grey,
                        )),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: Colors.grey,
                        )),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: Colors.grey,
                        )),
                  ),
                ),
              ),
              SelectDate()
            ],
          ),
        )
      ],
    );
  }

  Widget OrderdSuppliedTextField1({
    double FieldWidth,
    double FieldHieht,
    Function TextCallBack,
    FilteringTextInputFormatter Format,
    TextEditingController controller,
  }) {
    return TextField(
      controller: controller ?? TextEditingController(),
      inputFormatters: [Format],
      onChanged: TextCallBack,
      textDirection: TextDirection.rtl,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(
              color: Colors.grey,
            )),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(
              color: Colors.grey,
            )),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(
              color: Colors.grey,
            )),
      ),
    );
  }

/////////////test
}
