import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class AnimationContainer extends StatefulWidget {
  final Widget child;
  final int? index;
  final bool? vertical;
  final double? distance;
  AnimationContainer({
    required this.child,
    this.index,
    this.vertical,
    this.distance = 100,
  });
  @override
  State<StatefulWidget> createState() => ClassState();
}

class ClassState extends State<AnimationContainer> {
  @override
  Widget build(BuildContext context) {
    return AnimationConfiguration.staggeredList(
      position: widget.index!,
      duration: const Duration(milliseconds: 500),
      child: Visibility(
        child: SlideAnimation(
          verticalOffset: widget.distance,
          child: FadeInAnimation(
            child: widget.child,
          ),
        ),
        visible: widget.vertical!,
        replacement: SlideAnimation(
          horizontalOffset: widget.distance,
          child: FadeInAnimation(
            child: widget.child,
          ),
        ),
      ),
    );
  }
}
