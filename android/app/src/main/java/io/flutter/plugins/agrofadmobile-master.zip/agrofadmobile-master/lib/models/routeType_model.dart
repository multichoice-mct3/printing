class RouteType {
  int RouteTypeId;
  String RouteTypeName;

  RouteType({this.RouteTypeId, this.RouteTypeName});
}
