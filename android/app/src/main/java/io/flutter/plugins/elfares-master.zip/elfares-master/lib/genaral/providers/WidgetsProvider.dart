import 'package:flutter/material.dart';

class WidgetProvider extends ChangeNotifier {
  bool loading = false;
  changeLoadingState() {
    loading = !loading;
    notifyListeners();
  }

  bool showDropDown = true;
  changeDropDown(bool show) {
    showDropDown = show;
    notifyListeners();
  }
}
