import 'package:flutter/cupertino.dart';
import '../network/API/SuppliersAPI.dart';
import '../models/SuppliersModel.dart';

class SuppliersProvider extends ChangeNotifier {
  SuppliersAPI _api = SuppliersAPI();
  List<SuppliersModel> _suppliers = [];
  List<SuppliersModel> get suppliers => _suppliers;
  List<String> _suppliersNames = [];
  List<String> get suppliersNames => _suppliersNames;
  int? _supplierId;
  int get supplierId => _supplierId!;
  String? supplierName;
  Future<void> getSuppliers() async {
    _suppliers = await _api.getSuppliersFromApi();
    fillNames();
    print(_suppliers.length);
    notifyListeners();
  }

  fillNames() {
    for (var emp in _suppliers) {
      _suppliersNames.add(emp.supplierName!);
    }
  }

  changeSupplierName(String newValue) {
    supplierName = newValue;
    getSupplierId(newValue);
    notifyListeners();
  }

  getSupplierId(String name) {
    int supId = _suppliers.indexWhere((element) => element.supplierId == name);
    _supplierId = _suppliers[supId].supplierId;
  }
}
