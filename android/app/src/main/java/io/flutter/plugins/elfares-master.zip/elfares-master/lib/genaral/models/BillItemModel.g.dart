// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'BillItemModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BillItemModel _$BillItemModelFromJson(Map<String, dynamic> json) {
  return BillItemModel(
    itemName: json['ItemName'] as String?,
    itemId: json['ItemId'] as int?,
    unitName: json['UnitName'] as String?,
    qty: (json['Qty'] as num?)?.toDouble(),
    price: (json['price'] as num?)?.toDouble(),
    tot: (json['Tot'] as num?)?.toDouble(),
    unitId: json['UnitId'] as int?,
  );
}

Map<String, dynamic> _$BillItemModelToJson(BillItemModel instance) =>
    <String, dynamic>{
      'ItemName': instance.itemName,
      'ItemId': instance.itemId,
      'UnitId': instance.unitId,
      'UnitName': instance.unitName,
      'Qty': instance.qty,
      'price': instance.price,
      'Tot': instance.tot,
    };
