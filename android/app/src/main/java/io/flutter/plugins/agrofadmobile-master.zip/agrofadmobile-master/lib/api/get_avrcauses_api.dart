import 'dart:convert';
import 'package:agrofad/models/avrCause_model.dart';
import 'package:http/http.dart' as http;
import 'login_apis.dart';

class GetAvrCausesApi {
  LoginApi loginApi = new LoginApi();
  List <AvrCause>AvrCauses=[];
  Future<List <AvrCause>> GetAvrCauses() async {
    await loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var response = await http.get("http://104.196.134.107/AfitAPI/api/AgentVisitCaus",
        headers: Headers);
    if (response.statusCode == 200) {
      AvrCauses= ParseItems(response.body);
   print(AvrCauses[0].AVCName);
    } else {
      print(response.body);
    }
    return AvrCauses;
  }
  //fn get the item list
  List<AvrCause> ParseItems(String responseBody) {
    final parsedItems = jsonDecode(responseBody).cast<Map<String, dynamic>>();
    return parsedItems.map<AvrCause>((json) => AvrCause.fromJson(json)).toList();
  }

}
