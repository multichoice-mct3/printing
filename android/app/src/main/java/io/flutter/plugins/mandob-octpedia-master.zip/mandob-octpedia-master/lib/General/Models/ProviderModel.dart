class ProviderModel {
  int? providesId;
  String? providesName;
  String? providesLogo;
  String? providesDisc;
  String? phone1;
  String? phone2;
  String? socialMediaUrl1;
  String? socialMediaUrl2;
  String? socialMediaUrl3;
  String? webUrl;
  double? mapLatitude;
  double? mapLongitude;
  int? categoriesId;
  String? categoriesName;
  int? servicesId;
  String? servicesName;
  int? servicesParantId;

  ProviderModel(
      {this.providesId,
      this.providesName,
      this.providesLogo,
      this.providesDisc,
      this.phone1,
      this.phone2,
      this.socialMediaUrl1,
      this.socialMediaUrl2,
      this.socialMediaUrl3,
      this.webUrl,
      this.mapLatitude,
      this.mapLongitude,
      this.categoriesId,
      this.categoriesName,
      this.servicesId,
      this.servicesName,
      this.servicesParantId});

  ProviderModel.fromJson(Map<String, dynamic> json) {
    providesId = json['providesId'];
    providesName = json['providesName'];
    providesLogo = json['providesLogo'];
    providesDisc = json['providesDisc'];
    phone1 = json['phone1'];
    phone2 = json['phone2'];
    socialMediaUrl1 = json['socialMediaUrl1'];
    socialMediaUrl2 = json['socialMediaUrl2'];
    socialMediaUrl3 = json['socialMediaUrl3'];
    webUrl = json['webUrl'];
    mapLatitude = json['mapLatitude'];
    mapLongitude = json['mapLongitude'];
    categoriesId = json['categoriesId'];
    categoriesName = json['categoriesName'];
    servicesId = json['servicesId'];
    servicesName = json['servicesName'];
    servicesParantId = json['servicesParantId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['providesId'] = this.providesId;
    data['providesName'] = this.providesName;
    data['providesLogo'] = this.providesLogo;
    data['providesDisc'] = this.providesDisc;
    data['phone1'] = this.phone1;
    data['phone2'] = this.phone2;
    data['socialMediaUrl1'] = this.socialMediaUrl1;
    data['socialMediaUrl2'] = this.socialMediaUrl2;
    data['socialMediaUrl3'] = this.socialMediaUrl3;
    data['webUrl'] = this.webUrl;
    data['mapLatitude'] = this.mapLatitude;
    data['mapLongitude'] = this.mapLongitude;
    data['categoriesId'] = this.categoriesId;
    data['categoriesName'] = this.categoriesName;
    data['servicesId'] = this.servicesId;
    data['servicesName'] = this.servicesName;
    data['servicesParantId'] = this.servicesParantId;
    return data;
  }
}
