import 'package:LocarionWallet/Public/Provider/LocationProvider.dart';
import 'package:LocarionWallet/Public/Utilits/Router.gr.dart';
import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:provider/provider.dart';
import './Constants/MyText.dart';
import 'package:flutter/Material.dart';
import 'Public/Screens/addPlace.dart';
import 'Public/Screens/searchScreen.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  void didChangeDependencies() async {
    await context.read<LocationProvider>().getLocations();
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      initialIndex: 1,
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: MyText(title: tr("locationWallet")),
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
                icon: Icon(Icons.logout),
                onPressed: () => ExtendedNavigator.root
                    .pushAndRemoveUntil(Routes.userLogin, (route) => false))
          ],
          bottom: TabBar(
            tabs: <Widget>[
              Tab(
                icon: Image.asset(
                  "assets/images/search.png",
                  height: 25,
                  width: 25,
                  color: Colors.white,
                ),
                text: tr("search"),
              ),
              Tab(
                icon: Image.asset(
                  "assets/images/add.png",
                  height: 25,
                  width: 25,
                  color: Colors.white,
                ),
                text: tr("add"),
              ),
            ],
          ),
        ),
        body: TabBarView(
          physics: NeverScrollableScrollPhysics(),
          children: <Widget>[
            SearchScreen(),
            AddPlace(),
          ],
        ),
      ),
    );
  }
}
