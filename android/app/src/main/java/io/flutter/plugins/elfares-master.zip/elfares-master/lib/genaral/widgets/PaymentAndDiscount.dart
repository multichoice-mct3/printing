part of "WidgetsImport.dart";

class PaymentAndDisCount extends StatelessWidget {
  PaymentAndDisCount({
    Key? key,
    this.paymentMethod,
    required this.discountController,
    required this.change,
  }) : super(key: key);

  String? paymentMethod;
  final TextEditingController discountController;
  final Function(String value) change;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              Flexible(
                child: SimpleDropDown(
                  hint: "طريقة الدفع",
                  items: paymentTypes,
                  value: paymentMethod,
                  onChanged: (value) => change(value),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: SizeConfig.screenWidth! * .1),
        Expanded(
          child: Row(
            children: [
              Flexible(
                child: LabelTextField(
                  controller: discountController,
                  type: TextInputType.number,
                  label: "الخصم",
                  isPassword: false,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
