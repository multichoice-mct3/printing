import 'package:json_annotation/json_annotation.dart';
part 'SuppliersModel.g.dart';

@JsonSerializable(explicitToJson: true)
class SuppliersModel {
  SuppliersModel({
    this.supplierId,
    this.supplierName,
  });
  @JsonKey(name: "SupplierId")
  late final int? supplierId;
  @JsonKey(name: "SupplierName")
  late final String? supplierName;

  factory SuppliersModel.fromJson(Map<String, dynamic> json) =>
      _$SuppliersModelFromJson(json);
  Map<String, dynamic> toJson() => _$SuppliersModelToJson(this);
}
