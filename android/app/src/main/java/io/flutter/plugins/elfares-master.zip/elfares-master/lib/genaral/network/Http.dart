import 'dart:convert';
import 'dart:developer';

// ignore: import_of_legacy_library_into_null_safe

import 'package:elfares/genaral/constants/MyToast.dart';
import 'package:elfares/genaral/utilities/CachHelper.dart';
import 'package:elfares/genaral/utilities/GlobalState.dart';
import 'package:elfares/main.dart';
import 'package:elfares/user/auth/LoginContent.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class HttpMethods {
  String token = CachHelper.getData(key: "token") ?? "";
  String baseUrl = "http://104.196.134.107/AfitAPI/api/";
  String tokenBaseUrl = "http://104.196.134.107/AfitAPI";
  Map<String, String> normalHeaders = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  };

  Future<dynamic> getData({required String url}) async {
    token = CachHelper.getData(key: "token");
    print(token);
    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer $token',
    };
    var response = await http.get(Uri.parse("$baseUrl/$url"), headers: headers);
    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      return data;
    } else if (response.statusCode == 401 || response.statusCode == 301) {
      sessionExpired();
    } else {
      log(response.body);
      print("bad request ${response.statusCode} at $url");
    }
  }

  Future<dynamic> postData(
      {required String url,
      dynamic body,
      Map<String, String>? authHeaders}) async {
    try {
      var response = await http.post(Uri.parse("$baseUrl/$url"),
          body: body,
          headers: authHeaders ??
              {
                'Content-Type': 'application/json',
                // 'Accept': 'application/json',
                'Authorization': 'bearer $token',
              });
      print("$baseUrl/$url");
      if (response.statusCode == 200 || response.statusCode == 201) {
        var data = json.decode(response.body);
        print(data);
        return data;
      } else if (response.statusCode == 401 || response.statusCode == 301) {
        sessionExpired();
      } else {
        print("bad request ${response.statusCode}at $url");
        return null;
      }
    } catch (e) {
      print(e);
      MyToast().showToast("Failed To Connect", Colors.red);
    }
  }

  Future<dynamic> companyLogin({required String company}) async {
    Map body = {
      "username": company,
      "password": company,
      "grant_type": "password"
    };
    try {
      var response =
          await http.post(Uri.parse("$tokenBaseUrl/token"), body: body);
      if (response.statusCode == 200 || response.statusCode == 201) {
        var data = json.decode(response.body);
        print(data["access_token"]);
        GlobalState.instance.set("token", data["access_token"]);
        CachHelper.saveData(key: "token", value: data["access_token"]);
        return data;
      } else {
        print("bad request ${response.statusCode}at token");
        print(response.body);
        return null;
      }
    } catch (e) {
      print(e);
      MyToast().showToast("E $e", Colors.red);
    }
  }

  putData({required String url, Map<String, dynamic>? body}) async {
    var response =
        await http.put(Uri.parse("$baseUrl/$url"), body: body, headers: {
      // 'Content-Type': 'application/json',
      // 'Accept': 'application/json',
      'Authorization': 'bearer $token',
    });
    if (response.statusCode == 200 || response.statusCode == 201) {
      var data = json.decode(response.body);
      print(data);
      return data;
    } else if (response.statusCode == 401 || response.statusCode == 301) {
      sessionExpired();
    } else {
      print("bad request ${response.statusCode}at $url");
    }
  }

  sessionExpired() {
    CachHelper.clearData();
    MyApp.navigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => LoginContent()),
        (route) => false);
  }
}
