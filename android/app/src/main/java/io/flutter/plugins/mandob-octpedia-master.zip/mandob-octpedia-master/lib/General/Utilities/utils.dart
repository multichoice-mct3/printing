import 'package:flutter/material.dart';
import 'package:mandoboct/General/Constants/MyColors.dart';
import 'package:mandoboct/General/Constants/MyText.dart';
// import 'package:url_launcher/url_launcher.dart';

class Utils {
  Utils(this.context);
  BuildContext context;
  // static void launchURL({required String url, scaffold}) async {
  //   if (!url.toString().startsWith("https")) {
  //     url = "https://" + url;
  //   }
  //   if (await canLaunch(url)) {
  //     await launch(url);
  //   } else {
  //     MyToast().showToast("Check Link", Colors.red);
  //   }
  // }

  // Future<void> makePhoneCall(String url) async {
  //   if (await canLaunch(url)) {
  //     await launch(url);
  //   } else {
  //     throw 'Could not launch $url';
  //   }
  // }

  // static void launchWhatsApp(phone) async {
  //   String message = 'مرحبا بك';
  //   if (phone.startsWith("02023")) {
  //     phone = phone.substring(5);
  //   }
  //   var _whatsAppUrl = "whatsapp://send?phone=+20$phone&text=$message";
  //   print(_whatsAppUrl);
  //   if (await canLaunch(_whatsAppUrl)) {
  //     await launch(_whatsAppUrl);
  //   } else {
  //     throw 'حدث خطأ ما';
  //   }
  // }

  // static void callPhone(phone) async {
  //   await launch("tel:$phone");
  // }

  // Future<void> makePhoneCall1(String url) async {
  //   if (await canLaunch(url)) {
  //     await launch(url);
  //   } else {
  //     throw 'Could not launch $url';
  //   }
  // }

  // static void sendMail(mail) async {
  //   await launch("mailto:$mail");
  // }

  static void showSnackBar(String msg, Color color, BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      // behavior: SnackBarBehavior.floating,
      content: MyText(title: msg, color: MyColors.white),
      backgroundColor: color,
      duration: Duration(milliseconds: 1500),
    ));
  }

  // showConnectivitySnackBar(ConnectivityResult result) {
  //   final hasInternet = result != ConnectivityResult.none;
  //   final message = hasInternet ? tr("octoberConnected") : tr("lostConnection");
  //   final color = hasInternet ? Colors.green : Colors.red;
  //   if (!hasInternet) {
  //     showSnackBar(message, color, context);
  //   }
  // }

  Future<bool> showExitPopup() async {
    return await showDialog(
          //show confirm dialogue
          //the return value will be from "Yes" or "No" options
          context: context,
          builder: (context) => AlertDialog(
            title: MyText(title: 'مغادرة التطبيق !'),
            content: MyText(title: 'هل تريد مغادرة أكتوبيديا؟'),
            actions: [
              ElevatedButton(
                onPressed: () => Navigator.of(context).pop(false),
                //return false when click on "NO"
                child: MyText(title: "لا", color: MyColors.white),
                style: ElevatedButton.styleFrom(primary: MyColors.secondary),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pop(true),
                //return true when click on "Yes"
                child: MyText(title: "نعم", color: MyColors.white),
                style: ElevatedButton.styleFrom(primary: MyColors.primary),
              ),
            ],
          ),
        ) ??
        false; //if showDialouge had returned null, then return false
  }
//   // static Future<void> manipulateSplashData(
//   //     Function func, GlobalKey<ScaffoldState> scaffold) async {
//   //   SharedPreferences prefs = await SharedPreferences.getInstance();
//   //   var strUser = prefs.get("user");
//   //   if (strUser != null) {
//   //     SavedDataModel data = SavedDataModel().savedDataModelFromJson(strUser);
//   //     GlobalState.instance.set("token", data.token);
//   //     GlobalState.instance.set("deviceId", data.deviceId);
//   //     print(json.decode(strUser));
//   //     prefs.get("cityId") == null
//   //         ? MyRoute().navigate(
//   //             context: scaffold.currentContext,
//   //             route: Login(),
//   //             withReplace: true)
//   //         : setCurrentUser(data, scaffold.currentContext);
//   //     changeLanguage(data.lang, func);
//   //   } else {
//   //     changeLanguage("ar", func);
//   //     Future.delayed(Duration(seconds: 3), () {
//   //       MyRoute().navigate(
//   //           context: scaffold.currentContext,
//   //           route: Login(),
//   //           withReplace: true);
//   //     });
//   //   }
//   // }

//   static void setCurrentUserData(SavedDataModel model, context) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     provider.setModel(model);
//     MyRoute()
//         .navigate(context: context, route: SelectCity(), withReplace: true);
//   }

//   static void setCurrentUser(SavedDataModel model, context) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     provider.setModel(model);
//     MyRoute().navigate(context: context, route: Home(), withReplace: true);
//   }

//   static void saveUserData(SavedDataModel model) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     prefs.setString("user", SavedDataModel().savedDataModelToJson(model));
//   }

  // static void changeLanguage(String lang, Function func) {
  //   if (lang == "en") {
  //     func(Locale('en', 'US'));
  //   } else {
  //     func(Locale('ar', 'EG'));
  //   }
  // }-

//   static SavedDataModel getSavedData({@required context}) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     return provider.model;
//   }

//   static void clearSavedData() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     prefs.clear();
//   }

//   static CustomerModel getCustomerData({@required context}) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     return provider.model.customer;
//   }

//   static int getCurrentUserType({@required context}) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     return provider.model.type;
//   }

//   static String getCurrentUserLang({@required context}) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     return provider.model.lang;
//   }

//   static String getCurrentUserToken({@required context}) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     return provider.model.token;
//   }

//   static void setCurrentUserType({@required context, @required int type}) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     SavedDataModel model = provider.model;
//     model.type = type;
//     provider.setModel(model);
//   }

//   static void setCurrentUserLang(
//       {@required context, @required Function function, @required String lang}) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     SavedDataModel model = provider.model;
//     model.lang = lang;
//     provider.setModel(model);
//     changeLanguage(lang, function);
//   }

//   static String getCurrentUserId({@required context}) {
//     var provider = Provider.of<UserProvider>(context, listen: false);
//     return getCurrentUserType(context: context) == 1
//         ? provider.model.customer.id
//         : "";
//   }

//   static void getCurrentLocation() {
//     var location = Location();
//     location.getLocation().then((loc) {
//       GlobalState.instance.set("currentLat", "${loc.latitude}");
//       GlobalState.instance.set("currentLng", "${loc.longitude}");
//     });
//   }

//   static void setSelectUser({@required int type, @required context}) async {
//     setCurrentUserType(context: context, type: type);
//     MyRoute().navigate(context: context, route: Login());
//   }

//   static void launchYoutube({@required String url}) async {
//     if (Platform.isIOS) {
//       if (await canLaunch('$url')) {
//         await launch('$url', forceSafariVC: false);
//       } else {
//         if (await canLaunch('$url')) {
//           await launch('$url');
//         } else {
//           throw 'Could not launch $url';
//         }
//       }
//     } else {
//       if (await canLaunch(url)) {
//         await launch(url);
//       } else {
//         throw 'Could not launch $url';
//       }
//     }
//   }

  // static Future<File> getImage() async {
  //   PickedFile image =
  //       await ImagePicker().getImage(source: ImageSource.gallery);
  //   if (image != null) {
  //     return File(image.path);
  //   } else {
  //     return null;
  //   }
  // }

//   static Future<File> getVideo() async {
//     PickedFile image =
//         await ImagePicker().getVideo(source: ImageSource.gallery);
//     if (image != null) {
//       return File(image.path);
//     } else {
//       return null;
//     }
//   }

//   static void copToClipboard({String text, GlobalKey<ScaffoldState> scaffold}) {
//     if (text.trim().isEmpty) {
//       LoadingDialog(scaffold).showNotification(tr("couponValidation"));
//       return;
//     } else {
//       Clipboard.setData(ClipboardData(text: "$text")).then((value) {
//         LoadingDialog(scaffold).showNotification(tr("couponSuccess"));
//       });
//     }
//   }
}
