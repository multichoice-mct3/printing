
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:agrofad/models/post_account_det.dart';
import 'login_apis.dart';

class SendAgentRouteStatusApi{
  LoginApi loginApi = new LoginApi();
  bool done;
  Future<bool>  SendAgentRouteStatus({int AvrId,String Type,String manualResultNote , int EmpId})async {

    await loginApi.getAccessToken();
    Map Headers = <String, String>{
      'Accept': 'application/json',
      'Authorization': 'Bearer ${loginApi.token}',
    };
    var Response;
    if (Type=='Completed') {
      Response = await http.post(
          "http://104.196.134.107/AfitAPI/api/AgentVisitRoutes/CompleteAgentVisitRoute?avrId="+"$AvrId"+"&manualResultNote="+"$manualResultNote"+"&manualResultEmpID="+EmpId.toString(),
          headers: Headers
                          );
                         }
    if (Type=='EmpCancel') {
      Response = await http.post(
          "http://104.196.134.107/AfitAPI/api/AgentVisitRoutes/EmpCancelAgentVisitRoute?avrId="+"$AvrId"+"&manualResultNote="+"$manualResultNote"+"&manualResultEmpID="+EmpId.toString(),
          headers: Headers
      );
                       }
    if (Type=='ManagerCancel') {
      Response = await http.post(
          "http://104.196.134.107/AfitAPI/api/AgentVisitRoutes/ManagerCancelAgentVisitRoute?avrId="+"$AvrId"+"&manualResultNote="+"$manualResultNote"+"&manualResultEmpID="+EmpId.toString(),
          headers: Headers
      );
    }
    // if (Type=='Approved') {
    //   Response = await http.post(
    //       'http://104.196.134.107/AfitAPI/api/ApproveRequestOrder/$index',
    //       headers: Headers
    //    );
    //    }
    if (Response.statusCode==204 ||Response.statusCode==201 ||Response.statusCode==200){
      done=true;
    }
    else {
      var PostResult=jsonDecode(Response.body);
      done =false;
      print(PostResult);
    }

    return done;

  }

}