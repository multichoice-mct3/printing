import 'package:bot_toast/bot_toast.dart';
import 'package:elfares/genaral/constants/AnimatedLoading.dart';
import 'package:elfares/genaral/constants/MyColors.dart';
import 'package:elfares/main.dart';
import 'package:elfares/user/auth/LoginContent.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import 'MyText.dart';

class LoadingDialog {
  var context;

  LoadingDialog(this.context);

  showDilaog() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            contentPadding: EdgeInsets.all(0),
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(10))),
            backgroundColor: Colors.transparent,
            content: AnimatedLoading(
              child: Image.asset(
                "assets/ElfaresLogo.png",
                width: 50,
                height: 50,
              ),
            ),
          );
        });
  }

  showLoadingView() {
    return SpinKitThreeBounce(
      color: MyColors.primary,
      size: 40.0,
    );
  }

  showSimpleLoadingView() {
    return SpinKitRipple(
      color: MyColors.primary,
      size: 40.0,
    );
  }

  showMapLoadingView() {
    return CupertinoActivityIndicator(
      animating: true,
      radius: 20,
    );
  }

  showNotification(msg) {
    context.currentState.showSnackBar(
      SnackBar(
        content: Container(
          height: 25,
          alignment: Alignment.center,
          child: MyText(
            title: msg,
            color: Colors.white,
            size: 10,
          ),
        ),
        backgroundColor: Colors.black.withOpacity(.7),
        duration: Duration(seconds: 2),
      ),
    );
  }

  showBlackNotification(msg) {
    context.currentState.showSnackBar(
      SnackBar(
        content: Container(
          height: 30,
          alignment: Alignment.center,
          child: MyText(
            title: msg,
            color: Colors.white,
            size: 16,
          ),
        ),
        backgroundColor: MyColors.primary,
        duration: Duration(seconds: 2),
      ),
    );
  }

  static showLoadingDialog() {
    EasyLoading.show(
        maskType: EasyLoadingMaskType.black,
        dismissOnTap: false,
        indicator: SpinKitCubeGrid(
          size: 40.0,
          itemBuilder: (context, index) {
            return Container(
              height: 10,
              width: 10,
              margin: EdgeInsets.all(1),
              decoration: BoxDecoration(
                  color: MyColors.primary, shape: BoxShape.circle),
            );
          },
        ),
        status: "loading");
  }

  static showConfirmDialog(
      {required BuildContext context,
      required String title,
      required Function confirm}) {
    return showCupertinoDialog(
      context: context,
      builder: (BuildContext context) {
        return _alertDialog(title, confirm, context, "تأكيد");
      },
    );
  }

  static showAuthDialog({required BuildContext context}) {
    return showCupertinoDialog(
      context: context,
      builder: (BuildContext context) {
        return _alertDialog(
            "قم بتسجيل الدخول للمتابعة",
            () => MyApp.navigatorKey.currentState?.pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => LoginContent()),
                (route) => false),
            context,
            "دخول");
      },
    );
  }

  static Widget _alertDialog(
      String title, Function confirm, BuildContext context, String okText) {
    return CupertinoAlertDialog(
      title: MyText(
        title: title,
        size: 12,
        color: MyColors.blackOpacity,
      ),
      // content: MyText(title: title,size: 12,color: MyColors.blackOpacity,),
      actions: [
        CupertinoDialogAction(
          child: MyText(
            title: "رجوع",
            size: 12,
            color: MyColors.blackOpacity,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        CupertinoDialogAction(
          child: MyText(
            title: okText,
            size: 12,
            color: MyColors.blackOpacity,
          ),
          onPressed: confirm(),
        ),
      ],
    );
  }

  static showToastNotification(msg,
      {Color? color, Color? textColor, Alignment? alignment}) {
    BotToast.showSimpleNotification(
        title: msg,
        align: alignment ?? Alignment.bottomCenter,
        backgroundColor: color ?? MyColors.dark,
        titleStyle: TextStyle(color: textColor ?? MyColors.white),
        duration: Duration(seconds: 3),
        hideCloseButton: false,
        closeIcon: Icon(
          Icons.close,
          size: 25,
          color: MyColors.white,
        ));
  }

  static showSimpleToast(msg) {
    BotToast.showText(text: msg);
  }
}
