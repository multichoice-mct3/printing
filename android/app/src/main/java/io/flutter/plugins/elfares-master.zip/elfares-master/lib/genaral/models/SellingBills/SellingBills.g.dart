// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'SellingBills.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SellingBill _$SellingBillFromJson(Map<String, dynamic> json) {
  return SellingBill(
    customerId: json['CustomerId'] as int?,
    customerName: json['CustomerName'] as String?,
    date: json["'SellingDate'"] as String?,
    discount: (json['SellingDisc'] as num?)?.toDouble(),
    entryUserDate: json['EntryUserDate'] as String?,
    entryUserId: json['EntryUserId'] as int?,
    id: json['SellingID'] as int?,
    items: (json["'saleInvItems'"] as List<dynamic>?)
        ?.map((e) => BillItemModel.fromJson(e as Map<String, dynamic>))
        .toList(),
    sellingValue: (json['SellingVal'] as num?)?.toDouble(),
    total: (json['SellingTot'] as num?)?.toDouble(),
    type: json['SellingType'] as String?,
  );
}

Map<String, dynamic> _$SellingBillToJson(SellingBill instance) =>
    <String, dynamic>{
      'SellingID': instance.id,
      "'SellingDate'": instance.date,
      'SellingType': instance.type,
      'CustomerId': instance.customerId,
      'CustomerName': instance.customerName,
      'SellingDisc': instance.discount,
      'SellingTot': instance.total,
      'SellingVal': instance.sellingValue,
      "'saleInvItems'": instance.items?.map((e) => e.toJson()).toList(),
      'EntryUserId': instance.entryUserId,
      'EntryUserDate': instance.entryUserDate,
    };
