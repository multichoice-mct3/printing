import 'package:json_annotation/json_annotation.dart';
part 'ItemsModel.g.dart';

@JsonSerializable(explicitToJson: true)
class Items {
  @JsonKey(name: "ItemName")
  String? itemName;
  @JsonKey(name: "UnitName")
  String? unitName;
  @JsonKey(name: "ItemID")
  int? itemId;
  @JsonKey(name: "UnitId")
  int? unitId;
  @JsonKey(name: "ItemSalePrice")
  double? itemSalePrice;
  @JsonKey(name: "AvailableQty")
  double? availableQty;
  @JsonKey(name: "CompanyName")
  String? companyName;
  @JsonKey(name: "ItemNote1")
  String? itemNote1;
  @JsonKey(name: "ItemNote2")
  String? itemNote2;
  @JsonKey(name: "ItemNO")
  String? itemNo;
  @JsonKey(name: "GroupID")
  int? groupId;

  Items({
    this.itemName,
    this.unitName,
    this.unitId,
    this.itemId,
    this.itemSalePrice,
    this.availableQty,
    this.companyName,
    this.groupId,
    this.itemNo,
    this.itemNote1,
    this.itemNote2,
  });

  factory Items.fromJson(Map<String, dynamic> json) => _$ItemsFromJson(json);
  Map<String, dynamic> toJson() => _$ItemsToJson(this);
}
